<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Database/Console/Seeds/SeederMakeCommand.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-b2bebee42b284189f1ccaf62df11b0af9fc11ddc620db5c0dc145cbffad1aa7c-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\database\\console\\seeds\\seedermakecommand' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));