<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Foundation/Console/ObserverMakeCommand.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-d79e40fc796769e949f4533747cfae5b8e47b58d954bfabcafacc5f5d508d8c8-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\foundation\\console\\observermakecommand' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));