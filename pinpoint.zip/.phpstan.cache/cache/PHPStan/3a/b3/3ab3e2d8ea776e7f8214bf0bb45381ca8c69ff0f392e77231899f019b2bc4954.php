<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Queue/Console/PruneBatchesCommand.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-81dd1796b8db30fffa1a5a67bea738a030c3cb5479c3542c95588889e6732f97-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\queue\\console\\prunebatchescommand' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));