<?php declare(strict_types = 1);

// odsl-/mnt/workspace/Personal-Projects/sentinel/src
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1-enums',
   'data' => 
  array (
    '/mnt/workspace/Personal-Projects/sentinel/src/Caller.php' => 
    array (
      0 => '47ad1616e9a0707e2c6f6ae2bbb733abfbaf1601e2653d35e533e64d463a0b6c',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\caller',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\capture',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/Internal/Recorder.php' => 
    array (
      0 => 'd8bedea5807ca3fc4d0b063f8037f30b2b480c7ff5ee451d9ec76a505e1e1ac8',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\internal\\recorder',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\internal\\__construct',
        1 => 'asimali\\pinpoint\\internal\\isrecording',
        2 => 'asimali\\pinpoint\\internal\\capturescaller',
        3 => 'asimali\\pinpoint\\internal\\shouldrecord',
        4 => 'asimali\\pinpoint\\internal\\recordquery',
        5 => 'asimali\\pinpoint\\internal\\recordlazyload',
        6 => 'asimali\\pinpoint\\internal\\flush',
        7 => 'asimali\\pinpoint\\internal\\reset',
        8 => 'asimali\\pinpoint\\internal\\hasnplusone',
        9 => 'asimali\\pinpoint\\internal\\repeatcounts',
        10 => 'asimali\\pinpoint\\internal\\lazyloads',
        11 => 'asimali\\pinpoint\\internal\\queries',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/Pinpoint.php' => 
    array (
      0 => '92b9b63edfd5c3f656204243c680d8dca1153f4d68c40aae5a41957b72fef58b',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\pinpoint',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\__construct',
        1 => 'asimali\\pinpoint\\observelazyload',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/PinpointServiceProvider.php' => 
    array (
      0 => '957d231797feb59873d9e612fd33226fb5e93bf36a83aa2dea63e75618fe08ec',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\pinpointserviceprovider',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\configurepackage',
        1 => 'asimali\\pinpoint\\registeringpackage',
        2 => 'asimali\\pinpoint\\bootingpackage',
        3 => 'asimali\\pinpoint\\registerquerylistener',
        4 => 'asimali\\pinpoint\\registerrequestlistener',
        5 => 'asimali\\pinpoint\\registerlazyloadingobserver',
        6 => 'asimali\\pinpoint\\requeststart',
        7 => 'asimali\\pinpoint\\currentlazyloadingcallback',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/QueryFingerprinter.php' => 
    array (
      0 => '62e92f89929ce69073e55d2541b72a0f5fd1cdfc371a10eedfeeb6490b06f915',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\queryfingerprinter',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\hash',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/TierClassifier.php' => 
    array (
      0 => '3c07504468e4fe20b5cb6225767a075c2a1c9f98f54938e0df34fb3d29320385',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\tierclassifier',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\__construct',
        1 => 'asimali\\pinpoint\\classify',
        2 => 'asimali\\pinpoint\\thresholdsfor',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/Commands/AggregateCommand.php' => 
    array (
      0 => '39e641c1f0f6b2a565300fc9cf2403b875bbf94ca7cb355d8330b4b24c67226a',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\commands\\aggregatecommand',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\commands\\__construct',
        1 => 'asimali\\pinpoint\\commands\\handle',
        2 => 'asimali\\pinpoint\\commands\\aggregate',
        3 => 'asimali\\pinpoint\\commands\\durationsfor',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/Commands/ReportCommand.php' => 
    array (
      0 => '673b8d3a80c5913f47be52f5153b02bc13cf6e9434ad0896c19c1d5ea9726e56',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\commands\\reportcommand',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\commands\\__construct',
        1 => 'asimali\\pinpoint\\commands\\handle',
        2 => 'asimali\\pinpoint\\commands\\summary',
        3 => 'asimali\\pinpoint\\commands\\drillinto',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/Internal/Statistics.php' => 
    array (
      0 => 'eea602e8068224f158597575d2e45cc853c5e30b35b85953cd43ed9c360cca4f',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\internal\\statistics',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\internal\\percentile',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/Commands/PruneCommand.php' => 
    array (
      0 => 'f6307cd7f5346785547a70a7c6ac7d2768d80b01f26edb2b2bb9683a38fb7e69',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\commands\\prunecommand',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\commands\\handle',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/Http/Controllers/PinpointApiController.php' => 
    array (
      0 => '663f0e71381cd19ca5e5350ae2fdcc66ca8214f3f086ef46fe82c66bbe67b00e',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\http\\controllers\\pinpointapicontroller',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\http\\controllers\\__construct',
        1 => 'asimali\\pinpoint\\http\\controllers\\summaries',
        2 => 'asimali\\pinpoint\\http\\controllers\\topqueries',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/Http/Middleware/LocalOnly.php' => 
    array (
      0 => 'fae53e15b3a92e6479fb331714d597fa8464156e262b844331e6f69fb5148bfc',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\http\\middleware\\localonly',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\http\\middleware\\handle',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/Internal/QueryReader.php' => 
    array (
      0 => '2a45193ecb61464056a6cd06f54dade94960418727d2714622248dac17b28017',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\internal\\queryreader',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\internal\\topqueries',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/Internal/SummaryReader.php' => 
    array (
      0 => '780d66cfedff9c475fc0c02229de047155df84d05c8ea711f89630c5913a9b62',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\internal\\summaryreader',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\internal\\__construct',
        1 => 'asimali\\pinpoint\\internal\\fromraw',
        2 => 'asimali\\pinpoint\\internal\\maxrepeatcounts',
        3 => 'asimali\\pinpoint\\internal\\durationsfor',
      ),
      3 => 
      array (
      ),
    ),
  ),
));