<?php declare(strict_types = 1);

// odsl-/mnt/workspace/Personal-Projects/sentinel/src
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1-enums',
   'data' => 
  array (
    '/mnt/workspace/Personal-Projects/sentinel/src/Caller.php' => 
    array (
      0 => '0014ebd16d5344ff048cc199160d81f822ef52f2b0eefbebb614bac5bdc172e2',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\caller',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\capture',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/Internal/Recorder.php' => 
    array (
      0 => 'd8bedea5807ca3fc4d0b063f8037f30b2b480c7ff5ee451d9ec76a505e1e1ac8',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\internal\\recorder',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\internal\\__construct',
        1 => 'asimali\\pinpoint\\internal\\isrecording',
        2 => 'asimali\\pinpoint\\internal\\capturescaller',
        3 => 'asimali\\pinpoint\\internal\\shouldrecord',
        4 => 'asimali\\pinpoint\\internal\\recordquery',
        5 => 'asimali\\pinpoint\\internal\\recordlazyload',
        6 => 'asimali\\pinpoint\\internal\\flush',
        7 => 'asimali\\pinpoint\\internal\\reset',
        8 => 'asimali\\pinpoint\\internal\\hasnplusone',
        9 => 'asimali\\pinpoint\\internal\\repeatcounts',
        10 => 'asimali\\pinpoint\\internal\\lazyloads',
        11 => 'asimali\\pinpoint\\internal\\queries',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/Pinpoint.php' => 
    array (
      0 => 'b5e504839349a7e0e086f518eba71c9f58baab8ed4ed28b800b73e164a4bde36',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\pinpoint',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\__construct',
        1 => 'asimali\\pinpoint\\observelazyload',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/PinpointServiceProvider.php' => 
    array (
      0 => '0e277ce56691eaa66274e55aeed8f8e46471f29ea6fe791ebc10a9a89f3dd492',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\pinpointserviceprovider',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\configurepackage',
        1 => 'asimali\\pinpoint\\registeringpackage',
        2 => 'asimali\\pinpoint\\bootingpackage',
        3 => 'asimali\\pinpoint\\registerquerylistener',
        4 => 'asimali\\pinpoint\\registerrequestlistener',
        5 => 'asimali\\pinpoint\\registerlazyloadingobserver',
        6 => 'asimali\\pinpoint\\requeststart',
        7 => 'asimali\\pinpoint\\currentlazyloadingcallback',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/QueryFingerprinter.php' => 
    array (
      0 => '62e92f89929ce69073e55d2541b72a0f5fd1cdfc371a10eedfeeb6490b06f915',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\queryfingerprinter',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\hash',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/TierClassifier.php' => 
    array (
      0 => '92e012b0af6ef819aa84619ce7ef3394cd2e8e13fdd4995a9499f4ca1ae676d7',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\tierclassifier',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\__construct',
        1 => 'asimali\\pinpoint\\classify',
        2 => 'asimali\\pinpoint\\thresholdsfor',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/Commands/AggregateCommand.php' => 
    array (
      0 => 'fb9ce26649d3d7c7de71015d9571378a653b964e13cd528c279d617979d05094',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\commands\\aggregatecommand',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\commands\\__construct',
        1 => 'asimali\\pinpoint\\commands\\handle',
        2 => 'asimali\\pinpoint\\commands\\aggregate',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/Commands/ReportCommand.php' => 
    array (
      0 => '673b8d3a80c5913f47be52f5153b02bc13cf6e9434ad0896c19c1d5ea9726e56',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\commands\\reportcommand',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\commands\\__construct',
        1 => 'asimali\\pinpoint\\commands\\handle',
        2 => 'asimali\\pinpoint\\commands\\summary',
        3 => 'asimali\\pinpoint\\commands\\drillinto',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/Internal/Statistics.php' => 
    array (
      0 => 'eea602e8068224f158597575d2e45cc853c5e30b35b85953cd43ed9c360cca4f',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\internal\\statistics',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\internal\\percentile',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/Commands/PruneCommand.php' => 
    array (
      0 => '737e4254437bf8fe2bc20f64399472bc1208970e621d750d04642f049f6e3922',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\commands\\prunecommand',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\commands\\handle',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/Http/Controllers/PinpointApiController.php' => 
    array (
      0 => '663f0e71381cd19ca5e5350ae2fdcc66ca8214f3f086ef46fe82c66bbe67b00e',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\http\\controllers\\pinpointapicontroller',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\http\\controllers\\__construct',
        1 => 'asimali\\pinpoint\\http\\controllers\\summaries',
        2 => 'asimali\\pinpoint\\http\\controllers\\topqueries',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/Http/Middleware/LocalOnly.php' => 
    array (
      0 => 'fae53e15b3a92e6479fb331714d597fa8464156e262b844331e6f69fb5148bfc',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\http\\middleware\\localonly',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\http\\middleware\\handle',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/Internal/QueryReader.php' => 
    array (
      0 => 'f5b5c2325911fb6f54f3d195fe3dded7ef1192a54abbdac0cf144758ffb4f844',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\internal\\queryreader',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\internal\\topqueries',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/Internal/SummaryReader.php' => 
    array (
      0 => '06a4690aa161c61ad614e8bbc2859c3ae64b4bdc20753950a8a8a3529820f93c',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\internal\\summaryreader',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\internal\\__construct',
        1 => 'asimali\\pinpoint\\internal\\fromraw',
        2 => 'asimali\\pinpoint\\internal\\maxrepeatcounts',
      ),
      3 => 
      array (
      ),
    ),
    '/mnt/workspace/Personal-Projects/sentinel/src/Facades/Pinpoint.php' => 
    array (
      0 => '2be956d1288209dcf49c9d23c01afaf04748cb97721f52f8ebc28b8a088580fe',
      1 => 
      array (
        0 => 'asimali\\pinpoint\\facades\\pinpoint',
      ),
      2 => 
      array (
        0 => 'asimali\\pinpoint\\facades\\getfacadeaccessor',
      ),
      3 => 
      array (
      ),
    ),
  ),
));