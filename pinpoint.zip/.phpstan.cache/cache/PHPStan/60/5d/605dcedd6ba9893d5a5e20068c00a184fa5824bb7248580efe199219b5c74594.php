<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Queue/Console/ListFailedCommand.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-85e3c21a863a632d27b8c2ad6dc761dd09072cfa94fdae3f53aa5786e18d773a-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\queue\\console\\listfailedcommand' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));