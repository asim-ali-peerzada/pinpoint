<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ScopeMakeCommand.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      '139fcd6b79ce73e545044a9e134fe36f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1469230be72b8e225755d1b3f78ab952' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ScopeMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '1e98bee8a662245139b5efeea6eac040' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'presetmanager' => 'Orchestra\\Canvas\\Core\\PresetManager',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ScopeMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
          3 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          4 => NULL,
        ),
      )),
      '2ac3194a99592893dfcdfea3a39c18af' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'presetmanager' => 'Orchestra\\Canvas\\Core\\PresetManager',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => 'addGeneratorPresetOptions',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ScopeMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
          3 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          4 => NULL,
        ),
      )),
      '9a2731a9a6dff533c2b723e0dbcaf5d8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'presetmanager' => 'Orchestra\\Canvas\\Core\\PresetManager',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => 'generatorPreset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ScopeMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
          3 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          4 => NULL,
        ),
      )),
      '9bc057c69fd0400bd97bbff8c619dda1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'presetmanager' => 'Orchestra\\Canvas\\Core\\PresetManager',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => 'getGeneratorSourcePath',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ScopeMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
          3 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          4 => NULL,
        ),
      )),
      '6576a0bf587c9b0f09b5caba5af6eb63' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => 'generateCode',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ScopeMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '5815af95534e81a492c0e20f997b6ef4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => 'generatingCode',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ScopeMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'fb80d2e68934d70c5cbc466a7383570e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => 'codeAlreadyExists',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ScopeMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '552679cce17d54975569c529aa6bcbef' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => 'codeHasBeenGenerated',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ScopeMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'c5ff7f44f5b83dceb4929780900b9c3b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => 'afterCodeHasBeenGenerated',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ScopeMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'ac213ea73fd3c1140a75debe2c10877b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ScopeMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '5eb7638af7ec2338fd5ed6d6185bd881' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => 'qualifyModelUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ScopeMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '14e021e5d8c4ca9016a672e435084525' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => 'getPathUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ScopeMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '87521fa35b7389772d8e98e5a6612b20' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => 'rootNamespaceUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ScopeMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'ba725027eddb536b463edeb3d291f932' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => 'userProviderModelUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ScopeMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'f3fa2cacf95c8b7a57b6d7b877000f6d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => 'viewPathUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ScopeMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'b1b4fc49c14957f9c7137683bb347d50' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => 'findAvailableModelsUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ScopeMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '2fd366c82110ba78eabad04017e38d1f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => 'possibleModelsUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ScopeMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'e1fa39f20a9e1ac2a064880800c00183' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => 'possibleEventsUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ScopeMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '42eb33f973cc420d8076de9313bd7bed' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => 'rootNamespace',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ScopeMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'fe8c668b717a347ea15d9e9636ca03b6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => 'generatorPreset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ScopeMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '719eabfe25321d4278e545be35f351b3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => 'configure',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Orchestra\\Canvas\\Console',
           'uses' => 
          array (
            'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
            'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
            'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
          ),
           'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ee476aa27ca97e6674310aca05646208' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => 'handle',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Orchestra\\Canvas\\Console',
           'uses' => 
          array (
            'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
            'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
            'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
          ),
           'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7d60b23bb608568c2051d52409c5d652' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => 'qualifyModel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Orchestra\\Canvas\\Console',
           'uses' => 
          array (
            'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
            'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
            'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
          ),
           'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c043f403f859e6c1f50abd6040db9c18' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => 'getPath',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Orchestra\\Canvas\\Console',
           'uses' => 
          array (
            'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
            'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
            'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
          ),
           'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '28e99e473fb923b665ca43dafcfa137c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
         'functionName' => 'rootNamespace',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Orchestra\\Canvas\\Console',
           'uses' => 
          array (
            'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
            'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
            'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
          ),
           'className' => 'Orchestra\\Canvas\\Console\\ScopeMakeCommand',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ScopeMakeCommand.php' => '57c97ae8299d9f5795fc0a95739adac104454525abe81893d0442ce975638ecc',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas-core/src/Concerns/CodeGenerator.php' => '53a99bd8408373e5b764137127dd6bb92f0f84481043bc6e888a5bca12525f95',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas-core/src/Concerns/CreatesUsingGeneratorPreset.php' => '04f1fc472c3c006decd42fd64ba2fd495b70184367d40a981caa601c12ad8775',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas-core/src/Concerns/UsesGeneratorOverrides.php' => 'ccb973108e69ca46e54365c3cacda3127f5f816944d3d836b07a02ff21b1869d',
    ),
  ),
));