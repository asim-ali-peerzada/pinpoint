<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Concerns/BuildsQueries.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      'd2036e51e761b30b043de26f92922c3d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
          'TValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 2,
                'endLine' => 2,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8659bb0ac97809fb5a248b0848376152' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'closure' => 'Closure',
          'higherorderwhenproxy' => 'Illuminate\\Support\\HigherOrderWhenProxy',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Conditionable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Concerns/BuildsQueries.php',
          1 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          2 => 'Illuminate\\Support\\Traits\\Conditionable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '9bbef8d3c4de3a6eff6370e75893da72' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'closure' => 'Closure',
          'higherorderwhenproxy' => 'Illuminate\\Support\\HigherOrderWhenProxy',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => 'when',
         'templatePhpDocNodes' => 
        array (
          'TWhenParameter' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TWhenParameter',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TWhenReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TWhenReturnType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Conditionable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Concerns/BuildsQueries.php',
          1 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          2 => 'Illuminate\\Support\\Traits\\Conditionable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'a8eeda2164e1545af67ed727c49400ea' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'closure' => 'Closure',
          'higherorderwhenproxy' => 'Illuminate\\Support\\HigherOrderWhenProxy',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => 'unless',
         'templatePhpDocNodes' => 
        array (
          'TUnlessParameter' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TUnlessParameter',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TUnlessReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TUnlessReturnType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Conditionable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Concerns/BuildsQueries.php',
          1 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          2 => 'Illuminate\\Support\\Traits\\Conditionable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'd7ba0256d4e22cc2e1e030a875417e76' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => 'chunk',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'abbbeb137631e66f7b5e4f4d03dbc098' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => 'chunkMap',
         'templatePhpDocNodes' => 
        array (
          'TReturn' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TReturn',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3a2ea179f79d3f560359339844b3babb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => 'each',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c39ef48d0526e58e69d20c143109155d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => 'chunkById',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9166068cd675293059f2d6a9f6eafdcc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => 'chunkByIdDesc',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bda9e61a9bfa338450f46f366dc6952d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => 'orderedChunkById',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'da70760861110a519b02de67e732b3e5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => 'eachById',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c641326f1afdbf9c8146b46f5092728e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => 'lazy',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a61432f34d555db774769c0ddc2ca2c4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => 'lazyById',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd5c09c84d31abfdee87ef7d2ddc7523c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => 'lazyByIdDesc',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '94b6ab811789c817ff5089320b5646db' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => 'orderedLazyById',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '678c1d9a448727ddf0945cfd2f7fb725' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => 'first',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f55a83a7ead6d201ffe2b2e59c9b3ef8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => 'firstOrFail',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b100e3697af3365cb26e8c4ce950af32' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => 'sole',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a1ac5729a60ab9ef667ee92174fdc56c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => 'paginateUsingCursor',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a9f1e04bea35676ffebfbdd701254a21' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => 'getOriginalColumnNameForCursorPagination',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5654a9055deeca85edfd1eb1ef0f768a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => 'paginator',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f713d463a8d59525fd1b76a5dac6045e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => 'simplePaginator',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a098194280b87a36493df0ede7b725b2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => 'cursorPaginator',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8deea7383fb44c70dfa3c5f6913c0e44' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => 'tap',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'eaababe4dd3f88a8b6a032d499ce6181' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'functionName' => 'pipe',
         'templatePhpDocNodes' => 
        array (
          'TReturn' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TReturn',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Concerns/BuildsQueries.php' => '8ea5428ad1592fca250ef6724cbb4384185c5f95ef7bda850062a0d20e56bec1',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Conditionable/Traits/Conditionable.php' => '5697fdba0acb78ca0b4e122e5c459cd5d97d000ed9b14fed31271cb7ffd44225',
    ),
  ),
));