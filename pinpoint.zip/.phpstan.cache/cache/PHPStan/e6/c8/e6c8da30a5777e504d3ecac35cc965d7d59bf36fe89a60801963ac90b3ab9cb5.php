<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../spatie/laravel-package-tools/src/Concerns/PackageServiceProvider/ProcessInertia.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-d88494d15e350df0961deb32c037490689d190dbc575c1f21ef841e551db94ad-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'spatie\\laravelpackagetools\\concerns\\packageserviceprovider\\processinertia' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));