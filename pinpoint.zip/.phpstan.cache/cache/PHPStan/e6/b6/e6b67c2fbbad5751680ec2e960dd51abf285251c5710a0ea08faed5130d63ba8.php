<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../nesbot/carbon/src/Carbon/Traits/Week.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-4383ba3a1e433349741853035ab0996c59c5227a51a657725389b92831183198-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'carbon\\traits\\week' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));