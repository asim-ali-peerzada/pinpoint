<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Contracts/Support/Responsable.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-073522621ad7f4ae90dd19765eea94a14d14cfcd90d7942d2ba1107e6a6b34c0-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\contracts\\support\\responsable' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));