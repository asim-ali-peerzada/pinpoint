<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas-core/src/Commands/GeneratorCommand.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-798151c5afbef819fd7a8702f2b50532a4b0884a0091986731042e3eb94c24eb-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'orchestra\\canvas\\core\\commands\\generatorcommand' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));