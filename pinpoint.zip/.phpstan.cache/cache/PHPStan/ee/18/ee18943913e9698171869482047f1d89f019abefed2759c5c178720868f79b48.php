<?php declare(strict_types = 1);

// phpinternal-PHPStan\BetterReflection\Reflection\ReflectionConstant-DEBUG_BACKTRACE_PROVIDE_OBJECT
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.3-dev-master@709e512-8.2.33',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\InternalLocatedSource',
      'data' => 
      array (
        'name' => 'DEBUG_BACKTRACE_PROVIDE_OBJECT',
        'filename' => 'phpstorm-stubs:Core/Core_d.stub',
        'extensionName' => 'Core',
        'aliasName' => NULL,
      ),
    ),
    'name' => 'DEBUG_BACKTRACE_PROVIDE_OBJECT',
    'shortName' => 'DEBUG_BACKTRACE_PROVIDE_OBJECT',
    'value' => 
    array (
      'code' => '1',
      'attributes' => 
      array (
        'startLine' => 3,
        'endLine' => 3,
        'startTokenPos' => 7,
        'startFilePos' => 48,
        'endTokenPos' => 7,
        'endFilePos' => 48,
      ),
    ),
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 3,
    'endLine' => 3,
    'startColumn' => 1,
    'endColumn' => 43,
    'namespace' => NULL,
  ),
));