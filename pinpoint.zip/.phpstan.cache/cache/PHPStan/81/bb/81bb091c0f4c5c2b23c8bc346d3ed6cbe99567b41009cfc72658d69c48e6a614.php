<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/RequestMakeCommand.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      '412d1ec97bb249546ba8061d2f83c0b7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1b2dbd98e2c827b97a551f12ef3cd900' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/RequestMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'b208edf2f9b4f14d027cb5c25b5efc12' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'presetmanager' => 'Orchestra\\Canvas\\Core\\PresetManager',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/RequestMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
          3 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          4 => NULL,
        ),
      )),
      'a1c8b01c781e1788b3be688b597e5d79' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'presetmanager' => 'Orchestra\\Canvas\\Core\\PresetManager',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => 'addGeneratorPresetOptions',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/RequestMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
          3 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          4 => NULL,
        ),
      )),
      'b13ed2dd0f56075c2daeab6857831783' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'presetmanager' => 'Orchestra\\Canvas\\Core\\PresetManager',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => 'generatorPreset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/RequestMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
          3 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          4 => NULL,
        ),
      )),
      '8adc0ed48ba3cf2e50524c540b001ba4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'presetmanager' => 'Orchestra\\Canvas\\Core\\PresetManager',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => 'getGeneratorSourcePath',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/RequestMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
          3 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          4 => NULL,
        ),
      )),
      '24373c6f29afe5c30cf0ad588560073c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => 'generateCode',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/RequestMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '147b469ccb287439455912260f265126' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => 'generatingCode',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/RequestMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'c3aceff1cf30f9e7f6f96282184809c4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => 'codeAlreadyExists',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/RequestMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'c0095835bc8f510f1de94aab2dd84e06' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => 'codeHasBeenGenerated',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/RequestMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '11df0934b86eb3f1f688d08f4237abba' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => 'afterCodeHasBeenGenerated',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/RequestMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'c15d07a97f5379ebfe6f9281e5570b47' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/RequestMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '229b994d99ca97023a517c39dfd6ffe3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => 'qualifyModelUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/RequestMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '071b62a769086e4cf50708435ae1f854' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => 'getPathUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/RequestMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '9c410fb08f26d562c2f59bd9ac65d579' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => 'rootNamespaceUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/RequestMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '1f6383c00fb27d5c9d119609156dd697' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => 'userProviderModelUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/RequestMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '75fbe5c330a4a7b19f7e0fb6966c9695' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => 'viewPathUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/RequestMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'd40d200fd075df3ec9bbf437ed35d652' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => 'findAvailableModelsUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/RequestMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'b4f11ace49248615cc59f4884756df3b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => 'possibleModelsUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/RequestMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'd829eb7efe18b7f27caa38585437538c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => 'possibleEventsUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/RequestMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '898417fd9c284c6faa05a06537c0a3d6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => 'rootNamespace',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/RequestMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'faa4cb86e26ad76a7c9d845b0c1c067e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => 'generatorPreset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/RequestMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '42c65a0bb39d53a651cc94af7f75b50d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => 'configure',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Orchestra\\Canvas\\Console',
           'uses' => 
          array (
            'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
            'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
            'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
          ),
           'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '92d49e10d539a6778c33baefb94aac49' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => 'handle',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Orchestra\\Canvas\\Console',
           'uses' => 
          array (
            'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
            'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
            'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
          ),
           'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '239d51d3a7be674f28f81e4311730244' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => 'getPath',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Orchestra\\Canvas\\Console',
           'uses' => 
          array (
            'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
            'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
            'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
          ),
           'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '32861d0f85c476d8210ac451912404fd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
         'functionName' => 'rootNamespace',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Orchestra\\Canvas\\Console',
           'uses' => 
          array (
            'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
            'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
            'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
          ),
           'className' => 'Orchestra\\Canvas\\Console\\RequestMakeCommand',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/RequestMakeCommand.php' => '14595e3c3b12738932c980a82cd02d817685265a25106126f13c79f5a3cb937b',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas-core/src/Concerns/CodeGenerator.php' => '53a99bd8408373e5b764137127dd6bb92f0f84481043bc6e888a5bca12525f95',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas-core/src/Concerns/CreatesUsingGeneratorPreset.php' => '04f1fc472c3c006decd42fd64ba2fd495b70184367d40a981caa601c12ad8775',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas-core/src/Concerns/UsesGeneratorOverrides.php' => 'ccb973108e69ca46e54365c3cacda3127f5f816944d3d836b07a02ff21b1869d',
    ),
  ),
));