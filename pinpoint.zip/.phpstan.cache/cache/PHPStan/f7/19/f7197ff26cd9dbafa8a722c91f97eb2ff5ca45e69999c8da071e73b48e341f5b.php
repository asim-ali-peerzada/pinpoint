<?php declare(strict_types = 1);

// ftm-phar:///mnt/workspace/Personal-Projects/sentinel/vendor/phpstan/phpstan/phpstan.phar/vendor/phpstan/php-8-stubs/stubs/ext/hash/hash.stub
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      '6f4b845a5d3910c30380f8cabd6054ff' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
        ),
         'className' => NULL,
         'functionName' => 'hash',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'phar:///mnt/workspace/Personal-Projects/sentinel/vendor/phpstan/phpstan/phpstan.phar/vendor/phpstan/php-8-stubs/stubs/ext/hash/hash.stub' => 'd9290a8f5890512144bcaa3037f145e5d1ba7fb9c3c66e3569701d3290619685',
    ),
  ),
));