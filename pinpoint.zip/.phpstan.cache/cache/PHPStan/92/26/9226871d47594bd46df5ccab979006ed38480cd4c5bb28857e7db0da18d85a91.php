<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Concerns/ManagesTransactions.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      '801b8379c1092e297c6f61b6ef519f33' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '69f7873748e42889f099af122f7e3ac3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
         'functionName' => 'transaction',
         'templatePhpDocNodes' => 
        array (
          'TReturn' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TReturn',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'mixed',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '

Execute a Closure within a transaction.',
               'attributes' => 
              array (
                'startLine' => 2,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'closure' => 'Closure',
            'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
            'runtimeexception' => 'RuntimeException',
            'throwable' => 'Throwable',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '92efea8d04e5f08a5dc7a5f9786febac' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
         'functionName' => 'handleTransactionException',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'closure' => 'Closure',
            'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
            'runtimeexception' => 'RuntimeException',
            'throwable' => 'Throwable',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ca95be3b55e1bc18324ae4fb3f36b8e7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
         'functionName' => 'beginTransaction',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'closure' => 'Closure',
            'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
            'runtimeexception' => 'RuntimeException',
            'throwable' => 'Throwable',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '17a4754d883e9af05dc72a2d8467614c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
         'functionName' => 'createTransaction',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'closure' => 'Closure',
            'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
            'runtimeexception' => 'RuntimeException',
            'throwable' => 'Throwable',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8d2c838c56d8e473b05270b4746baef7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
         'functionName' => 'createSavepoint',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'closure' => 'Closure',
            'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
            'runtimeexception' => 'RuntimeException',
            'throwable' => 'Throwable',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '40b108b4f5e791285eee4d9f9fca852a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
         'functionName' => 'handleBeginTransactionException',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'closure' => 'Closure',
            'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
            'runtimeexception' => 'RuntimeException',
            'throwable' => 'Throwable',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1a82d4e111d893aca427173cf8abf754' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
         'functionName' => 'commit',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'closure' => 'Closure',
            'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
            'runtimeexception' => 'RuntimeException',
            'throwable' => 'Throwable',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ee68fba031ed3ef1f1ce8c8a512b720a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
         'functionName' => 'handleCommitTransactionException',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'closure' => 'Closure',
            'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
            'runtimeexception' => 'RuntimeException',
            'throwable' => 'Throwable',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dc344b866772c2ff3b06ee536b682f6c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
         'functionName' => 'rollBack',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'closure' => 'Closure',
            'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
            'runtimeexception' => 'RuntimeException',
            'throwable' => 'Throwable',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dc7a352bd23a55ce23433c95fe6d4c20' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
         'functionName' => 'performRollBack',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'closure' => 'Closure',
            'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
            'runtimeexception' => 'RuntimeException',
            'throwable' => 'Throwable',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9697b635dcab5084a1e9f5cb97eff4f5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
         'functionName' => 'handleRollBackException',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'closure' => 'Closure',
            'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
            'runtimeexception' => 'RuntimeException',
            'throwable' => 'Throwable',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '30792f7b002a48ba0a7035ed75cb6828' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
         'functionName' => 'transactionLevel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'closure' => 'Closure',
            'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
            'runtimeexception' => 'RuntimeException',
            'throwable' => 'Throwable',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '905b8d579de5fd8c26571c963be693ed' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
         'functionName' => 'afterCommit',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'closure' => 'Closure',
            'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
            'runtimeexception' => 'RuntimeException',
            'throwable' => 'Throwable',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '84b780f20af0190ed6cbdeda87addb1f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
         'functionName' => 'afterRollBack',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'closure' => 'Closure',
            'deadlockexception' => 'Illuminate\\Database\\DeadlockException',
            'runtimeexception' => 'RuntimeException',
            'throwable' => 'Throwable',
          ),
           'className' => 'Illuminate\\Database\\Concerns\\ManagesTransactions',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Concerns/ManagesTransactions.php' => 'bb71e1cbe34f3f88a65e7ad192ade967a0f5b8c360e480197ed054ba8f11419c',
    ),
  ),
));