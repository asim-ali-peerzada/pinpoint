<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      '61502ebb9865fe6e341b1366846c1755' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6c091f6f729c80eaef94d06b2f5a0ef7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\CanBePrecognitive',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\CanBePrecognitive',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '53d5b544cb0bf6572086d3fccf912841' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'filterPrecognitiveRules',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\CanBePrecognitive',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\CanBePrecognitive',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '3c0ae09b57d275c06606f3949197cdb3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'shouldValidatePrecognitiveAttribute',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\CanBePrecognitive',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\CanBePrecognitive',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'ba9421d5254669bf2c9d8da8a933410d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'isAttemptingPrecognition',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\CanBePrecognitive',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\CanBePrecognitive',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '3d994c669c93c0cb80277a0e262ff5e6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'isPrecognitive',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\CanBePrecognitive',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\CanBePrecognitive',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'fd4443cc5da012c6598a8a6401fb7352' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'b6eb6704e49cc5d04c94d2ae2496549c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'isJson',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '871267110e5c7212003f6fb866534bef' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'expectsJson',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '86c5ad6ca7c8db0786aabffa923448bf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'wantsJson',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'c021afd130cb23e26127275ab2996288' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'wantsMarkdown',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '818d404b82c39eaf8fd454b3fa07e742' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'accepts',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '69da434179f15fc7af4cfdd2f15311dd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'prefers',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'cf71ae20268b6c5a1310d73bfe24c6cd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'acceptsAnyContentType',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'ef4e5933f50ede3ba93ba5afef8d1885' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'acceptsJson',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '4d7fef7660214f6835a322c118eeb569' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'acceptsMarkdown',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'cebe0cb919f07ee1da9cd755a518fb5d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'acceptsHtml',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '06961813054d8008821804bc743694c0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'matchesType',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'b65d0b1bb2f2c79fa1006c75bef84d61' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'format',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithContentTypes',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '1a673e9a1916568e2b2902b78bbac2f9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithFlashData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithFlashData',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '061c864f620fc1da704f8c7c05f61743' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'old',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithFlashData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithFlashData',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '3dfd95b8c823e69a063a4b3a252737f5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'flash',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithFlashData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithFlashData',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '2f91dce0f554e2e24244a1783700c9b9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'flashOnly',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithFlashData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithFlashData',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '7becdabe21ad47b073b441517ee82ca7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'flashExcept',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithFlashData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithFlashData',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '5c70a2138a80d5aa6bb628e8a8927bc7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'flush',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithFlashData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithFlashData',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'adcb78098e6ca3b84673ad3e720ce4ff' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'uploadedfile' => 'Illuminate\\Http\\UploadedFile',
          'arr' => 'Illuminate\\Support\\Arr',
          'fluent' => 'Illuminate\\Support\\Fluent',
          'dumpable' => 'Illuminate\\Support\\Traits\\Dumpable',
          'interactswithdata' => 'Illuminate\\Support\\Traits\\InteractsWithData',
          'splfileinfo' => 'SplFileInfo',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '365bcc9d5a6ebf91ba351efdf2d00ea7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Dumpable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\Dumpable',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      '15aca28e91f310b174be1a140ab1fb76' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'dd',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Dumpable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\Dumpable',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      '99114aa95a54c5884ce65e8c18a0fb6b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'dump',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Dumpable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\Dumpable',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      '07a2afe95f62d843a1e137719a4150dd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      'be568b3c1b82e112bd60b494836ca377' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'all',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      '0a8d1926e82a09653371cd32f3d781fc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'data',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      '0fd9f61b5f9f49523760beaf15131873' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'exists',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      'd6e68c84991af1eca477304ae5512018' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'has',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      'b7c0dc8524fe95ca6dd395d849af7d77' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'hasAny',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      '941c7ff27518594b36a3ff83e52ce53e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'whenHas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      '8e7891893f34e415993d97b658434a02' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'filled',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      '45752ca2e1eddbb3a5328f43701defbd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'isNotFilled',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      '211254514e849dc05a6216cdf32dc157' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'anyFilled',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      '0f991958d6b2af12f4dd1a3c701370f5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'whenFilled',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      'cfbbe92fce400bddbe26e5428a61a181' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'missing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      '29a30ce1d469e1a3f3bdab12d935858b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'whenMissing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      '7d202eba9f750c2742b9dfd07761f73f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'isEmptyString',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      'c7f4de9b1d54944b51d1c15cea5caedf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'str',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      'ab948b366bcb918f2cb2e180ad419fad' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'string',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      'c6170a17eceff0a0610e0a2f9b977bcb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'boolean',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      '70a086465c0e362572eb7f14a46ef185' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'integer',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      '3f346d9406019b048c97b66c980fc8b9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'float',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      'd02b5fa48125f4b47782d686e1d2c7c3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'clamp',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      '1d9fc0172d53b4e5b44ba13f2db4c287' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'date',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      'b5c7b0f06fca45d093ca02f02bc92ace' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'interval',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      '9ed09940b3860fa2972488f4f7b07142' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'enum',
         'templatePhpDocNodes' => 
        array (
          'TEnum' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TEnum',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => '\\BackedEnum',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TDefault' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TDefault',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\UnionTypeNode::__set_state(array(
                 'types' => 
                array (
                  0 => 
                  \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                     'name' => 'TEnum',
                     'attributes' => 
                    array (
                      'startLine' => 5,
                      'endLine' => 5,
                    ),
                  )),
                  1 => 
                  \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                     'name' => 'null',
                     'attributes' => 
                    array (
                      'startLine' => 5,
                      'endLine' => 5,
                    ),
                  )),
                ),
                 'attributes' => 
                array (
                  'startLine' => 5,
                  'endLine' => 5,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      'e571014d0ff940aba9090cd5c40f9265' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'enums',
         'templatePhpDocNodes' => 
        array (
          'TEnum' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TEnum',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => '\\BackedEnum',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      '1db8fb426372c37bace07e566c6e0fef' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'isBackedEnum',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      '4e927ecdcfcb37b31a58ba4c4ed2ad74' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'array',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      '0b0615d9b9234a89ac7afb43adc46115' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'collect',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      '59adcdf68691cc63fb096b728ab0f859' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'only',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      '1dbb9fa6cfa103ca705dc690fd75e35d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'unit' => 'Carbon\\Unit',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'date' => 'Illuminate\\Support\\Facades\\Date',
          'number' => 'Illuminate\\Support\\Number',
          'str' => 'Illuminate\\Support\\Str',
          'stdclass' => 'stdClass',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'except',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\InteractsWithData',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\InteractsWithData',
          3 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          4 => NULL,
        ),
      )),
      '1b14548c843fae8dbee2a297fcd38248' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'uploadedfile' => 'Illuminate\\Http\\UploadedFile',
          'arr' => 'Illuminate\\Support\\Arr',
          'fluent' => 'Illuminate\\Support\\Fluent',
          'dumpable' => 'Illuminate\\Support\\Traits\\Dumpable',
          'interactswithdata' => 'Illuminate\\Support\\Traits\\InteractsWithData',
          'splfileinfo' => 'SplFileInfo',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'server',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '0d43e96ce27a7f247fccf287b52149e9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'uploadedfile' => 'Illuminate\\Http\\UploadedFile',
          'arr' => 'Illuminate\\Support\\Arr',
          'fluent' => 'Illuminate\\Support\\Fluent',
          'dumpable' => 'Illuminate\\Support\\Traits\\Dumpable',
          'interactswithdata' => 'Illuminate\\Support\\Traits\\InteractsWithData',
          'splfileinfo' => 'SplFileInfo',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'hasHeader',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'da5bec687dff0ae07cb6a6b32ef82b9e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'uploadedfile' => 'Illuminate\\Http\\UploadedFile',
          'arr' => 'Illuminate\\Support\\Arr',
          'fluent' => 'Illuminate\\Support\\Fluent',
          'dumpable' => 'Illuminate\\Support\\Traits\\Dumpable',
          'interactswithdata' => 'Illuminate\\Support\\Traits\\InteractsWithData',
          'splfileinfo' => 'SplFileInfo',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'header',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '627aba706762180fa94aa95c6c4d48d0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'uploadedfile' => 'Illuminate\\Http\\UploadedFile',
          'arr' => 'Illuminate\\Support\\Arr',
          'fluent' => 'Illuminate\\Support\\Fluent',
          'dumpable' => 'Illuminate\\Support\\Traits\\Dumpable',
          'interactswithdata' => 'Illuminate\\Support\\Traits\\InteractsWithData',
          'splfileinfo' => 'SplFileInfo',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'bearerToken',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '05b94961f5034f0c38289e9f255b1b19' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'uploadedfile' => 'Illuminate\\Http\\UploadedFile',
          'arr' => 'Illuminate\\Support\\Arr',
          'fluent' => 'Illuminate\\Support\\Fluent',
          'dumpable' => 'Illuminate\\Support\\Traits\\Dumpable',
          'interactswithdata' => 'Illuminate\\Support\\Traits\\InteractsWithData',
          'splfileinfo' => 'SplFileInfo',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'keys',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'fafa2e0e24cf642eb37c30bba0a07313' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'uploadedfile' => 'Illuminate\\Http\\UploadedFile',
          'arr' => 'Illuminate\\Support\\Arr',
          'fluent' => 'Illuminate\\Support\\Fluent',
          'dumpable' => 'Illuminate\\Support\\Traits\\Dumpable',
          'interactswithdata' => 'Illuminate\\Support\\Traits\\InteractsWithData',
          'splfileinfo' => 'SplFileInfo',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'all',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '9c64791b0d9ad5868a02a9bf2a1a5413' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'uploadedfile' => 'Illuminate\\Http\\UploadedFile',
          'arr' => 'Illuminate\\Support\\Arr',
          'fluent' => 'Illuminate\\Support\\Fluent',
          'dumpable' => 'Illuminate\\Support\\Traits\\Dumpable',
          'interactswithdata' => 'Illuminate\\Support\\Traits\\InteractsWithData',
          'splfileinfo' => 'SplFileInfo',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'input',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '3590043e31d00bc97e4e4f57c3745ccd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'uploadedfile' => 'Illuminate\\Http\\UploadedFile',
          'arr' => 'Illuminate\\Support\\Arr',
          'fluent' => 'Illuminate\\Support\\Fluent',
          'dumpable' => 'Illuminate\\Support\\Traits\\Dumpable',
          'interactswithdata' => 'Illuminate\\Support\\Traits\\InteractsWithData',
          'splfileinfo' => 'SplFileInfo',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'fluent',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '5ebca417f38c5efcf26f7132c4e071c2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'uploadedfile' => 'Illuminate\\Http\\UploadedFile',
          'arr' => 'Illuminate\\Support\\Arr',
          'fluent' => 'Illuminate\\Support\\Fluent',
          'dumpable' => 'Illuminate\\Support\\Traits\\Dumpable',
          'interactswithdata' => 'Illuminate\\Support\\Traits\\InteractsWithData',
          'splfileinfo' => 'SplFileInfo',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'query',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '36790f3de727ba5b236db096dc542a9c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'uploadedfile' => 'Illuminate\\Http\\UploadedFile',
          'arr' => 'Illuminate\\Support\\Arr',
          'fluent' => 'Illuminate\\Support\\Fluent',
          'dumpable' => 'Illuminate\\Support\\Traits\\Dumpable',
          'interactswithdata' => 'Illuminate\\Support\\Traits\\InteractsWithData',
          'splfileinfo' => 'SplFileInfo',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'post',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'cfae59bb13967a4986d8262d86b7223b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'uploadedfile' => 'Illuminate\\Http\\UploadedFile',
          'arr' => 'Illuminate\\Support\\Arr',
          'fluent' => 'Illuminate\\Support\\Fluent',
          'dumpable' => 'Illuminate\\Support\\Traits\\Dumpable',
          'interactswithdata' => 'Illuminate\\Support\\Traits\\InteractsWithData',
          'splfileinfo' => 'SplFileInfo',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'hasCookie',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '999e6f52e82ba68819ccf7a7ad3991d9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'uploadedfile' => 'Illuminate\\Http\\UploadedFile',
          'arr' => 'Illuminate\\Support\\Arr',
          'fluent' => 'Illuminate\\Support\\Fluent',
          'dumpable' => 'Illuminate\\Support\\Traits\\Dumpable',
          'interactswithdata' => 'Illuminate\\Support\\Traits\\InteractsWithData',
          'splfileinfo' => 'SplFileInfo',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'cookie',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '2a90e9d54d4cf7581a325c247d1a60ec' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'uploadedfile' => 'Illuminate\\Http\\UploadedFile',
          'arr' => 'Illuminate\\Support\\Arr',
          'fluent' => 'Illuminate\\Support\\Fluent',
          'dumpable' => 'Illuminate\\Support\\Traits\\Dumpable',
          'interactswithdata' => 'Illuminate\\Support\\Traits\\InteractsWithData',
          'splfileinfo' => 'SplFileInfo',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'allFiles',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '592e9ba469670afbf2f8019379011a23' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'uploadedfile' => 'Illuminate\\Http\\UploadedFile',
          'arr' => 'Illuminate\\Support\\Arr',
          'fluent' => 'Illuminate\\Support\\Fluent',
          'dumpable' => 'Illuminate\\Support\\Traits\\Dumpable',
          'interactswithdata' => 'Illuminate\\Support\\Traits\\InteractsWithData',
          'splfileinfo' => 'SplFileInfo',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'convertUploadedFiles',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'f88620516b7c1ef39bf764ad26e2d759' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'uploadedfile' => 'Illuminate\\Http\\UploadedFile',
          'arr' => 'Illuminate\\Support\\Arr',
          'fluent' => 'Illuminate\\Support\\Fluent',
          'dumpable' => 'Illuminate\\Support\\Traits\\Dumpable',
          'interactswithdata' => 'Illuminate\\Support\\Traits\\InteractsWithData',
          'splfileinfo' => 'SplFileInfo',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'hasFile',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '23472da197d05a16584e360c73cf3ef0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'uploadedfile' => 'Illuminate\\Http\\UploadedFile',
          'arr' => 'Illuminate\\Support\\Arr',
          'fluent' => 'Illuminate\\Support\\Fluent',
          'dumpable' => 'Illuminate\\Support\\Traits\\Dumpable',
          'interactswithdata' => 'Illuminate\\Support\\Traits\\InteractsWithData',
          'splfileinfo' => 'SplFileInfo',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'isValidFile',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '272b24fcd97c330c399bbad0f3f4b012' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'uploadedfile' => 'Illuminate\\Http\\UploadedFile',
          'arr' => 'Illuminate\\Support\\Arr',
          'fluent' => 'Illuminate\\Support\\Fluent',
          'dumpable' => 'Illuminate\\Support\\Traits\\Dumpable',
          'interactswithdata' => 'Illuminate\\Support\\Traits\\InteractsWithData',
          'splfileinfo' => 'SplFileInfo',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'file',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '6388600339b64f76989cb82fac080bd2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'uploadedfile' => 'Illuminate\\Http\\UploadedFile',
          'arr' => 'Illuminate\\Support\\Arr',
          'fluent' => 'Illuminate\\Support\\Fluent',
          'dumpable' => 'Illuminate\\Support\\Traits\\Dumpable',
          'interactswithdata' => 'Illuminate\\Support\\Traits\\InteractsWithData',
          'splfileinfo' => 'SplFileInfo',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'data',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '2cb9a619a0be2885e1e9f63193c6302c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'uploadedfile' => 'Illuminate\\Http\\UploadedFile',
          'arr' => 'Illuminate\\Support\\Arr',
          'fluent' => 'Illuminate\\Support\\Fluent',
          'dumpable' => 'Illuminate\\Support\\Traits\\Dumpable',
          'interactswithdata' => 'Illuminate\\Support\\Traits\\InteractsWithData',
          'splfileinfo' => 'SplFileInfo',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'retrieveItem',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '99926db3e157c0bb404ff196e608a49f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http\\Concerns',
         'uses' => 
        array (
          'uploadedfile' => 'Illuminate\\Http\\UploadedFile',
          'arr' => 'Illuminate\\Support\\Arr',
          'fluent' => 'Illuminate\\Support\\Fluent',
          'dumpable' => 'Illuminate\\Support\\Traits\\Dumpable',
          'interactswithdata' => 'Illuminate\\Support\\Traits\\InteractsWithData',
          'splfileinfo' => 'SplFileInfo',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'dump',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Http\\Concerns\\InteractsWithInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '7b05e85461d2c86a364918f2dde24efe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'closure' => 'Closure',
          'higherorderwhenproxy' => 'Illuminate\\Support\\HigherOrderWhenProxy',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Conditionable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\Conditionable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '84f5005248967d9ac2b27c362058ea29' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'closure' => 'Closure',
          'higherorderwhenproxy' => 'Illuminate\\Support\\HigherOrderWhenProxy',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'when',
         'templatePhpDocNodes' => 
        array (
          'TWhenParameter' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TWhenParameter',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TWhenReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TWhenReturnType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Conditionable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\Conditionable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '1e66fba40bbc47d9d94975d213e3a602' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'closure' => 'Closure',
          'higherorderwhenproxy' => 'Illuminate\\Support\\HigherOrderWhenProxy',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'unless',
         'templatePhpDocNodes' => 
        array (
          'TUnlessParameter' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TUnlessParameter',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TUnlessReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TUnlessReturnType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Conditionable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\Conditionable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '8dd67d66bd388631031f923b6c414e20' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '68c4aa7c6e061fc9dbdb1fee9e8ef7e9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'macro',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '6bfd3c6e36e35435b610e51e99714364' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'mixin',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'a24e22715ffd479c701ce8a7266c108f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'hasMacro',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'bc906d2dea240297a3a56b6f0053f1e8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'flushMacros',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '1365e1fd822509f531fa48c01b4c1cbb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => '__callStatic',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'fbf5a16e866661d0ee57810f6da2064a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => '__call',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php',
          1 => 'Illuminate\\Http\\Request',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '4ff11e115fa5d487f2f4620e8250245b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'capture',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '33d2b09a3e0874923fbbabd03d8156ee' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'instance',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4c730644027c4b44c597a4dda0eae9fd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'method',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2c86ba7e4ce43dd7959c3fb03762591e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'uri',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9686cc120b59b85f5a0d51bfea626fe7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'root',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1d6632d8b319733ea936183dd2246976' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'url',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4416b5d4ce5ba12bd9514d4b664dd666' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'fullUrl',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'af9463c1f500a29222598d70fedc86f7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'fullUrlWithQuery',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '44d7b868cf8833b2188059c74df70b5d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'fullUrlWithoutQuery',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c3c7bb7efcfd9223f38aeef9d7da0e13' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'path',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bfe2f71da7a02b23623d935a50a8dc05' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'decodedPath',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4c72879607136d0e74b91a42c83efb01' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'segment',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b37dfad9ca2a780f1e967389b895b0ac' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'segments',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f2358b4678a6216907072a0b26bbaf91' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'is',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c2ffecff7e762bfff09311065a1480fe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'routeIs',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '047e9dd026e04a06f8929c10c384e2de' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'fullUrlIs',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '714bfad52df75c49792e2dc0dcce35ec' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'host',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '03dd189d8cbc15f934a944c44a427817' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'httpHost',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ec4f4ce255ac11328edeefbffcc5b162' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'schemeAndHttpHost',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '177afe118d16f887f169a27c423fb165' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'ajax',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f6e6ce3dff60e0cdcbdf1b7129fb4475' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'pjax',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fa93a4de994234f6af13911fcf00b0bc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'prefetch',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2e06b6b1e209161425a2ef3f1a1f7888' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'secure',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f7f249b1f09a416f956d6f2098307d88' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'ip',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '24a435395bd239d8a44ef0d9ecf77f58' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'ips',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1f2da50c12e3e323a39a583d0a05b29f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'userAgent',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '85efacb62f7e055ce3c27347ea80fee4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'getAcceptableContentTypes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bf0d8e724607fe390c83d0dd2f64874b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'merge',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8c4b497fb1fccc26bc001bb5cc6efa18' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'mergeIfMissing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '94c59c973107c0107cd6ccd6c088bdf9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'replace',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4c8353e641fd3c2cf3cfe78025b467d3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'get',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cc6cff824ac74d4e3e08fb98b721cc36' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'json',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '908efe10f747df5b36f6b8f0c2752d15' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'getInputSource',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'acd6ce09e7cf4fc23b16d9c1722a3bd3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'createFrom',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '38d28190c13b3bde492d404c10d61e5e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'createFromBase',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3fc4db86b8cd95d852a6b5f6669668f2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'duplicate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd88a82cf94b75640ef8af10b0f6d2127' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'filterFiles',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a31487aa22ec0844666967585c87f23a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'hasSession',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '48c025f70bf3debca9089b1b2292fc0e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'getSession',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '13daa6dbb776e9f0828e9b77cc34eec7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'session',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8403b0d6e966010f7a7683d51bc706f9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'setLaravelSession',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bdfae28780e6c641989f311c6b8c1f8c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'setRequestLocale',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b7f3acf4daff150dc61c9c4fc9439cf6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'setDefaultRequestLocale',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1e970ce2a89f4b0d867ce2b9ff4e5b7f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'user',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a09539d3d051b9d4bb108d99bd19b487' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'route',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b23720cadc25b46bb4b19b21a2bb5242' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'fingerprint',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8ecc040b2c7114b038c9dea9c4f9a976' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'setJson',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9de36537e9e4005bb0a081446a766429' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'getUserResolver',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '11314273434f9010fddaa767ffe6f5fc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'setUserResolver',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ba1de82d1e3e2881678e1265271f80ae' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'getRouteResolver',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dbe501120075370f77e8a53ec62b8241' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'setRouteResolver',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f471d19cba9c9246686ae937dbba277c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'toArray',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2e601f7174b9abfe17f1b85bd1a5369f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'offsetExists',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ea60dbd66182ccd6f8cc1e86de19401c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'offsetGet',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0a50aa3187f0861ba2c2e35915aa192b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'offsetSet',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1b0c4e78adc0d610afc61291fc2c8ddb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => 'offsetUnset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a493599d47705f34ec458f8e7ca61eb1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => '__isset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1b72df3e2c4a7612b57d99231717d62c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Http',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'uri' => 'Illuminate\\Support\\Uri',
          'runtimeexception' => 'RuntimeException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
          'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Illuminate\\Http\\Request',
         'functionName' => '__get',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Http',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'closure' => 'Closure',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'symfonysessiondecorator' => 'Illuminate\\Session\\SymfonySessionDecorator',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'uri' => 'Illuminate\\Support\\Uri',
            'runtimeexception' => 'RuntimeException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'inputbag' => 'Symfony\\Component\\HttpFoundation\\InputBag',
            'symfonyrequest' => 'Symfony\\Component\\HttpFoundation\\Request',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Illuminate\\Http\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Http/Request.php' => 'b588e38f63b4050aeb78e8d0ba90bd5adebba883f5c7391153e457c34e73175d',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Http/Concerns/CanBePrecognitive.php' => '2101e3beeaedb2395ab44547778ccd036de559eaa5a2c1e80095d48cfa5cf64f',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Http/Concerns/InteractsWithContentTypes.php' => '8ba290cbd2c6053ce01911d309804ca267c00340e40903800ead92894460989f',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Http/Concerns/InteractsWithFlashData.php' => 'f1e1cfc096426ec1002825015f43b034aadbb1787391bb1077fb1a7adc3c486d',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Http/Concerns/InteractsWithInput.php' => '7d314f28c3756077b85c2df544d67d844a802e410b17a5186610ad0410c792df',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Support/Traits/Dumpable.php' => '5ee524eba6728c03ac2743fb83643d2178f7a632664167f92d87323c10206ad8',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Support/Traits/InteractsWithData.php' => '5f3e6445359ba821ac7da0fb7cb05a7dcc3e6ed73e5d341237cccf7c570acd3a',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Conditionable/Traits/Conditionable.php' => '5697fdba0acb78ca0b4e122e5c459cd5d97d000ed9b14fed31271cb7ffd44225',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Macroable/Traits/Macroable.php' => '6dd85b1e28b55ebeee678f9ca423dfb8375e1342bc42d8658da6321bdf97b3c0',
    ),
  ),
));