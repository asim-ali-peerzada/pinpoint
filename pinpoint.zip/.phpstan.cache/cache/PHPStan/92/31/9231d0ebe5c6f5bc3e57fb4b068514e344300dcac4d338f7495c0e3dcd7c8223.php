<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../spatie/laravel-package-tools/src/Concerns/PackageServiceProvider/ProcessMigrations.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-1c7fce2a0ed1adbd7a14afcb2eebd488b452977eee725b5c26b9b13170e0e16a-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'spatie\\laravelpackagetools\\concerns\\packageserviceprovider\\processmigrations' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));