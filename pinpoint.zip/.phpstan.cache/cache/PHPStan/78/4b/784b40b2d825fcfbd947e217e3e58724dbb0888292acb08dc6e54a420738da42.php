<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Modifiers.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      '8588bf2c3596e3437e838990822de337' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c00f60ba1ac219c5315a9a89cf37d8b5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'getMidDayAt',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e227cbee2b6ad289d690e092cae9ba2c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'setMidDayAt',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a4f5236cdb5be9f25d1c4fb27b1a3ae0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'midDay',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a230bdb4dc3812f00c9c0a3b08af24fb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'next',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ebaf3d6e1aa02a12eb69ecc87999272c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'nextOrPreviousDay',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a3f64119031571041f1f53a697383cc5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'nextWeekday',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c1af8dd7e076fe5457c55b1655a30996' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'previousWeekday',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cb0e8ebe1baf6b58bd23d8842823b95a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'nextWeekendDay',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '61994ee2a6a48df52a27100dfce4cd7d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'previousWeekendDay',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8b31e2fd1385dae1f5863ef7c4916de3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'previous',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '04ea315e10f9d02265e29cad0ba98523' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'firstOfMonth',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cf314800d4c65f7a84f14c6cda20fd7f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'lastOfMonth',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1fe51480e9104cbc1a5e6b927f750d86' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'nthOfMonth',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e322f3866183070a85484bd7f69d7eb3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'firstOfQuarter',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5355100ebd38f29744a35a3bacaf6a27' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'lastOfQuarter',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8903b1b961b593dcfd152c704f23bc6a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'nthOfQuarter',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1fad9db566b10591151a036f4c18ac22' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'firstOfYear',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd1f0081f2165b51100a6c1fb924f7e18' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'lastOfYear',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e35188f21095616ef1089174cb4a7ac9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'nthOfYear',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6c834f5dded9831d256a874f230427b8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'average',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '906b164b548c0a1be50e84868d1ccfdd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'closest',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1236eed2eff8cc8bdd06dcaefcfb482e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'farthest',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6fc2215f9a7a5b96be7177ca85ca22b5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'min',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '97dfd9f9107e87e56f45f37af1e9b848' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'minimum',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8edf4ec90c55da06deefca3b48ba2ab2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'max',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'df9b071ddc861516a7bbac5f7b1cf267' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'maximum',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8736baeaa7bbf23295e7f910ed033fed' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'modify',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8d478b96124cce8a282aed2d62796278' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Modifiers',
         'functionName' => 'change',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Modifiers',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Modifiers.php' => '3fa3b46a794e51ec6c6a84090c21a84103986d34c130a36cf56d96181bff839f',
    ),
  ),
));