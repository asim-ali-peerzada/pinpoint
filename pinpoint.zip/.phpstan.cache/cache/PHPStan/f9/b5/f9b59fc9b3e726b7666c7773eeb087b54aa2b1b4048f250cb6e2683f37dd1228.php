<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Foundation/Application.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-cc6f9f5d2d6e9a0bfbcf6412e5e721082c618b01ade4a675bbb016d8d523a8ba-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\foundation\\application' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));