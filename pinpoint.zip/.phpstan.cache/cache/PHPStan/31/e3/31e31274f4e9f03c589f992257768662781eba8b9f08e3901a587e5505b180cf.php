<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Contracts/Container/Container.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-cca1c6c4c50aa8bf7007e786cde473cc9bab83317367f384ab711a0c4d305611-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\contracts\\container\\container' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));