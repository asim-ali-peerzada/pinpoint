<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas/src/Console/JobMiddlewareMakeCommand.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-b09e403a70750596b80832fad8643eec3132c3cad3b4794f8d29e8430097c99f-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'orchestra\\canvas\\console\\jobmiddlewaremakecommand' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));