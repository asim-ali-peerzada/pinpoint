<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/ConnectionInterface.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      'fefbe0cb0b5a27f72ce634fba79fd913' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Illuminate\\Database\\ConnectionInterface',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '46b3de3e557b3fc97ce994469ff2e5c7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Illuminate\\Database\\ConnectionInterface',
         'functionName' => 'table',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c1263492f5768f8acc6cda5fb04fcd53' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Illuminate\\Database\\ConnectionInterface',
         'functionName' => 'raw',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '45ebedc6b95e6d3cdf4f47fc6f4904bc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Illuminate\\Database\\ConnectionInterface',
         'functionName' => 'selectOne',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c1b38bf033f094626b84c821c56f753d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Illuminate\\Database\\ConnectionInterface',
         'functionName' => 'scalar',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd3848155dba2ba29864fa1f1991db320' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Illuminate\\Database\\ConnectionInterface',
         'functionName' => 'select',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd42ae9fc6af2760f48f84410ef60e72c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Illuminate\\Database\\ConnectionInterface',
         'functionName' => 'cursor',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a31301bae7f05230fe07341a85301621' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Illuminate\\Database\\ConnectionInterface',
         'functionName' => 'insert',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b97091c2fc296ba0bb7681374af40d07' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Illuminate\\Database\\ConnectionInterface',
         'functionName' => 'update',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1ba77041e9624c33a809cd35384e0976' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Illuminate\\Database\\ConnectionInterface',
         'functionName' => 'delete',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f00138b86042cae0b8245306482177b2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Illuminate\\Database\\ConnectionInterface',
         'functionName' => 'statement',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a3e3194db5c5a88d91638b58020117df' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Illuminate\\Database\\ConnectionInterface',
         'functionName' => 'affectingStatement',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c71cbb4f43f085909a6e32bec9a54019' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Illuminate\\Database\\ConnectionInterface',
         'functionName' => 'unprepared',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3a7751c05636f43e972d40ee44b1f895' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Illuminate\\Database\\ConnectionInterface',
         'functionName' => 'prepareBindings',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e0e717fa9b998239458cbbdecd4659e5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Illuminate\\Database\\ConnectionInterface',
         'functionName' => 'transaction',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8a977fb93c50cc08df4a27330d243d1b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Illuminate\\Database\\ConnectionInterface',
         'functionName' => 'beginTransaction',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd335eaf9884ec0ffcb1a5bd5c5c9bd75' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Illuminate\\Database\\ConnectionInterface',
         'functionName' => 'commit',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '928b0fc3921dd1600835ec90611e5a3b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Illuminate\\Database\\ConnectionInterface',
         'functionName' => 'rollBack',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ab9d8a0beebf519b506180fed84635b1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Illuminate\\Database\\ConnectionInterface',
         'functionName' => 'transactionLevel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '425497237698f74ffb06dc62ae23c043' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Illuminate\\Database\\ConnectionInterface',
         'functionName' => 'pretend',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '98f6c4ecb2c6b3a969f254138eda55ed' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database',
         'uses' => 
        array (
          'closure' => 'Closure',
        ),
         'className' => 'Illuminate\\Database\\ConnectionInterface',
         'functionName' => 'getDatabaseName',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/ConnectionInterface.php' => 'aceabb60c5981e112df68e645e776fb8e99f13b4178dc54263460c4efee52c8c',
    ),
  ),
));