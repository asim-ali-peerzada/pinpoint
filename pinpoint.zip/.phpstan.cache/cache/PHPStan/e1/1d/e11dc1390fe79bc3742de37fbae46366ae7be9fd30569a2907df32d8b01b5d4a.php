<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas/src/Console/PolicyMakeCommand.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-615a66b029310f3d44ca3d9682708321db39835814f2256eae42aeb6285ed34d-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'orchestra\\canvas\\console\\policymakecommand' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));