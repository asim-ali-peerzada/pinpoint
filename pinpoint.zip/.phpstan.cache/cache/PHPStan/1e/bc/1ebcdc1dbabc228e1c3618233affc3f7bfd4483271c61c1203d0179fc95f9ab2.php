<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Contracts/Foundation/CachesRoutes.php-PHPStan\BetterReflection\Reflection\ReflectionClass-Illuminate\Contracts\Foundation\CachesRoutes
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-cf84a535d1626958461e4ed9e4545c6758dce92a1c1800c0612f43d88123762c-8.2.33-6.70.0.3',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'Illuminate\\Contracts\\Foundation\\CachesRoutes',
        'filename' => '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Contracts/Foundation/CachesRoutes.php',
      ),
    ),
    'namespace' => 'Illuminate\\Contracts\\Foundation',
    'name' => 'Illuminate\\Contracts\\Foundation\\CachesRoutes',
    'shortName' => 'CachesRoutes',
    'isInterface' => true,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 0,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 5,
    'endLine' => 20,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => NULL,
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      'routesAreCached' => 
      array (
        'name' => 'routesAreCached',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Determine if the application routes are cached.
 *
 * @return bool
 */',
        'startLine' => 12,
        'endLine' => 12,
        'startColumn' => 5,
        'endColumn' => 38,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Illuminate\\Contracts\\Foundation',
        'declaringClassName' => 'Illuminate\\Contracts\\Foundation\\CachesRoutes',
        'implementingClassName' => 'Illuminate\\Contracts\\Foundation\\CachesRoutes',
        'currentClassName' => 'Illuminate\\Contracts\\Foundation\\CachesRoutes',
        'aliasName' => NULL,
      ),
      'getCachedRoutesPath' => 
      array (
        'name' => 'getCachedRoutesPath',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Get the path to the routes cache file.
 *
 * @return string
 */',
        'startLine' => 19,
        'endLine' => 19,
        'startColumn' => 5,
        'endColumn' => 42,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Illuminate\\Contracts\\Foundation',
        'declaringClassName' => 'Illuminate\\Contracts\\Foundation\\CachesRoutes',
        'implementingClassName' => 'Illuminate\\Contracts\\Foundation\\CachesRoutes',
        'currentClassName' => 'Illuminate\\Contracts\\Foundation\\CachesRoutes',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));