<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../symfony/console/Command/CompleteCommand.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-58776175bda3280dc286eeabb3645a502f660fdaf468806417ef11acf9f0808e-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'symfony\\component\\console\\command\\completecommand' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));