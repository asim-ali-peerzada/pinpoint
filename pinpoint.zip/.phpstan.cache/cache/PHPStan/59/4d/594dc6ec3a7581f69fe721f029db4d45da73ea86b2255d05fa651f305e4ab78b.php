<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Database/Console/Migrations/InstallCommand.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6018a1e1605f8a2cda537bbf172182a45d92f540c7a7f8f36730dce4d3599fbf-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\database\\console\\migrations\\installcommand' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));