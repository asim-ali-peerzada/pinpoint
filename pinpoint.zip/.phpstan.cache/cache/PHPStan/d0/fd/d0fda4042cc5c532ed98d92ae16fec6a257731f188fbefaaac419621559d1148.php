<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Macro.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      '6bffdea5ed660f0c8283510cf5971aa1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
        ),
         'className' => 'Carbon\\Traits\\Macro',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0647ac9fd74cc5b09139ca733513af7a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'carbonperiod' => 'Carbon\\CarbonPeriod',
          'closure' => 'Closure',
          'generator' => 'Generator',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionmethod' => 'ReflectionMethod',
          'reflectionnamedtype' => 'ReflectionNamedType',
          'throwable' => 'Throwable',
        ),
         'className' => 'Carbon\\Traits\\Macro',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Carbon\\Traits\\Mixin',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Macro.php',
          1 => 'Carbon\\Traits\\Macro',
          2 => 'Carbon\\Traits\\Mixin',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '8fd7fb05a6d935dada42f65effa25099' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'carbonperiod' => 'Carbon\\CarbonPeriod',
          'closure' => 'Closure',
          'generator' => 'Generator',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionmethod' => 'ReflectionMethod',
          'reflectionnamedtype' => 'ReflectionNamedType',
          'throwable' => 'Throwable',
        ),
         'className' => 'Carbon\\Traits\\Macro',
         'functionName' => 'mixin',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'carbonperiod' => 'Carbon\\CarbonPeriod',
            'closure' => 'Closure',
            'generator' => 'Generator',
            'reflectionclass' => 'ReflectionClass',
            'reflectionexception' => 'ReflectionException',
            'reflectionmethod' => 'ReflectionMethod',
            'reflectionnamedtype' => 'ReflectionNamedType',
            'throwable' => 'Throwable',
          ),
           'className' => 'Carbon\\Traits\\Macro',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Carbon\\Traits\\Mixin',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Carbon\\Traits\\Mixin',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Macro.php',
          1 => 'Carbon\\Traits\\Macro',
          2 => 'Carbon\\Traits\\Mixin',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '6beb6f6abdbd7af0e607502ebfbf7e85' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'carbonperiod' => 'Carbon\\CarbonPeriod',
          'closure' => 'Closure',
          'generator' => 'Generator',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionmethod' => 'ReflectionMethod',
          'reflectionnamedtype' => 'ReflectionNamedType',
          'throwable' => 'Throwable',
        ),
         'className' => 'Carbon\\Traits\\Macro',
         'functionName' => 'loadMixinClass',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'carbonperiod' => 'Carbon\\CarbonPeriod',
            'closure' => 'Closure',
            'generator' => 'Generator',
            'reflectionclass' => 'ReflectionClass',
            'reflectionexception' => 'ReflectionException',
            'reflectionmethod' => 'ReflectionMethod',
            'reflectionnamedtype' => 'ReflectionNamedType',
            'throwable' => 'Throwable',
          ),
           'className' => 'Carbon\\Traits\\Macro',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Carbon\\Traits\\Mixin',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Carbon\\Traits\\Mixin',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Macro.php',
          1 => 'Carbon\\Traits\\Macro',
          2 => 'Carbon\\Traits\\Mixin',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '0a88d95e2d45c0cd658f5a0cfcaa92f0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'carbonperiod' => 'Carbon\\CarbonPeriod',
          'closure' => 'Closure',
          'generator' => 'Generator',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionmethod' => 'ReflectionMethod',
          'reflectionnamedtype' => 'ReflectionNamedType',
          'throwable' => 'Throwable',
        ),
         'className' => 'Carbon\\Traits\\Macro',
         'functionName' => 'cannotBeAMixinMethod',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'carbonperiod' => 'Carbon\\CarbonPeriod',
            'closure' => 'Closure',
            'generator' => 'Generator',
            'reflectionclass' => 'ReflectionClass',
            'reflectionexception' => 'ReflectionException',
            'reflectionmethod' => 'ReflectionMethod',
            'reflectionnamedtype' => 'ReflectionNamedType',
            'throwable' => 'Throwable',
          ),
           'className' => 'Carbon\\Traits\\Macro',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Carbon\\Traits\\Mixin',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Carbon\\Traits\\Mixin',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Macro.php',
          1 => 'Carbon\\Traits\\Macro',
          2 => 'Carbon\\Traits\\Mixin',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '987dbf8d4f309b4f19784008ba8616a7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'carbonperiod' => 'Carbon\\CarbonPeriod',
          'closure' => 'Closure',
          'generator' => 'Generator',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionmethod' => 'ReflectionMethod',
          'reflectionnamedtype' => 'ReflectionNamedType',
          'throwable' => 'Throwable',
        ),
         'className' => 'Carbon\\Traits\\Macro',
         'functionName' => 'loadMixinTrait',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'carbonperiod' => 'Carbon\\CarbonPeriod',
            'closure' => 'Closure',
            'generator' => 'Generator',
            'reflectionclass' => 'ReflectionClass',
            'reflectionexception' => 'ReflectionException',
            'reflectionmethod' => 'ReflectionMethod',
            'reflectionnamedtype' => 'ReflectionNamedType',
            'throwable' => 'Throwable',
          ),
           'className' => 'Carbon\\Traits\\Macro',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Carbon\\Traits\\Mixin',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Carbon\\Traits\\Mixin',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Macro.php',
          1 => 'Carbon\\Traits\\Macro',
          2 => 'Carbon\\Traits\\Mixin',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'c847548144650fc17d426a00cdc45b1c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'carbonperiod' => 'Carbon\\CarbonPeriod',
          'closure' => 'Closure',
          'generator' => 'Generator',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionmethod' => 'ReflectionMethod',
          'reflectionnamedtype' => 'ReflectionNamedType',
          'throwable' => 'Throwable',
        ),
         'className' => 'Carbon\\Traits\\Macro',
         'functionName' => 'getAnonymousClassCodeForTrait',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'carbonperiod' => 'Carbon\\CarbonPeriod',
            'closure' => 'Closure',
            'generator' => 'Generator',
            'reflectionclass' => 'ReflectionClass',
            'reflectionexception' => 'ReflectionException',
            'reflectionmethod' => 'ReflectionMethod',
            'reflectionnamedtype' => 'ReflectionNamedType',
            'throwable' => 'Throwable',
          ),
           'className' => 'Carbon\\Traits\\Macro',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Carbon\\Traits\\Mixin',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Carbon\\Traits\\Mixin',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Macro.php',
          1 => 'Carbon\\Traits\\Macro',
          2 => 'Carbon\\Traits\\Mixin',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'f59e88102eca50e51def45c37dac7d99' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'carbonperiod' => 'Carbon\\CarbonPeriod',
          'closure' => 'Closure',
          'generator' => 'Generator',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionmethod' => 'ReflectionMethod',
          'reflectionnamedtype' => 'ReflectionNamedType',
          'throwable' => 'Throwable',
        ),
         'className' => 'Carbon\\Traits\\Macro',
         'functionName' => 'getMixableMethods',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'carbonperiod' => 'Carbon\\CarbonPeriod',
            'closure' => 'Closure',
            'generator' => 'Generator',
            'reflectionclass' => 'ReflectionClass',
            'reflectionexception' => 'ReflectionException',
            'reflectionmethod' => 'ReflectionMethod',
            'reflectionnamedtype' => 'ReflectionNamedType',
            'throwable' => 'Throwable',
          ),
           'className' => 'Carbon\\Traits\\Macro',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Carbon\\Traits\\Mixin',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Carbon\\Traits\\Mixin',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Macro.php',
          1 => 'Carbon\\Traits\\Macro',
          2 => 'Carbon\\Traits\\Mixin',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '8a45a512f8d288c61944b953e6a83b4f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'carbonperiod' => 'Carbon\\CarbonPeriod',
          'closure' => 'Closure',
          'generator' => 'Generator',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionmethod' => 'ReflectionMethod',
          'reflectionnamedtype' => 'ReflectionNamedType',
          'throwable' => 'Throwable',
        ),
         'className' => 'Carbon\\Traits\\Macro',
         'functionName' => 'bindMacroContext',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'carbonperiod' => 'Carbon\\CarbonPeriod',
            'closure' => 'Closure',
            'generator' => 'Generator',
            'reflectionclass' => 'ReflectionClass',
            'reflectionexception' => 'ReflectionException',
            'reflectionmethod' => 'ReflectionMethod',
            'reflectionnamedtype' => 'ReflectionNamedType',
            'throwable' => 'Throwable',
          ),
           'className' => 'Carbon\\Traits\\Macro',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Carbon\\Traits\\Mixin',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Carbon\\Traits\\Mixin',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Macro.php',
          1 => 'Carbon\\Traits\\Macro',
          2 => 'Carbon\\Traits\\Mixin',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'ccccbc9e8a20995ecb9f0f5a9e1a2459' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'carbonperiod' => 'Carbon\\CarbonPeriod',
          'closure' => 'Closure',
          'generator' => 'Generator',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionmethod' => 'ReflectionMethod',
          'reflectionnamedtype' => 'ReflectionNamedType',
          'throwable' => 'Throwable',
        ),
         'className' => 'Carbon\\Traits\\Macro',
         'functionName' => 'context',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'carbonperiod' => 'Carbon\\CarbonPeriod',
            'closure' => 'Closure',
            'generator' => 'Generator',
            'reflectionclass' => 'ReflectionClass',
            'reflectionexception' => 'ReflectionException',
            'reflectionmethod' => 'ReflectionMethod',
            'reflectionnamedtype' => 'ReflectionNamedType',
            'throwable' => 'Throwable',
          ),
           'className' => 'Carbon\\Traits\\Macro',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Carbon\\Traits\\Mixin',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Carbon\\Traits\\Mixin',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Macro.php',
          1 => 'Carbon\\Traits\\Macro',
          2 => 'Carbon\\Traits\\Mixin',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '70fe6a95a5015b715ceed5422391f735' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'carbonperiod' => 'Carbon\\CarbonPeriod',
          'closure' => 'Closure',
          'generator' => 'Generator',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionmethod' => 'ReflectionMethod',
          'reflectionnamedtype' => 'ReflectionNamedType',
          'throwable' => 'Throwable',
        ),
         'className' => 'Carbon\\Traits\\Macro',
         'functionName' => 'this',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'carbonperiod' => 'Carbon\\CarbonPeriod',
            'closure' => 'Closure',
            'generator' => 'Generator',
            'reflectionclass' => 'ReflectionClass',
            'reflectionexception' => 'ReflectionException',
            'reflectionmethod' => 'ReflectionMethod',
            'reflectionnamedtype' => 'ReflectionNamedType',
            'throwable' => 'Throwable',
          ),
           'className' => 'Carbon\\Traits\\Macro',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Carbon\\Traits\\Mixin',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Carbon\\Traits\\Mixin',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Macro.php',
          1 => 'Carbon\\Traits\\Macro',
          2 => 'Carbon\\Traits\\Mixin',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'c0507bb57a9492ccbf0124b9a25a12e0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
        ),
         'className' => 'Carbon\\Traits\\Macro',
         'functionName' => 'macro',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
          ),
           'className' => 'Carbon\\Traits\\Macro',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bd066705b13a37ae7ad0875e22f9fa30' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
        ),
         'className' => 'Carbon\\Traits\\Macro',
         'functionName' => 'resetMacros',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
          ),
           'className' => 'Carbon\\Traits\\Macro',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '76c459231a6170f7abcafa3e72cff3bd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
        ),
         'className' => 'Carbon\\Traits\\Macro',
         'functionName' => 'genericMacro',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
          ),
           'className' => 'Carbon\\Traits\\Macro',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '46868181d7b4c13f473a9f4ca0f1b6db' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
        ),
         'className' => 'Carbon\\Traits\\Macro',
         'functionName' => 'hasMacro',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
          ),
           'className' => 'Carbon\\Traits\\Macro',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3beaff6bd6b34ba063d0f38bb0e7219d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
        ),
         'className' => 'Carbon\\Traits\\Macro',
         'functionName' => 'getMacro',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
          ),
           'className' => 'Carbon\\Traits\\Macro',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd7b52b3cbe5f17e71b9362240d9457b2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
        ),
         'className' => 'Carbon\\Traits\\Macro',
         'functionName' => 'hasLocalMacro',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
          ),
           'className' => 'Carbon\\Traits\\Macro',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ec85d551d685f589a2fd9b697f017b5c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
        ),
         'className' => 'Carbon\\Traits\\Macro',
         'functionName' => 'getLocalMacro',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
          ),
           'className' => 'Carbon\\Traits\\Macro',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Macro.php' => 'a253f4e36273051bae4f0c17c9975c51132a757b02eb53645dff0978c0ea5bf5',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../nesbot/carbon/src/Carbon/Traits/Mixin.php' => '5491a7cc283a03fb2240d193acfab173081a4e4132b9c805aac34771d5a89fb6',
    ),
  ),
));