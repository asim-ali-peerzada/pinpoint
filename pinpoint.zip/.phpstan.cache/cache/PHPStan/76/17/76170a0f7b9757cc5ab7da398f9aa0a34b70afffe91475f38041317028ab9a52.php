<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Database/Connection.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-3b2e18c30ca187936cd0d936c1523622316b60cc7e419e48702bcb623e1b089b-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\database\\connection' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));