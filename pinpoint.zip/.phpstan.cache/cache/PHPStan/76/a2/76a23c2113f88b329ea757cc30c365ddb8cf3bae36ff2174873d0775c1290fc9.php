<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Translation/Translator.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-818a412ee2cbe3389ee786654d6b1dde2e822701658da48781157f098775322f-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\translation\\translator' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));