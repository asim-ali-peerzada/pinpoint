<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Rounding.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      '0883876f8bdf7c3910ee84806eb61925' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'unknownunitexception' => 'Carbon\\Exceptions\\UnknownUnitException',
          'weekday' => 'Carbon\\WeekDay',
          'dateinterval' => 'DateInterval',
        ),
         'className' => 'Carbon\\Traits\\Rounding',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9e524b80d5b681b084a083afb93131d3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'dateinterval' => 'DateInterval',
        ),
         'className' => 'Carbon\\Traits\\Rounding',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Carbon\\Traits\\IntervalRounding',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Rounding.php',
          1 => 'Carbon\\Traits\\Rounding',
          2 => 'Carbon\\Traits\\IntervalRounding',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '7fa07e213f47c955ebf51cb240338c5e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'dateinterval' => 'DateInterval',
        ),
         'className' => 'Carbon\\Traits\\Rounding',
         'functionName' => 'callRoundMethod',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterval' => 'Carbon\\CarbonInterval',
            'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
            'dateinterval' => 'DateInterval',
          ),
           'className' => 'Carbon\\Traits\\Rounding',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Carbon\\Traits\\IntervalRounding',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Carbon\\Traits\\IntervalRounding',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Rounding.php',
          1 => 'Carbon\\Traits\\Rounding',
          2 => 'Carbon\\Traits\\IntervalRounding',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '73769ba753a81e4ac94b2d4e9782d882' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'dateinterval' => 'DateInterval',
        ),
         'className' => 'Carbon\\Traits\\Rounding',
         'functionName' => 'roundWith',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterval' => 'Carbon\\CarbonInterval',
            'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
            'dateinterval' => 'DateInterval',
          ),
           'className' => 'Carbon\\Traits\\Rounding',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Carbon\\Traits\\IntervalRounding',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Carbon\\Traits\\IntervalRounding',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Rounding.php',
          1 => 'Carbon\\Traits\\Rounding',
          2 => 'Carbon\\Traits\\IntervalRounding',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '57e0ec39425be87c16c5c2bf0a51a2b7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'unknownunitexception' => 'Carbon\\Exceptions\\UnknownUnitException',
          'weekday' => 'Carbon\\WeekDay',
          'dateinterval' => 'DateInterval',
        ),
         'className' => 'Carbon\\Traits\\Rounding',
         'functionName' => 'roundUnit',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'unknownunitexception' => 'Carbon\\Exceptions\\UnknownUnitException',
            'weekday' => 'Carbon\\WeekDay',
            'dateinterval' => 'DateInterval',
          ),
           'className' => 'Carbon\\Traits\\Rounding',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'da9ced0d2b25e994fabcb89c31e72ef1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'unknownunitexception' => 'Carbon\\Exceptions\\UnknownUnitException',
          'weekday' => 'Carbon\\WeekDay',
          'dateinterval' => 'DateInterval',
        ),
         'className' => 'Carbon\\Traits\\Rounding',
         'functionName' => 'floorUnit',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'unknownunitexception' => 'Carbon\\Exceptions\\UnknownUnitException',
            'weekday' => 'Carbon\\WeekDay',
            'dateinterval' => 'DateInterval',
          ),
           'className' => 'Carbon\\Traits\\Rounding',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f398036e3b2216a4b225df0c8c37758b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'unknownunitexception' => 'Carbon\\Exceptions\\UnknownUnitException',
          'weekday' => 'Carbon\\WeekDay',
          'dateinterval' => 'DateInterval',
        ),
         'className' => 'Carbon\\Traits\\Rounding',
         'functionName' => 'ceilUnit',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'unknownunitexception' => 'Carbon\\Exceptions\\UnknownUnitException',
            'weekday' => 'Carbon\\WeekDay',
            'dateinterval' => 'DateInterval',
          ),
           'className' => 'Carbon\\Traits\\Rounding',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '753bbf9e5e011235a1db91ad5577de20' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'unknownunitexception' => 'Carbon\\Exceptions\\UnknownUnitException',
          'weekday' => 'Carbon\\WeekDay',
          'dateinterval' => 'DateInterval',
        ),
         'className' => 'Carbon\\Traits\\Rounding',
         'functionName' => 'round',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'unknownunitexception' => 'Carbon\\Exceptions\\UnknownUnitException',
            'weekday' => 'Carbon\\WeekDay',
            'dateinterval' => 'DateInterval',
          ),
           'className' => 'Carbon\\Traits\\Rounding',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '843da8724238d4492780bdd8872b1eab' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'unknownunitexception' => 'Carbon\\Exceptions\\UnknownUnitException',
          'weekday' => 'Carbon\\WeekDay',
          'dateinterval' => 'DateInterval',
        ),
         'className' => 'Carbon\\Traits\\Rounding',
         'functionName' => 'floor',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'unknownunitexception' => 'Carbon\\Exceptions\\UnknownUnitException',
            'weekday' => 'Carbon\\WeekDay',
            'dateinterval' => 'DateInterval',
          ),
           'className' => 'Carbon\\Traits\\Rounding',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd7661d97a4a7c42ea24788720b42fcba' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'unknownunitexception' => 'Carbon\\Exceptions\\UnknownUnitException',
          'weekday' => 'Carbon\\WeekDay',
          'dateinterval' => 'DateInterval',
        ),
         'className' => 'Carbon\\Traits\\Rounding',
         'functionName' => 'ceil',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'unknownunitexception' => 'Carbon\\Exceptions\\UnknownUnitException',
            'weekday' => 'Carbon\\WeekDay',
            'dateinterval' => 'DateInterval',
          ),
           'className' => 'Carbon\\Traits\\Rounding',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4c1f47853adc178fdf13f02bb75209fe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'unknownunitexception' => 'Carbon\\Exceptions\\UnknownUnitException',
          'weekday' => 'Carbon\\WeekDay',
          'dateinterval' => 'DateInterval',
        ),
         'className' => 'Carbon\\Traits\\Rounding',
         'functionName' => 'roundWeek',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'unknownunitexception' => 'Carbon\\Exceptions\\UnknownUnitException',
            'weekday' => 'Carbon\\WeekDay',
            'dateinterval' => 'DateInterval',
          ),
           'className' => 'Carbon\\Traits\\Rounding',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4c2b34295a60ca11b9aaa62ff415dd30' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'unknownunitexception' => 'Carbon\\Exceptions\\UnknownUnitException',
          'weekday' => 'Carbon\\WeekDay',
          'dateinterval' => 'DateInterval',
        ),
         'className' => 'Carbon\\Traits\\Rounding',
         'functionName' => 'floorWeek',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'unknownunitexception' => 'Carbon\\Exceptions\\UnknownUnitException',
            'weekday' => 'Carbon\\WeekDay',
            'dateinterval' => 'DateInterval',
          ),
           'className' => 'Carbon\\Traits\\Rounding',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '910984875a611b596c6d9dadb9ef950e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'unknownunitexception' => 'Carbon\\Exceptions\\UnknownUnitException',
          'weekday' => 'Carbon\\WeekDay',
          'dateinterval' => 'DateInterval',
        ),
         'className' => 'Carbon\\Traits\\Rounding',
         'functionName' => 'ceilWeek',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'unknownunitexception' => 'Carbon\\Exceptions\\UnknownUnitException',
            'weekday' => 'Carbon\\WeekDay',
            'dateinterval' => 'DateInterval',
          ),
           'className' => 'Carbon\\Traits\\Rounding',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Rounding.php' => '474a533e3a57c186a311e718357172b69c14f248b61ea9445334e1e78429d1bd',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../nesbot/carbon/src/Carbon/Traits/IntervalRounding.php' => 'f8aa8b67c35ba4c9a2dd49784f246a1cecd2c8fb179c69934ddc5dd3a64f17b0',
    ),
  ),
));