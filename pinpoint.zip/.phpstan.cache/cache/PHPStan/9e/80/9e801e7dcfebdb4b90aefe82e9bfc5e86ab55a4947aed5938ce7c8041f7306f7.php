<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Foundation/Console/StorageUnlinkCommand.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-db76f211092f0ede12849edd8263a3dc98a0fbf9fa53f0949dfc2717e547bc79-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\foundation\\console\\storageunlinkcommand' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));