<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../nesbot/carbon/src/Carbon/Carbon.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-04c14b487d33a16b4b10b54504e8261938747e0e3b1942f4b23ff4d4bb378d36-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'carbon\\carbon' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));