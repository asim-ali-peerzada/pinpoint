<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../nesbot/carbon/src/Carbon/Exceptions/UnknownMethodException.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-be02a24bd457383e696c54fcd9942a50af9d4d81f547a892175da2c8a1bdace3-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'carbon\\exceptions\\unknownmethodexception' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));