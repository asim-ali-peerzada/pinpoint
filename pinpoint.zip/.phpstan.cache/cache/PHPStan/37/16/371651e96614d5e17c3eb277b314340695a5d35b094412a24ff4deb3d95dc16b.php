<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Support/Stringable.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-79f330caf378e97b50615918178e3ef57d7f56330bb29d12e41ca3ad729a0f58-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\support\\stringable' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));