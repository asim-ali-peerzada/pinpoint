<?php declare(strict_types = 1);

// odsl-/mnt/workspace/Personal-Projects/sentinel/src/PinpointServiceProvider.php-PHPStan\BetterReflection\Reflection\ReflectionClass-AsimAli\Pinpoint\PinpointServiceProvider
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.3-8.2.33-957d231797feb59873d9e612fd33226fb5e93bf36a83aa2dea63e75618fe08ec',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'filename' => '/mnt/workspace/Personal-Projects/sentinel/src/PinpointServiceProvider.php',
      ),
    ),
    'namespace' => 'AsimAli\\Pinpoint',
    'name' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
    'shortName' => 'PinpointServiceProvider',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 0,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 18,
    'endLine' => 158,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => 'Spatie\\LaravelPackageTools\\PackageServiceProvider',
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
      'startedAt' => 
      array (
        'declaringClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'implementingClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'name' => 'startedAt',
        'modifiers' => 2,
        'type' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'float',
            'isIdentifier' => true,
          ),
        ),
        'default' => NULL,
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 20,
        'endLine' => 20,
        'startColumn' => 5,
        'endColumn' => 31,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
    ),
    'immediateMethods' => 
    array (
      'configurePackage' => 
      array (
        'name' => 'configurePackage',
        'parameters' => 
        array (
          'package' => 
          array (
            'name' => 'package',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'Spatie\\LaravelPackageTools\\Package',
                'isIdentifier' => false,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 22,
            'endLine' => 22,
            'startColumn' => 38,
            'endColumn' => 53,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 22,
        'endLine' => 36,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'AsimAli\\Pinpoint',
        'declaringClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'implementingClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'currentClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'aliasName' => NULL,
      ),
      'registeringPackage' => 
      array (
        'name' => 'registeringPackage',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 38,
        'endLine' => 43,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'AsimAli\\Pinpoint',
        'declaringClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'implementingClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'currentClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'aliasName' => NULL,
      ),
      'bootingPackage' => 
      array (
        'name' => 'bootingPackage',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 45,
        'endLine' => 50,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'AsimAli\\Pinpoint',
        'declaringClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'implementingClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'currentClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'aliasName' => NULL,
      ),
      'registerQueryListener' => 
      array (
        'name' => 'registerQueryListener',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 52,
        'endLine' => 72,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'AsimAli\\Pinpoint',
        'declaringClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'implementingClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'currentClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'aliasName' => NULL,
      ),
      'registerRequestListener' => 
      array (
        'name' => 'registerRequestListener',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 74,
        'endLine' => 110,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'AsimAli\\Pinpoint',
        'declaringClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'implementingClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'currentClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'aliasName' => NULL,
      ),
      'registerLazyLoadingObserver' => 
      array (
        'name' => 'registerLazyLoadingObserver',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Auto-chain: captures whatever handler already exists at boot time via
 * Reflection (there\'s no public getter for this property) and calls it
 * after recording. Reflection can\'t fix the reverse direction (a handler
 * registered in a provider booting *after* ours overwrites us) — apps in
 * that situation should call Pinpoint::observeLazyLoad() in their handler.
 */',
        'startLine' => 119,
        'endLine' => 140,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'AsimAli\\Pinpoint',
        'declaringClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'implementingClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'currentClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'aliasName' => NULL,
      ),
      'requestStart' => 
      array (
        'name' => 'requestStart',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'float',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 142,
        'endLine' => 145,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'AsimAli\\Pinpoint',
        'declaringClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'implementingClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'currentClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'aliasName' => NULL,
      ),
      'currentLazyLoadingCallback' => 
      array (
        'name' => 'currentLazyLoadingCallback',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionUnionType',
          'data' => 
          array (
            'types' => 
            array (
              0 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'callable',
                  'isIdentifier' => true,
                ),
              ),
              1 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'null',
                  'isIdentifier' => true,
                ),
              ),
            ),
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 147,
        'endLine' => 157,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'AsimAli\\Pinpoint',
        'declaringClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'implementingClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'currentClassName' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));