<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas/src/Console/ChannelMakeCommand.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-28fa535be30420a37b669c6111294b0c8e48e32dfd5ac5a9c7b9151f1566e33e-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'orchestra\\canvas\\console\\channelmakecommand' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));