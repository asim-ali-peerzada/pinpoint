<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Http/Concerns/InteractsWithInput.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-7d314f28c3756077b85c2df544d67d844a802e410b17a5186610ad0410c792df-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\http\\concerns\\interactswithinput' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));