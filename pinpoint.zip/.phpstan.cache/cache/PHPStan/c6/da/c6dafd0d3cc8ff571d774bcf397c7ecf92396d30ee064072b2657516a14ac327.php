<?php declare(strict_types = 1);

// odsl-/mnt/workspace/Personal-Projects/sentinel/src/Facades/Pinpoint.php-PHPStan\BetterReflection\Reflection\ReflectionClass-AsimAli\Pinpoint\Facades\Pinpoint
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.3-8.2.33-2be956d1288209dcf49c9d23c01afaf04748cb97721f52f8ebc28b8a088580fe',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'AsimAli\\Pinpoint\\Facades\\Pinpoint',
        'filename' => '/mnt/workspace/Personal-Projects/sentinel/src/Facades/Pinpoint.php',
      ),
    ),
    'namespace' => 'AsimAli\\Pinpoint\\Facades',
    'name' => 'AsimAli\\Pinpoint\\Facades\\Pinpoint',
    'shortName' => 'Pinpoint',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 0,
    'docComment' => '/**
 * @method static void observeLazyLoad(string $model, string $relation)
 *
 * @see \\AsimAli\\Pinpoint\\Pinpoint
 */',
    'attributes' => 
    array (
    ),
    'startLine' => 12,
    'endLine' => 18,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => 'Illuminate\\Support\\Facades\\Facade',
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      'getFacadeAccessor' => 
      array (
        'name' => 'getFacadeAccessor',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'string',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 14,
        'endLine' => 17,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 18,
        'namespace' => 'AsimAli\\Pinpoint\\Facades',
        'declaringClassName' => 'AsimAli\\Pinpoint\\Facades\\Pinpoint',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Facades\\Pinpoint',
        'currentClassName' => 'AsimAli\\Pinpoint\\Facades\\Pinpoint',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));