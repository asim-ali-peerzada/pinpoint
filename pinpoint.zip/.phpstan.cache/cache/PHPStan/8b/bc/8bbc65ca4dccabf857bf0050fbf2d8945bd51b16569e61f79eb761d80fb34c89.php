<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Console/Concerns/PromptsForMissingInput.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-b64deca387ae959be0bc7885518aad8521b65f300cbb7ac4efb46d3de2aaff35-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\console\\concerns\\promptsformissinginput' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));