<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Contracts/Broadcasting/HasBroadcastChannel.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-4adf747bb1f0810b2a8aacd3ab55d59fe348bdb57a47130375264d5fc1002b43-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\contracts\\broadcasting\\hasbroadcastchannel' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));