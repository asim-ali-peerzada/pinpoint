<?php declare(strict_types = 1);

// odsl-/mnt/workspace/Personal-Projects/sentinel/src/Caller.php-PHPStan\BetterReflection\Reflection\ReflectionClass-AsimAli\Pinpoint\Caller
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.3-8.2.33-47ad1616e9a0707e2c6f6ae2bbb733abfbaf1601e2653d35e533e64d463a0b6c',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'AsimAli\\Pinpoint\\Caller',
        'filename' => '/mnt/workspace/Personal-Projects/sentinel/src/Caller.php',
      ),
    ),
    'namespace' => 'AsimAli\\Pinpoint',
    'name' => 'AsimAli\\Pinpoint\\Caller',
    'shortName' => 'Caller',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 0,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 5,
    'endLine' => 32,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => NULL,
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      'capture' => 
      array (
        'name' => 'capture',
        'parameters' => 
        array (
          'basePath' => 
          array (
            'name' => 'basePath',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'string',
                'isIdentifier' => true,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 15,
            'endLine' => 15,
            'startColumn' => 36,
            'endColumn' => 51,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionUnionType',
          'data' => 
          array (
            'types' => 
            array (
              0 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'array',
                  'isIdentifier' => true,
                ),
              ),
              1 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'null',
                  'isIdentifier' => true,
                ),
              ),
            ),
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Capture the first stack frame inside the app\'s base path.
 *
 * debug_backtrace is the most expensive thing this package does:
 * DEBUG_BACKTRACE_IGNORE_ARGS avoids capturing full argument values at
 * every frame (the source of memory spikes), and the depth limit stops
 * it walking the entire call stack.
 */',
        'startLine' => 15,
        'endLine' => 31,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 17,
        'namespace' => 'AsimAli\\Pinpoint',
        'declaringClassName' => 'AsimAli\\Pinpoint\\Caller',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Caller',
        'currentClassName' => 'AsimAli\\Pinpoint\\Caller',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));