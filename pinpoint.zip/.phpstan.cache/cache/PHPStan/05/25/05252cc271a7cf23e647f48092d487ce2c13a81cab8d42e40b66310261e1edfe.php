<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Database/ConnectionResolverInterface.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-05e764edae3ec80a4db69f3fd2769b0baad8cb08472b6c86b6b01e33db642feb-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\database\\connectionresolverinterface' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));