<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/src/Caller.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      'e9a5410658d99345803adeab4a209912' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint',
         'uses' => 
        array (
        ),
         'className' => 'AsimAli\\Pinpoint\\Caller',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7e63f283804390538554bcfd43f494d2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint',
         'uses' => 
        array (
        ),
         'className' => 'AsimAli\\Pinpoint\\Caller',
         'functionName' => 'capture',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/src/Caller.php' => '47ad1616e9a0707e2c6f6ae2bbb733abfbaf1601e2653d35e533e64d463a0b6c',
    ),
  ),
));