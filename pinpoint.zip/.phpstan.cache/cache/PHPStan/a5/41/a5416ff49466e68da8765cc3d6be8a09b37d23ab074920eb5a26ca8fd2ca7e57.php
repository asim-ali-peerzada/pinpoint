<?php declare(strict_types = 1);

// odsl-/mnt/workspace/Personal-Projects/sentinel/src/Commands/AggregateCommand.php-PHPStan\BetterReflection\Reflection\ReflectionClass-AsimAli\Pinpoint\Commands\AggregateCommand
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.3-8.2.33-39e641c1f0f6b2a565300fc9cf2403b875bbf94ca7cb355d8330b4b24c67226a',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
        'filename' => '/mnt/workspace/Personal-Projects/sentinel/src/Commands/AggregateCommand.php',
      ),
    ),
    'namespace' => 'AsimAli\\Pinpoint\\Commands',
    'name' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
    'shortName' => 'AggregateCommand',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 0,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 12,
    'endLine' => 76,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => 'Illuminate\\Console\\Command',
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
      'signature' => 
      array (
        'declaringClassName' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
        'name' => 'signature',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'pinpoint:aggregate\'',
          'attributes' => 
          array (
            'startLine' => 14,
            'endLine' => 14,
            'startTokenPos' => 53,
            'startFilePos' => 311,
            'endTokenPos' => 53,
            'endFilePos' => 330,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 14,
        'endLine' => 14,
        'startColumn' => 5,
        'endColumn' => 48,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'description' => 
      array (
        'declaringClassName' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
        'name' => 'description',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'Roll raw pinpoint_requests into per-route percentile summaries\'',
          'attributes' => 
          array (
            'startLine' => 16,
            'endLine' => 16,
            'startTokenPos' => 62,
            'startFilePos' => 363,
            'endTokenPos' => 62,
            'endFilePos' => 426,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 16,
        'endLine' => 16,
        'startColumn' => 5,
        'endColumn' => 94,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'tiers' => 
      array (
        'declaringClassName' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
        'name' => 'tiers',
        'modifiers' => 2,
        'type' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'AsimAli\\Pinpoint\\TierClassifier',
            'isIdentifier' => false,
          ),
        ),
        'default' => NULL,
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 18,
        'endLine' => 18,
        'startColumn' => 33,
        'endColumn' => 63,
        'isPromoted' => true,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
    ),
    'immediateMethods' => 
    array (
      '__construct' => 
      array (
        'name' => '__construct',
        'parameters' => 
        array (
          'tiers' => 
          array (
            'name' => 'tiers',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'AsimAli\\Pinpoint\\TierClassifier',
                'isIdentifier' => false,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => true,
            'attributes' => 
            array (
            ),
            'startLine' => 18,
            'endLine' => 18,
            'startColumn' => 33,
            'endColumn' => 63,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 18,
        'endLine' => 21,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'AsimAli\\Pinpoint\\Commands',
        'declaringClassName' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
        'currentClassName' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
        'aliasName' => NULL,
      ),
      'handle' => 
      array (
        'name' => 'handle',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'int',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 23,
        'endLine' => 35,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'AsimAli\\Pinpoint\\Commands',
        'declaringClassName' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
        'currentClassName' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
        'aliasName' => NULL,
      ),
      'aggregate' => 
      array (
        'name' => 'aggregate',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 37,
        'endLine' => 65,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'AsimAli\\Pinpoint\\Commands',
        'declaringClassName' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
        'currentClassName' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
        'aliasName' => NULL,
      ),
      'durationsFor' => 
      array (
        'name' => 'durationsFor',
        'parameters' => 
        array (
          'label' => 
          array (
            'name' => 'label',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'string',
                'isIdentifier' => true,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 67,
            'endLine' => 67,
            'startColumn' => 37,
            'endColumn' => 49,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'array',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 67,
        'endLine' => 75,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'AsimAli\\Pinpoint\\Commands',
        'declaringClassName' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
        'currentClassName' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));