<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Units.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      'a8797d72e4a8713993881e905bebe19b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'unitexception' => 'Carbon\\Exceptions\\UnitException',
          'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
          'overflowmode' => 'Carbon\\OverflowMode',
          'unit' => 'Carbon\\Unit',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datemalformedstringexception' => 'DateMalformedStringException',
          'invalidargumentexception' => 'InvalidArgumentException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Units',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '067d3c2a33f32ae3cf242ca70dd5ded2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'unitexception' => 'Carbon\\Exceptions\\UnitException',
          'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
          'overflowmode' => 'Carbon\\OverflowMode',
          'unit' => 'Carbon\\Unit',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datemalformedstringexception' => 'DateMalformedStringException',
          'invalidargumentexception' => 'InvalidArgumentException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Units',
         'functionName' => 'addRealUnit',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
            'unitexception' => 'Carbon\\Exceptions\\UnitException',
            'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
            'overflowmode' => 'Carbon\\OverflowMode',
            'unit' => 'Carbon\\Unit',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datemalformedstringexception' => 'DateMalformedStringException',
            'invalidargumentexception' => 'InvalidArgumentException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Units',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '54d74dc707591809e1e9c7727bb689f9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'unitexception' => 'Carbon\\Exceptions\\UnitException',
          'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
          'overflowmode' => 'Carbon\\OverflowMode',
          'unit' => 'Carbon\\Unit',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datemalformedstringexception' => 'DateMalformedStringException',
          'invalidargumentexception' => 'InvalidArgumentException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Units',
         'functionName' => 'addUTCUnit',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
            'unitexception' => 'Carbon\\Exceptions\\UnitException',
            'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
            'overflowmode' => 'Carbon\\OverflowMode',
            'unit' => 'Carbon\\Unit',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datemalformedstringexception' => 'DateMalformedStringException',
            'invalidargumentexception' => 'InvalidArgumentException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Units',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1e5b6ab8d16ac4a8fe206576e7bf278f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'unitexception' => 'Carbon\\Exceptions\\UnitException',
          'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
          'overflowmode' => 'Carbon\\OverflowMode',
          'unit' => 'Carbon\\Unit',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datemalformedstringexception' => 'DateMalformedStringException',
          'invalidargumentexception' => 'InvalidArgumentException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Units',
         'functionName' => 'subRealUnit',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
            'unitexception' => 'Carbon\\Exceptions\\UnitException',
            'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
            'overflowmode' => 'Carbon\\OverflowMode',
            'unit' => 'Carbon\\Unit',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datemalformedstringexception' => 'DateMalformedStringException',
            'invalidargumentexception' => 'InvalidArgumentException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Units',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a1710ba2a73e86cf94db65150f3d8995' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'unitexception' => 'Carbon\\Exceptions\\UnitException',
          'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
          'overflowmode' => 'Carbon\\OverflowMode',
          'unit' => 'Carbon\\Unit',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datemalformedstringexception' => 'DateMalformedStringException',
          'invalidargumentexception' => 'InvalidArgumentException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Units',
         'functionName' => 'subUTCUnit',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
            'unitexception' => 'Carbon\\Exceptions\\UnitException',
            'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
            'overflowmode' => 'Carbon\\OverflowMode',
            'unit' => 'Carbon\\Unit',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datemalformedstringexception' => 'DateMalformedStringException',
            'invalidargumentexception' => 'InvalidArgumentException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Units',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'adff13bbbd711b543403816d5da243c2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'unitexception' => 'Carbon\\Exceptions\\UnitException',
          'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
          'overflowmode' => 'Carbon\\OverflowMode',
          'unit' => 'Carbon\\Unit',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datemalformedstringexception' => 'DateMalformedStringException',
          'invalidargumentexception' => 'InvalidArgumentException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Units',
         'functionName' => 'isModifiableUnit',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
            'unitexception' => 'Carbon\\Exceptions\\UnitException',
            'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
            'overflowmode' => 'Carbon\\OverflowMode',
            'unit' => 'Carbon\\Unit',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datemalformedstringexception' => 'DateMalformedStringException',
            'invalidargumentexception' => 'InvalidArgumentException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Units',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6d09dec3c40fe88640fbfb09222bde55' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'unitexception' => 'Carbon\\Exceptions\\UnitException',
          'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
          'overflowmode' => 'Carbon\\OverflowMode',
          'unit' => 'Carbon\\Unit',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datemalformedstringexception' => 'DateMalformedStringException',
          'invalidargumentexception' => 'InvalidArgumentException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Units',
         'functionName' => 'rawAdd',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
            'unitexception' => 'Carbon\\Exceptions\\UnitException',
            'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
            'overflowmode' => 'Carbon\\OverflowMode',
            'unit' => 'Carbon\\Unit',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datemalformedstringexception' => 'DateMalformedStringException',
            'invalidargumentexception' => 'InvalidArgumentException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Units',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '42d6c619e1f0693a4a68db7693342a00' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'unitexception' => 'Carbon\\Exceptions\\UnitException',
          'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
          'overflowmode' => 'Carbon\\OverflowMode',
          'unit' => 'Carbon\\Unit',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datemalformedstringexception' => 'DateMalformedStringException',
          'invalidargumentexception' => 'InvalidArgumentException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Units',
         'functionName' => 'add',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
            'unitexception' => 'Carbon\\Exceptions\\UnitException',
            'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
            'overflowmode' => 'Carbon\\OverflowMode',
            'unit' => 'Carbon\\Unit',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datemalformedstringexception' => 'DateMalformedStringException',
            'invalidargumentexception' => 'InvalidArgumentException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Units',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4aa5ff9b98c4189cf04c09acb44457cb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'unitexception' => 'Carbon\\Exceptions\\UnitException',
          'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
          'overflowmode' => 'Carbon\\OverflowMode',
          'unit' => 'Carbon\\Unit',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datemalformedstringexception' => 'DateMalformedStringException',
          'invalidargumentexception' => 'InvalidArgumentException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Units',
         'functionName' => 'addUnit',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
            'unitexception' => 'Carbon\\Exceptions\\UnitException',
            'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
            'overflowmode' => 'Carbon\\OverflowMode',
            'unit' => 'Carbon\\Unit',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datemalformedstringexception' => 'DateMalformedStringException',
            'invalidargumentexception' => 'InvalidArgumentException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Units',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '342dc4da43cdd4c2b480da4a812338a9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'unitexception' => 'Carbon\\Exceptions\\UnitException',
          'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
          'overflowmode' => 'Carbon\\OverflowMode',
          'unit' => 'Carbon\\Unit',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datemalformedstringexception' => 'DateMalformedStringException',
          'invalidargumentexception' => 'InvalidArgumentException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Units',
         'functionName' => 'subUnit',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
            'unitexception' => 'Carbon\\Exceptions\\UnitException',
            'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
            'overflowmode' => 'Carbon\\OverflowMode',
            'unit' => 'Carbon\\Unit',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datemalformedstringexception' => 'DateMalformedStringException',
            'invalidargumentexception' => 'InvalidArgumentException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Units',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a7bcf4bb285ff86ff98cc1380fe03519' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'unitexception' => 'Carbon\\Exceptions\\UnitException',
          'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
          'overflowmode' => 'Carbon\\OverflowMode',
          'unit' => 'Carbon\\Unit',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datemalformedstringexception' => 'DateMalformedStringException',
          'invalidargumentexception' => 'InvalidArgumentException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Units',
         'functionName' => 'rawSub',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
            'unitexception' => 'Carbon\\Exceptions\\UnitException',
            'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
            'overflowmode' => 'Carbon\\OverflowMode',
            'unit' => 'Carbon\\Unit',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datemalformedstringexception' => 'DateMalformedStringException',
            'invalidargumentexception' => 'InvalidArgumentException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Units',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7117221d2ed1301f48257f0357da2a90' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'unitexception' => 'Carbon\\Exceptions\\UnitException',
          'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
          'overflowmode' => 'Carbon\\OverflowMode',
          'unit' => 'Carbon\\Unit',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datemalformedstringexception' => 'DateMalformedStringException',
          'invalidargumentexception' => 'InvalidArgumentException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Units',
         'functionName' => 'sub',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
            'unitexception' => 'Carbon\\Exceptions\\UnitException',
            'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
            'overflowmode' => 'Carbon\\OverflowMode',
            'unit' => 'Carbon\\Unit',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datemalformedstringexception' => 'DateMalformedStringException',
            'invalidargumentexception' => 'InvalidArgumentException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Units',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bf3c19d59bfa7e4e95d1447806fc26eb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'unitexception' => 'Carbon\\Exceptions\\UnitException',
          'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
          'overflowmode' => 'Carbon\\OverflowMode',
          'unit' => 'Carbon\\Unit',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datemalformedstringexception' => 'DateMalformedStringException',
          'invalidargumentexception' => 'InvalidArgumentException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Units',
         'functionName' => 'subtract',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
            'unitexception' => 'Carbon\\Exceptions\\UnitException',
            'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
            'overflowmode' => 'Carbon\\OverflowMode',
            'unit' => 'Carbon\\Unit',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datemalformedstringexception' => 'DateMalformedStringException',
            'invalidargumentexception' => 'InvalidArgumentException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Units',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '136b8e29f26b7eb2ef5475c25dfa21e9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'unitexception' => 'Carbon\\Exceptions\\UnitException',
          'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
          'overflowmode' => 'Carbon\\OverflowMode',
          'unit' => 'Carbon\\Unit',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datemalformedstringexception' => 'DateMalformedStringException',
          'invalidargumentexception' => 'InvalidArgumentException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Units',
         'functionName' => 'doPlus',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
            'unitexception' => 'Carbon\\Exceptions\\UnitException',
            'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
            'overflowmode' => 'Carbon\\OverflowMode',
            'unit' => 'Carbon\\Unit',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datemalformedstringexception' => 'DateMalformedStringException',
            'invalidargumentexception' => 'InvalidArgumentException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Units',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8404fad5ade228d3e13c40330bcb168e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'unitexception' => 'Carbon\\Exceptions\\UnitException',
          'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
          'overflowmode' => 'Carbon\\OverflowMode',
          'unit' => 'Carbon\\Unit',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datemalformedstringexception' => 'DateMalformedStringException',
          'invalidargumentexception' => 'InvalidArgumentException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Units',
         'functionName' => 'doMinus',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
            'unitexception' => 'Carbon\\Exceptions\\UnitException',
            'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
            'overflowmode' => 'Carbon\\OverflowMode',
            'unit' => 'Carbon\\Unit',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datemalformedstringexception' => 'DateMalformedStringException',
            'invalidargumentexception' => 'InvalidArgumentException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Units',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b6dfdbe38acda24d9270615d3b3f0362' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'unitexception' => 'Carbon\\Exceptions\\UnitException',
          'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
          'overflowmode' => 'Carbon\\OverflowMode',
          'unit' => 'Carbon\\Unit',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datemalformedstringexception' => 'DateMalformedStringException',
          'invalidargumentexception' => 'InvalidArgumentException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Units',
         'functionName' => 'callPlusOrMinus',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
            'unitexception' => 'Carbon\\Exceptions\\UnitException',
            'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
            'overflowmode' => 'Carbon\\OverflowMode',
            'unit' => 'Carbon\\Unit',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datemalformedstringexception' => 'DateMalformedStringException',
            'invalidargumentexception' => 'InvalidArgumentException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Units',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ac085bb4437650d87e8f6a7104d066f0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'unitexception' => 'Carbon\\Exceptions\\UnitException',
          'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
          'overflowmode' => 'Carbon\\OverflowMode',
          'unit' => 'Carbon\\Unit',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datemalformedstringexception' => 'DateMalformedStringException',
          'invalidargumentexception' => 'InvalidArgumentException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Units',
         'functionName' => 'rawAddUnit',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
            'unitexception' => 'Carbon\\Exceptions\\UnitException',
            'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
            'overflowmode' => 'Carbon\\OverflowMode',
            'unit' => 'Carbon\\Unit',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datemalformedstringexception' => 'DateMalformedStringException',
            'invalidargumentexception' => 'InvalidArgumentException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Units',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '748cb06df13d0f2ba0361cf980eb24f6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'unitexception' => 'Carbon\\Exceptions\\UnitException',
          'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
          'overflowmode' => 'Carbon\\OverflowMode',
          'unit' => 'Carbon\\Unit',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datemalformedstringexception' => 'DateMalformedStringException',
          'invalidargumentexception' => 'InvalidArgumentException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Units',
         'functionName' => 'getNumberAsString',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
            'unitexception' => 'Carbon\\Exceptions\\UnitException',
            'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
            'overflowmode' => 'Carbon\\OverflowMode',
            'unit' => 'Carbon\\Unit',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datemalformedstringexception' => 'DateMalformedStringException',
            'invalidargumentexception' => 'InvalidArgumentException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Units',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4cc6ba492e75c617f4e6359559cf7181' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'unitexception' => 'Carbon\\Exceptions\\UnitException',
          'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
          'overflowmode' => 'Carbon\\OverflowMode',
          'unit' => 'Carbon\\Unit',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datemalformedstringexception' => 'DateMalformedStringException',
          'invalidargumentexception' => 'InvalidArgumentException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Units',
         'functionName' => 'setAnchorDay',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
            'unitexception' => 'Carbon\\Exceptions\\UnitException',
            'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
            'overflowmode' => 'Carbon\\OverflowMode',
            'unit' => 'Carbon\\Unit',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datemalformedstringexception' => 'DateMalformedStringException',
            'invalidargumentexception' => 'InvalidArgumentException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Units',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '184a14d4cf92d7b4357da3a9bcd06b26' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'unitexception' => 'Carbon\\Exceptions\\UnitException',
          'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
          'overflowmode' => 'Carbon\\OverflowMode',
          'unit' => 'Carbon\\Unit',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datemalformedstringexception' => 'DateMalformedStringException',
          'invalidargumentexception' => 'InvalidArgumentException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Units',
         'functionName' => 'disallowDecimalPart',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
            'unitexception' => 'Carbon\\Exceptions\\UnitException',
            'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
            'overflowmode' => 'Carbon\\OverflowMode',
            'unit' => 'Carbon\\Unit',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datemalformedstringexception' => 'DateMalformedStringException',
            'invalidargumentexception' => 'InvalidArgumentException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Units',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '27335ec3557174aea8bc3fcb21bc5efe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'unitexception' => 'Carbon\\Exceptions\\UnitException',
          'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
          'overflowmode' => 'Carbon\\OverflowMode',
          'unit' => 'Carbon\\Unit',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datemalformedstringexception' => 'DateMalformedStringException',
          'invalidargumentexception' => 'InvalidArgumentException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Units',
         'functionName' => 'getOverflowMode',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
            'unitexception' => 'Carbon\\Exceptions\\UnitException',
            'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
            'overflowmode' => 'Carbon\\OverflowMode',
            'unit' => 'Carbon\\Unit',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datemalformedstringexception' => 'DateMalformedStringException',
            'invalidargumentexception' => 'InvalidArgumentException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Units',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '49da4fc581246c8cb04112c81e2e77af' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'carboninterval' => 'Carbon\\CarbonInterval',
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
          'unitexception' => 'Carbon\\Exceptions\\UnitException',
          'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
          'overflowmode' => 'Carbon\\OverflowMode',
          'unit' => 'Carbon\\Unit',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datemalformedstringexception' => 'DateMalformedStringException',
          'invalidargumentexception' => 'InvalidArgumentException',
          'returntypewillchange' => 'ReturnTypeWillChange',
        ),
         'className' => 'Carbon\\Traits\\Units',
         'functionName' => 'shouldUnitOverflow',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'carboninterval' => 'Carbon\\CarbonInterval',
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'invalidintervalexception' => 'Carbon\\Exceptions\\InvalidIntervalException',
            'unitexception' => 'Carbon\\Exceptions\\UnitException',
            'unsupportedunitexception' => 'Carbon\\Exceptions\\UnsupportedUnitException',
            'overflowmode' => 'Carbon\\OverflowMode',
            'unit' => 'Carbon\\Unit',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datemalformedstringexception' => 'DateMalformedStringException',
            'invalidargumentexception' => 'InvalidArgumentException',
            'returntypewillchange' => 'ReturnTypeWillChange',
          ),
           'className' => 'Carbon\\Traits\\Units',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Units.php' => 'a8b988c0d72f7710d600e91b8e29d09af5c79eaaa5998eafb7148734a259e280',
    ),
  ),
));