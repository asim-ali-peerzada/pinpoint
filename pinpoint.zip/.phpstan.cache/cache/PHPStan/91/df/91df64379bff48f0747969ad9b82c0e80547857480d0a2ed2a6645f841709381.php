<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/symfony/console/Exception/ExceptionInterface.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      '5bdc8cb1f6492e2406a15f0b0ce7b872' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\Console\\Exception',
         'uses' => 
        array (
        ),
         'className' => 'Symfony\\Component\\Console\\Exception\\ExceptionInterface',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/symfony/console/Exception/ExceptionInterface.php' => '566051a18eafac33728f361dfbe3492515ad5f9230bdf00405845e1b164e3b3e',
    ),
  ),
));