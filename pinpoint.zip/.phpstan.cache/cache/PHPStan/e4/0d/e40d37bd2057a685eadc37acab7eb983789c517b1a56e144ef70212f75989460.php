<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Http/Concerns/InteractsWithFlashData.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-f1e1cfc096426ec1002825015f43b034aadbb1787391bb1077fb1a7adc3c486d-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\http\\concerns\\interactswithflashdata' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));