<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Foundation/Console/EventGenerateCommand.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-15bc50cfe83701bfb0c92db91a6df2987f120e9953510c82fd5768c8d5c6e37d-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\foundation\\console\\eventgeneratecommand' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));