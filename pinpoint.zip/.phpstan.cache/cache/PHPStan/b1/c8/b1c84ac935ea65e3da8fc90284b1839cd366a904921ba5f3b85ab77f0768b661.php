<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Database/Eloquent/Concerns/HasUniqueIds.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-c66f346a6b8d205758773d0283bbd33ad5a465d06af8a23f7f05cfd1f6565b66-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\database\\eloquent\\concerns\\hasuniqueids' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));