<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      'da410ba93fb9eaa417a48c6a54a51369' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console',
         'uses' => 
        array (
          'factory' => 'Illuminate\\Console\\View\\Components\\Factory',
          'isolatable' => 'Illuminate\\Contracts\\Console\\Isolatable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'symfonycommand' => 'Symfony\\Component\\Console\\Command\\Command',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '18777b9d6e57586de18f173998f9f4f5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'collection' => 'Illuminate\\Support\\Collection',
          'arrayinput' => 'Symfony\\Component\\Console\\Input\\ArrayInput',
          'nulloutput' => 'Symfony\\Component\\Console\\Output\\NullOutput',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\CallsCommands',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\CallsCommands',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '053082c4183ea1187e0c783d158ad25d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'collection' => 'Illuminate\\Support\\Collection',
          'arrayinput' => 'Symfony\\Component\\Console\\Input\\ArrayInput',
          'nulloutput' => 'Symfony\\Component\\Console\\Output\\NullOutput',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'resolveCommand',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\CallsCommands',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\CallsCommands',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '390fd14ea54d245d3218ee92b92fd6f4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'collection' => 'Illuminate\\Support\\Collection',
          'arrayinput' => 'Symfony\\Component\\Console\\Input\\ArrayInput',
          'nulloutput' => 'Symfony\\Component\\Console\\Output\\NullOutput',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'call',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\CallsCommands',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\CallsCommands',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '630f3e344b2bc0ebd7f3f62da58bf6df' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'collection' => 'Illuminate\\Support\\Collection',
          'arrayinput' => 'Symfony\\Component\\Console\\Input\\ArrayInput',
          'nulloutput' => 'Symfony\\Component\\Console\\Output\\NullOutput',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'callSilent',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\CallsCommands',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\CallsCommands',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '59819859c39c77b387284d88395939bf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'collection' => 'Illuminate\\Support\\Collection',
          'arrayinput' => 'Symfony\\Component\\Console\\Input\\ArrayInput',
          'nulloutput' => 'Symfony\\Component\\Console\\Output\\NullOutput',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'callSilently',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\CallsCommands',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\CallsCommands',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'deb1feaca2e0ef0b780e16553f12617d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'collection' => 'Illuminate\\Support\\Collection',
          'arrayinput' => 'Symfony\\Component\\Console\\Input\\ArrayInput',
          'nulloutput' => 'Symfony\\Component\\Console\\Output\\NullOutput',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'runCommand',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\CallsCommands',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\CallsCommands',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '4afe147245fe949d203d5d596e313c57' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'collection' => 'Illuminate\\Support\\Collection',
          'arrayinput' => 'Symfony\\Component\\Console\\Input\\ArrayInput',
          'nulloutput' => 'Symfony\\Component\\Console\\Output\\NullOutput',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'createInputFromArguments',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\CallsCommands',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\CallsCommands',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '32cb1a46b4f5e598ad739a22fa307ab9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'collection' => 'Illuminate\\Support\\Collection',
          'arrayinput' => 'Symfony\\Component\\Console\\Input\\ArrayInput',
          'nulloutput' => 'Symfony\\Component\\Console\\Output\\NullOutput',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'context',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\CallsCommands',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\CallsCommands',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '385c1f879c762a4dfc7a84d208f3d71c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'promptvalidationexception' => 'Illuminate\\Console\\PromptValidationException',
          'confirmprompt' => 'Laravel\\Prompts\\ConfirmPrompt',
          'multisearchprompt' => 'Laravel\\Prompts\\MultiSearchPrompt',
          'multiselectprompt' => 'Laravel\\Prompts\\MultiSelectPrompt',
          'passwordprompt' => 'Laravel\\Prompts\\PasswordPrompt',
          'pauseprompt' => 'Laravel\\Prompts\\PausePrompt',
          'prompt' => 'Laravel\\Prompts\\Prompt',
          'searchprompt' => 'Laravel\\Prompts\\SearchPrompt',
          'selectprompt' => 'Laravel\\Prompts\\SelectPrompt',
          'suggestprompt' => 'Laravel\\Prompts\\SuggestPrompt',
          'textareaprompt' => 'Laravel\\Prompts\\TextareaPrompt',
          'textprompt' => 'Laravel\\Prompts\\TextPrompt',
          'stdclass' => 'stdClass',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\ConfiguresPrompts',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\ConfiguresPrompts',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '2189f46ea6fbe1b5a957cb39dc14fd84' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'promptvalidationexception' => 'Illuminate\\Console\\PromptValidationException',
          'confirmprompt' => 'Laravel\\Prompts\\ConfirmPrompt',
          'multisearchprompt' => 'Laravel\\Prompts\\MultiSearchPrompt',
          'multiselectprompt' => 'Laravel\\Prompts\\MultiSelectPrompt',
          'passwordprompt' => 'Laravel\\Prompts\\PasswordPrompt',
          'pauseprompt' => 'Laravel\\Prompts\\PausePrompt',
          'prompt' => 'Laravel\\Prompts\\Prompt',
          'searchprompt' => 'Laravel\\Prompts\\SearchPrompt',
          'selectprompt' => 'Laravel\\Prompts\\SelectPrompt',
          'suggestprompt' => 'Laravel\\Prompts\\SuggestPrompt',
          'textareaprompt' => 'Laravel\\Prompts\\TextareaPrompt',
          'textprompt' => 'Laravel\\Prompts\\TextPrompt',
          'stdclass' => 'stdClass',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'configurePrompts',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\ConfiguresPrompts',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\ConfiguresPrompts',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '05f790455aa9e89a102dd4c52a13fa6a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'promptvalidationexception' => 'Illuminate\\Console\\PromptValidationException',
          'confirmprompt' => 'Laravel\\Prompts\\ConfirmPrompt',
          'multisearchprompt' => 'Laravel\\Prompts\\MultiSearchPrompt',
          'multiselectprompt' => 'Laravel\\Prompts\\MultiSelectPrompt',
          'passwordprompt' => 'Laravel\\Prompts\\PasswordPrompt',
          'pauseprompt' => 'Laravel\\Prompts\\PausePrompt',
          'prompt' => 'Laravel\\Prompts\\Prompt',
          'searchprompt' => 'Laravel\\Prompts\\SearchPrompt',
          'selectprompt' => 'Laravel\\Prompts\\SelectPrompt',
          'suggestprompt' => 'Laravel\\Prompts\\SuggestPrompt',
          'textareaprompt' => 'Laravel\\Prompts\\TextareaPrompt',
          'textprompt' => 'Laravel\\Prompts\\TextPrompt',
          'stdclass' => 'stdClass',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'promptUntilValid',
         'templatePhpDocNodes' => 
        array (
          'PResult' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'PResult',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\ConfiguresPrompts',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\ConfiguresPrompts',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '9ec753ee9b046fc117054cd2b3d2ef9d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'promptvalidationexception' => 'Illuminate\\Console\\PromptValidationException',
          'confirmprompt' => 'Laravel\\Prompts\\ConfirmPrompt',
          'multisearchprompt' => 'Laravel\\Prompts\\MultiSearchPrompt',
          'multiselectprompt' => 'Laravel\\Prompts\\MultiSelectPrompt',
          'passwordprompt' => 'Laravel\\Prompts\\PasswordPrompt',
          'pauseprompt' => 'Laravel\\Prompts\\PausePrompt',
          'prompt' => 'Laravel\\Prompts\\Prompt',
          'searchprompt' => 'Laravel\\Prompts\\SearchPrompt',
          'selectprompt' => 'Laravel\\Prompts\\SelectPrompt',
          'suggestprompt' => 'Laravel\\Prompts\\SuggestPrompt',
          'textareaprompt' => 'Laravel\\Prompts\\TextareaPrompt',
          'textprompt' => 'Laravel\\Prompts\\TextPrompt',
          'stdclass' => 'stdClass',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'validatePrompt',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\ConfiguresPrompts',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\ConfiguresPrompts',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '5f290dc31d4356a2a046877629cfbd68' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'promptvalidationexception' => 'Illuminate\\Console\\PromptValidationException',
          'confirmprompt' => 'Laravel\\Prompts\\ConfirmPrompt',
          'multisearchprompt' => 'Laravel\\Prompts\\MultiSearchPrompt',
          'multiselectprompt' => 'Laravel\\Prompts\\MultiSelectPrompt',
          'passwordprompt' => 'Laravel\\Prompts\\PasswordPrompt',
          'pauseprompt' => 'Laravel\\Prompts\\PausePrompt',
          'prompt' => 'Laravel\\Prompts\\Prompt',
          'searchprompt' => 'Laravel\\Prompts\\SearchPrompt',
          'selectprompt' => 'Laravel\\Prompts\\SelectPrompt',
          'suggestprompt' => 'Laravel\\Prompts\\SuggestPrompt',
          'textareaprompt' => 'Laravel\\Prompts\\TextareaPrompt',
          'textprompt' => 'Laravel\\Prompts\\TextPrompt',
          'stdclass' => 'stdClass',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'getPromptValidatorInstance',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\ConfiguresPrompts',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\ConfiguresPrompts',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '659ce4363a997f377f461775ccb7e210' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'promptvalidationexception' => 'Illuminate\\Console\\PromptValidationException',
          'confirmprompt' => 'Laravel\\Prompts\\ConfirmPrompt',
          'multisearchprompt' => 'Laravel\\Prompts\\MultiSearchPrompt',
          'multiselectprompt' => 'Laravel\\Prompts\\MultiSelectPrompt',
          'passwordprompt' => 'Laravel\\Prompts\\PasswordPrompt',
          'pauseprompt' => 'Laravel\\Prompts\\PausePrompt',
          'prompt' => 'Laravel\\Prompts\\Prompt',
          'searchprompt' => 'Laravel\\Prompts\\SearchPrompt',
          'selectprompt' => 'Laravel\\Prompts\\SelectPrompt',
          'suggestprompt' => 'Laravel\\Prompts\\SuggestPrompt',
          'textareaprompt' => 'Laravel\\Prompts\\TextareaPrompt',
          'textprompt' => 'Laravel\\Prompts\\TextPrompt',
          'stdclass' => 'stdClass',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'validationMessages',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\ConfiguresPrompts',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\ConfiguresPrompts',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '4935517102d473e18465b4be6c2fef99' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'promptvalidationexception' => 'Illuminate\\Console\\PromptValidationException',
          'confirmprompt' => 'Laravel\\Prompts\\ConfirmPrompt',
          'multisearchprompt' => 'Laravel\\Prompts\\MultiSearchPrompt',
          'multiselectprompt' => 'Laravel\\Prompts\\MultiSelectPrompt',
          'passwordprompt' => 'Laravel\\Prompts\\PasswordPrompt',
          'pauseprompt' => 'Laravel\\Prompts\\PausePrompt',
          'prompt' => 'Laravel\\Prompts\\Prompt',
          'searchprompt' => 'Laravel\\Prompts\\SearchPrompt',
          'selectprompt' => 'Laravel\\Prompts\\SelectPrompt',
          'suggestprompt' => 'Laravel\\Prompts\\SuggestPrompt',
          'textareaprompt' => 'Laravel\\Prompts\\TextareaPrompt',
          'textprompt' => 'Laravel\\Prompts\\TextPrompt',
          'stdclass' => 'stdClass',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'validationAttributes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\ConfiguresPrompts',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\ConfiguresPrompts',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'fa6041ef971c042430deef120d99ec1b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'promptvalidationexception' => 'Illuminate\\Console\\PromptValidationException',
          'confirmprompt' => 'Laravel\\Prompts\\ConfirmPrompt',
          'multisearchprompt' => 'Laravel\\Prompts\\MultiSearchPrompt',
          'multiselectprompt' => 'Laravel\\Prompts\\MultiSelectPrompt',
          'passwordprompt' => 'Laravel\\Prompts\\PasswordPrompt',
          'pauseprompt' => 'Laravel\\Prompts\\PausePrompt',
          'prompt' => 'Laravel\\Prompts\\Prompt',
          'searchprompt' => 'Laravel\\Prompts\\SearchPrompt',
          'selectprompt' => 'Laravel\\Prompts\\SelectPrompt',
          'suggestprompt' => 'Laravel\\Prompts\\SuggestPrompt',
          'textareaprompt' => 'Laravel\\Prompts\\TextareaPrompt',
          'textprompt' => 'Laravel\\Prompts\\TextPrompt',
          'stdclass' => 'stdClass',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'restorePrompts',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\ConfiguresPrompts',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\ConfiguresPrompts',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '132354f471d1c9e1518b526ae1ba6376' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'promptvalidationexception' => 'Illuminate\\Console\\PromptValidationException',
          'confirmprompt' => 'Laravel\\Prompts\\ConfirmPrompt',
          'multisearchprompt' => 'Laravel\\Prompts\\MultiSearchPrompt',
          'multiselectprompt' => 'Laravel\\Prompts\\MultiSelectPrompt',
          'passwordprompt' => 'Laravel\\Prompts\\PasswordPrompt',
          'pauseprompt' => 'Laravel\\Prompts\\PausePrompt',
          'prompt' => 'Laravel\\Prompts\\Prompt',
          'searchprompt' => 'Laravel\\Prompts\\SearchPrompt',
          'selectprompt' => 'Laravel\\Prompts\\SelectPrompt',
          'suggestprompt' => 'Laravel\\Prompts\\SuggestPrompt',
          'textareaprompt' => 'Laravel\\Prompts\\TextareaPrompt',
          'textprompt' => 'Laravel\\Prompts\\TextPrompt',
          'stdclass' => 'stdClass',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'selectFallback',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\ConfiguresPrompts',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\ConfiguresPrompts',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '2239ad2701b927ccf51dfc0f1ec4bd05' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'promptvalidationexception' => 'Illuminate\\Console\\PromptValidationException',
          'confirmprompt' => 'Laravel\\Prompts\\ConfirmPrompt',
          'multisearchprompt' => 'Laravel\\Prompts\\MultiSearchPrompt',
          'multiselectprompt' => 'Laravel\\Prompts\\MultiSelectPrompt',
          'passwordprompt' => 'Laravel\\Prompts\\PasswordPrompt',
          'pauseprompt' => 'Laravel\\Prompts\\PausePrompt',
          'prompt' => 'Laravel\\Prompts\\Prompt',
          'searchprompt' => 'Laravel\\Prompts\\SearchPrompt',
          'selectprompt' => 'Laravel\\Prompts\\SelectPrompt',
          'suggestprompt' => 'Laravel\\Prompts\\SuggestPrompt',
          'textareaprompt' => 'Laravel\\Prompts\\TextareaPrompt',
          'textprompt' => 'Laravel\\Prompts\\TextPrompt',
          'stdclass' => 'stdClass',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'multiselectFallback',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\ConfiguresPrompts',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\ConfiguresPrompts',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'e1a6fac2afcf995aad188fa743cbfe57' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'completioninput' => 'Symfony\\Component\\Console\\Completion\\CompletionInput',
          'completionsuggestions' => 'Symfony\\Component\\Console\\Completion\\CompletionSuggestions',
          'suggestion' => 'Symfony\\Component\\Console\\Completion\\Suggestion',
          'inputargument' => 'Symfony\\Component\\Console\\Input\\InputArgument',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\HasParameters',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\HasParameters',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'aad25deaf481115fa08505e9d3dc68d4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'completioninput' => 'Symfony\\Component\\Console\\Completion\\CompletionInput',
          'completionsuggestions' => 'Symfony\\Component\\Console\\Completion\\CompletionSuggestions',
          'suggestion' => 'Symfony\\Component\\Console\\Completion\\Suggestion',
          'inputargument' => 'Symfony\\Component\\Console\\Input\\InputArgument',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'specifyParameters',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\HasParameters',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\HasParameters',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'e25c7cafbbb275a6d68ede5aff72a52d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'completioninput' => 'Symfony\\Component\\Console\\Completion\\CompletionInput',
          'completionsuggestions' => 'Symfony\\Component\\Console\\Completion\\CompletionSuggestions',
          'suggestion' => 'Symfony\\Component\\Console\\Completion\\Suggestion',
          'inputargument' => 'Symfony\\Component\\Console\\Input\\InputArgument',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'getArguments',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\HasParameters',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\HasParameters',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '6f6938b036248a9a80278814970c73ce' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'completioninput' => 'Symfony\\Component\\Console\\Completion\\CompletionInput',
          'completionsuggestions' => 'Symfony\\Component\\Console\\Completion\\CompletionSuggestions',
          'suggestion' => 'Symfony\\Component\\Console\\Completion\\Suggestion',
          'inputargument' => 'Symfony\\Component\\Console\\Input\\InputArgument',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'getOptions',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\HasParameters',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\HasParameters',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '5bf65361a2a181e2f60ae5276203ee4f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '6a95359491f10906c89332a539fbbd87' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'hasArgument',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '19dcc4578340a8432d4957aa424d3a1e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'argument',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '86a85389a6aa234f3e3797298250428a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'arguments',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '4809b3fb3ed8adf6de3a72b043e85a00' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'hasOption',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'cdc478210d8044ae908e16b46df61962' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'option',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '0d050dacf35589e0e27e77e86f451e28' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'options',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'f2f9b11716099de81811922dc01f8d09' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'confirm',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'dee57e4693ada01ca7421aecd9a684a8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'ask',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'c38f231c1a4159811a02211ca35ae285' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'anticipate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'db2b4817d94b5c5f7725587460a41831' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'askWithCompletion',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '927968f850b76d2be43a487e2cdb6e11' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'secret',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'c1cfdbdb3a98cbc64d5fcd35177263a8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'choice',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '66bc577c1c7329d5a387c12b560ce10c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'table',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '149d31630cadd1dccedcb76208a65541' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'withProgressBar',
         'templatePhpDocNodes' => 
        array (
          'TKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TKey',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'array-key',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
          'TIterable' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TIterable',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\GenericTypeNode::__set_state(array(
                 'type' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'iterable',
                   'attributes' => 
                  array (
                    'startLine' => 6,
                    'endLine' => 6,
                  ),
                )),
                 'genericTypes' => 
                array (
                  0 => 
                  \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                     'name' => 'TKey',
                     'attributes' => 
                    array (
                      'startLine' => 6,
                      'endLine' => 6,
                    ),
                  )),
                  1 => 
                  \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                     'name' => 'TValue',
                     'attributes' => 
                    array (
                      'startLine' => 6,
                      'endLine' => 6,
                    ),
                  )),
                ),
                 'variances' => 
                array (
                  0 => 'invariant',
                  1 => 'invariant',
                ),
                 'attributes' => 
                array (
                  'startLine' => 6,
                  'endLine' => 6,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 6,
                'endLine' => 6,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'f67a0984249f55e17240ad12984e10e0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'info',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '41b763d2abd409198db5e3b7f4997151' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'line',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'b40ededd99d4b69ad6650ac0b4e89c42' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'comment',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'd047399d7a660a41e5d4e88562d76468' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'question',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'a12e9f673016f7cb5c497cf77d63ad44' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'error',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'cb049aed7eaa929373e0934f11cc8f88' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'warn',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '73eb6c4d6fa1a60206032cb75e25c784' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'alert',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '6eb5fe3322498142f227a52d80918185' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'newLine',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '711436efdcaf848b4b371424213a73be' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'setInput',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'f4ffd6a4dc93ab1361cdb88d2f28505e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'setOutput',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '3e262f4aaff704903103aab883e2b8bd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'setVerbosity',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '5004ff9ac71746f39e50373116d2e4f7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'parseVerbosity',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '382cfbe435e658b5e0fab9233fe599c2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'getOutput',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'b2956bda9c6a0accdb771d98456903cd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'outputstyle' => 'Illuminate\\Console\\OutputStyle',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'str' => 'Illuminate\\Support\\Str',
          'outputformatterstyle' => 'Symfony\\Component\\Console\\Formatter\\OutputFormatterStyle',
          'table' => 'Symfony\\Component\\Console\\Helper\\Table',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'choicequestion' => 'Symfony\\Component\\Console\\Question\\ChoiceQuestion',
          'question' => 'Symfony\\Component\\Console\\Question\\Question',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'outputComponents',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithIO',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'ea6e3caf959bf56725b4dbbea46cb2a2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'signals' => 'Illuminate\\Console\\Signals',
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithSignals',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithSignals',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'c87be8ca9e1818e3d9f182bf428e1868' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'signals' => 'Illuminate\\Console\\Signals',
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'trap',
         'templatePhpDocNodes' => 
        array (
          'TSignals' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TSignals',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\UnionTypeNode::__set_state(array(
                 'types' => 
                array (
                  0 => 
                  \PHPStan\PhpDocParser\Ast\Type\GenericTypeNode::__set_state(array(
                     'type' => 
                    \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                       'name' => 'iterable',
                       'attributes' => 
                      array (
                        'startLine' => 4,
                        'endLine' => 4,
                      ),
                    )),
                     'genericTypes' => 
                    array (
                      0 => 
                      \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                         'name' => 'array-key',
                         'attributes' => 
                        array (
                          'startLine' => 4,
                          'endLine' => 4,
                        ),
                      )),
                      1 => 
                      \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                         'name' => 'int',
                         'attributes' => 
                        array (
                          'startLine' => 4,
                          'endLine' => 4,
                        ),
                      )),
                    ),
                     'variances' => 
                    array (
                      0 => 'invariant',
                      1 => 'invariant',
                    ),
                     'attributes' => 
                    array (
                      'startLine' => 4,
                      'endLine' => 4,
                    ),
                  )),
                  1 => 
                  \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                     'name' => 'int',
                     'attributes' => 
                    array (
                      'startLine' => 4,
                      'endLine' => 4,
                    ),
                  )),
                ),
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithSignals',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithSignals',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '57ff3651fa6e8c589d4a69daa11dabf2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'signals' => 'Illuminate\\Console\\Signals',
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'untrap',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\InteractsWithSignals',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\InteractsWithSignals',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'fd5a02945a150d21f8e65989bf998b5b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'promptsformissinginputcontract' => 'Illuminate\\Contracts\\Console\\PromptsForMissingInput',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'inputargument' => 'Symfony\\Component\\Console\\Input\\InputArgument',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\PromptsForMissingInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\PromptsForMissingInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '9f4a4e25a599e9ffcfcca21fc5758855' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'promptsformissinginputcontract' => 'Illuminate\\Contracts\\Console\\PromptsForMissingInput',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'inputargument' => 'Symfony\\Component\\Console\\Input\\InputArgument',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'interact',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\PromptsForMissingInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\PromptsForMissingInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '7010e96a2aa3a990ebedbab0ee170f06' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'promptsformissinginputcontract' => 'Illuminate\\Contracts\\Console\\PromptsForMissingInput',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'inputargument' => 'Symfony\\Component\\Console\\Input\\InputArgument',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'promptForMissingArguments',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\PromptsForMissingInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\PromptsForMissingInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'aa205089ac22c9412a758f8945b41d32' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'promptsformissinginputcontract' => 'Illuminate\\Contracts\\Console\\PromptsForMissingInput',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'inputargument' => 'Symfony\\Component\\Console\\Input\\InputArgument',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'promptForMissingArgumentsUsing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\PromptsForMissingInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\PromptsForMissingInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'ecddbe2af6b92ae9b502193a2c8d2252' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'promptsformissinginputcontract' => 'Illuminate\\Contracts\\Console\\PromptsForMissingInput',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'inputargument' => 'Symfony\\Component\\Console\\Input\\InputArgument',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'afterPromptingForMissingArguments',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\PromptsForMissingInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\PromptsForMissingInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'd83e0e1fdc703a92dcf1d0f16d10e43e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console\\Concerns',
         'uses' => 
        array (
          'closure' => 'Closure',
          'promptsformissinginputcontract' => 'Illuminate\\Contracts\\Console\\PromptsForMissingInput',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'inputargument' => 'Symfony\\Component\\Console\\Input\\InputArgument',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'didReceiveOptions',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Console\\Concerns\\PromptsForMissingInput',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Console\\Concerns\\PromptsForMissingInput',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '10bca7fdbdc2f583696a26869940d97e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '1906d942b3a7fe40beb10baeae5c9234' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'macro',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'd265e07e283d440617bc010739a0c3f1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'mixin',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '5f523bbe0e375a7ada5dc80a7eb86df6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'hasMacro',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'ba1917f6033596a5083914f9ec5c965d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'flushMacros',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'bbce4cb5d4bf8f93f0863fba47f29e0e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => '__callStatic',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'ec35de6ba8c0a59f1f7dd4614b39b978' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => '__call',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php',
          1 => 'Illuminate\\Console\\Command',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'a29cfde49e3686ac30eb96645bbce78e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console',
         'uses' => 
        array (
          'factory' => 'Illuminate\\Console\\View\\Components\\Factory',
          'isolatable' => 'Illuminate\\Contracts\\Console\\Isolatable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'symfonycommand' => 'Symfony\\Component\\Console\\Command\\Command',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b1bad4f494c5ca73ae6acc0c7023379f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console',
         'uses' => 
        array (
          'factory' => 'Illuminate\\Console\\View\\Components\\Factory',
          'isolatable' => 'Illuminate\\Contracts\\Console\\Isolatable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'symfonycommand' => 'Symfony\\Component\\Console\\Command\\Command',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'configureUsingFluentDefinition',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '86779901a0d13a3c4cb84e74e33bb608' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console',
         'uses' => 
        array (
          'factory' => 'Illuminate\\Console\\View\\Components\\Factory',
          'isolatable' => 'Illuminate\\Contracts\\Console\\Isolatable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'symfonycommand' => 'Symfony\\Component\\Console\\Command\\Command',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'configureIsolation',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2d0ac6d638489af35c5a1947a3d52062' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console',
         'uses' => 
        array (
          'factory' => 'Illuminate\\Console\\View\\Components\\Factory',
          'isolatable' => 'Illuminate\\Contracts\\Console\\Isolatable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'symfonycommand' => 'Symfony\\Component\\Console\\Command\\Command',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'run',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3dca1cca44a6fc08763a61cdfa2ae802' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console',
         'uses' => 
        array (
          'factory' => 'Illuminate\\Console\\View\\Components\\Factory',
          'isolatable' => 'Illuminate\\Contracts\\Console\\Isolatable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'symfonycommand' => 'Symfony\\Component\\Console\\Command\\Command',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'execute',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '72e4553cbef660971036e2b9ad4e4b1d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console',
         'uses' => 
        array (
          'factory' => 'Illuminate\\Console\\View\\Components\\Factory',
          'isolatable' => 'Illuminate\\Contracts\\Console\\Isolatable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'symfonycommand' => 'Symfony\\Component\\Console\\Command\\Command',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'commandIsolationMutex',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1d6e41d6b6cd472ffc5e6356c7b76dab' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console',
         'uses' => 
        array (
          'factory' => 'Illuminate\\Console\\View\\Components\\Factory',
          'isolatable' => 'Illuminate\\Contracts\\Console\\Isolatable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'symfonycommand' => 'Symfony\\Component\\Console\\Command\\Command',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'resolveCommand',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9e99e6df288b709907061f73db6a12c2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console',
         'uses' => 
        array (
          'factory' => 'Illuminate\\Console\\View\\Components\\Factory',
          'isolatable' => 'Illuminate\\Contracts\\Console\\Isolatable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'symfonycommand' => 'Symfony\\Component\\Console\\Command\\Command',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'fail',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f20f0ed8ad94a2a91e8352abd37316b5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console',
         'uses' => 
        array (
          'factory' => 'Illuminate\\Console\\View\\Components\\Factory',
          'isolatable' => 'Illuminate\\Contracts\\Console\\Isolatable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'symfonycommand' => 'Symfony\\Component\\Console\\Command\\Command',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'isHidden',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fc8311444c051966795d81127dbdddc6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console',
         'uses' => 
        array (
          'factory' => 'Illuminate\\Console\\View\\Components\\Factory',
          'isolatable' => 'Illuminate\\Contracts\\Console\\Isolatable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'symfonycommand' => 'Symfony\\Component\\Console\\Command\\Command',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'setHidden',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5147e30e701a9a119eb5f924f5350c3e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console',
         'uses' => 
        array (
          'factory' => 'Illuminate\\Console\\View\\Components\\Factory',
          'isolatable' => 'Illuminate\\Contracts\\Console\\Isolatable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'symfonycommand' => 'Symfony\\Component\\Console\\Command\\Command',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'getLaravel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'db19c1522a757e210a4b46a03d5deedf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Console',
         'uses' => 
        array (
          'factory' => 'Illuminate\\Console\\View\\Components\\Factory',
          'isolatable' => 'Illuminate\\Contracts\\Console\\Isolatable',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'symfonycommand' => 'Symfony\\Component\\Console\\Command\\Command',
          'inputinterface' => 'Symfony\\Component\\Console\\Input\\InputInterface',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
          'outputinterface' => 'Symfony\\Component\\Console\\Output\\OutputInterface',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Console\\Command',
         'functionName' => 'setLaravel',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Console/Command.php' => '34cce221b150a23e403701aca08a934ea6d313cd3c627194c3b1f1a8ea52d89e',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Console/Concerns/CallsCommands.php' => '5d183902da1b6e9ac7f07b573c98094f514f0fc9edd96ae7fecf3cc7e4d9fc62',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Console/Concerns/ConfiguresPrompts.php' => '6bedfb55d8f7db3e278de8f89d9b886a8c394a43b226212070f3a4a7e77e56c1',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Console/Concerns/HasParameters.php' => '22e973525cd606a721f500ccd8950b956fd2360301f3e3fb0b964bfb37d7bb62',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Console/Concerns/InteractsWithIO.php' => 'df2cda3a62b98915ab72eb4361b57cbd878f9d77c49976a7327adfc6bcdd7606',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Console/Concerns/InteractsWithSignals.php' => 'b5cbab30713dd9b48178b8ad13186fb62f9d9fbdf0407a8827b9c84a5773cb28',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Console/Concerns/PromptsForMissingInput.php' => 'b64deca387ae959be0bc7885518aad8521b65f300cbb7ac4efb46d3de2aaff35',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Macroable/Traits/Macroable.php' => '6dd85b1e28b55ebeee678f9ca423dfb8375e1342bc42d8658da6321bdf97b3c0',
    ),
  ),
));