<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Foundation/Console/ProviderMakeCommand.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-bdf3eeb481ef64cc253179d6d2224a1eda1e3d852f655fba425241e125556672-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\foundation\\console\\providermakecommand' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));