<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Support/Manager.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-b1c2789067e4e933c84711d0ed646bb4358c0a0296df8cca54c8660251cbe351-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\support\\manager' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));