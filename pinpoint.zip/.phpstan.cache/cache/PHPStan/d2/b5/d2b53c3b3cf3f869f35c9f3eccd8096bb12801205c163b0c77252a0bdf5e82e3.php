<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Database/Eloquent/Concerns/GuardsAttributes.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-0ffecda662a87c4f7f925fff5f788542be48c5fb0ec3f16828e507f865719010-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\database\\eloquent\\concerns\\guardsattributes' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));