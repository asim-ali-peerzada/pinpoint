<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../spatie/laravel-package-tools/src/Concerns/PackageServiceProvider/ProcessTranslations.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-fde33f15f903cb12ddb5aea24534f9e0c7bbea3821d3095754451570ec5525e0-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'spatie\\laravelpackagetools\\concerns\\packageserviceprovider\\processtranslations' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));