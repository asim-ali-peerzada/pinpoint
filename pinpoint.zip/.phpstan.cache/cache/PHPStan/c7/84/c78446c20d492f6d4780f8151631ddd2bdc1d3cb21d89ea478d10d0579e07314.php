<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../spatie/laravel-package-tools/src/Concerns/PackageServiceProvider/ProcessBladeComponents.php-PHPStan\BetterReflection\Reflection\ReflectionClass-Spatie\LaravelPackageTools\Concerns\PackageServiceProvider\ProcessBladeComponents
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-67707c0d6e73d880f03124559679925bf6319f6fa613709329fdf61005a7c6eb-8.2.33-6.70.0.3',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'Spatie\\LaravelPackageTools\\Concerns\\PackageServiceProvider\\ProcessBladeComponents',
        'filename' => '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../spatie/laravel-package-tools/src/Concerns/PackageServiceProvider/ProcessBladeComponents.php',
      ),
    ),
    'namespace' => 'Spatie\\LaravelPackageTools\\Concerns\\PackageServiceProvider',
    'name' => 'Spatie\\LaravelPackageTools\\Concerns\\PackageServiceProvider\\ProcessBladeComponents',
    'shortName' => 'ProcessBladeComponents',
    'isInterface' => false,
    'isTrait' => true,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 0,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 5,
    'endLine' => 26,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => NULL,
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      'bootPackageBladeComponents' => 
      array (
        'name' => 'bootPackageBladeComponents',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'self',
            'isIdentifier' => false,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 7,
        'endLine' => 25,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'Spatie\\LaravelPackageTools\\Concerns\\PackageServiceProvider',
        'declaringClassName' => 'Spatie\\LaravelPackageTools\\Concerns\\PackageServiceProvider\\ProcessBladeComponents',
        'implementingClassName' => 'Spatie\\LaravelPackageTools\\Concerns\\PackageServiceProvider\\ProcessBladeComponents',
        'currentClassName' => 'Spatie\\LaravelPackageTools\\Concerns\\PackageServiceProvider\\ProcessBladeComponents',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));