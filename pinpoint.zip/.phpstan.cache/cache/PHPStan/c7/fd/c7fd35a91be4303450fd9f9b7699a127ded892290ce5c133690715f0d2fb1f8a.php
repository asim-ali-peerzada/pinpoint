<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Http/ResponseTrait.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-3c82814621299a17a9b8a37120e8d4d669b34e9628a866009d671fd1ff3c54ed-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\http\\responsetrait' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));