<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Database/DatabaseManager.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-dadfa950307fdd97d377a3c2ff2553036da0b9d04e9a0951ffe435ecbcca3a70-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\database\\databasemanager' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));