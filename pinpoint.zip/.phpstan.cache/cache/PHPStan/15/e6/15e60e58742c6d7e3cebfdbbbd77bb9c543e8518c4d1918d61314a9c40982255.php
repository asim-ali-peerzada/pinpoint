<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Contracts/Config/Repository.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      '1a51563707dac0ee72c9cd1ed603512b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Config',
         'uses' => 
        array (
        ),
         'className' => 'Illuminate\\Contracts\\Config\\Repository',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a9e6080bdc2f3e0ff13917705b078372' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Config',
         'uses' => 
        array (
        ),
         'className' => 'Illuminate\\Contracts\\Config\\Repository',
         'functionName' => 'has',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'efd65c968e78e1ca3e6298e8b1199320' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Config',
         'uses' => 
        array (
        ),
         'className' => 'Illuminate\\Contracts\\Config\\Repository',
         'functionName' => 'get',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4e8453b403394ad1a82604e5b22693e2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Config',
         'uses' => 
        array (
        ),
         'className' => 'Illuminate\\Contracts\\Config\\Repository',
         'functionName' => 'all',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4a47b9f0d5ff343833f8bfac705dbdea' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Config',
         'uses' => 
        array (
        ),
         'className' => 'Illuminate\\Contracts\\Config\\Repository',
         'functionName' => 'set',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd645b42e46969a3d979f699b19c9a346' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Config',
         'uses' => 
        array (
        ),
         'className' => 'Illuminate\\Contracts\\Config\\Repository',
         'functionName' => 'prepend',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '288eb7487d6563547e0171c6c0f02743' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Config',
         'uses' => 
        array (
        ),
         'className' => 'Illuminate\\Contracts\\Config\\Repository',
         'functionName' => 'push',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Contracts/Config/Repository.php' => '256287ff0d7ee0462348a64cdc3fd59f065e9ed7d21b2621e1a6706d2239fd51',
    ),
  ),
));