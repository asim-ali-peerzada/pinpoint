<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Container/Container.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      '95dbb89bb33d59ab14d7312751599e29' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cdbdd72a871b974c2b271f86f943c452' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'closure' => 'Closure',
          'collection' => 'Illuminate\\Support\\Collection',
          'reflector' => 'Illuminate\\Support\\Reflector',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionintersectiontype' => 'ReflectionIntersectionType',
          'reflectionuniontype' => 'ReflectionUnionType',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Container/Container.php',
          1 => 'Illuminate\\Container\\Container',
          2 => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '82ece0566e0563db801ca9886eadae10' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'closure' => 'Closure',
          'collection' => 'Illuminate\\Support\\Collection',
          'reflector' => 'Illuminate\\Support\\Reflector',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionintersectiontype' => 'ReflectionIntersectionType',
          'reflectionuniontype' => 'ReflectionUnionType',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'firstClosureParameterType',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Container/Container.php',
          1 => 'Illuminate\\Container\\Container',
          2 => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'ebc510f5cd167e99599485e416607661' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'closure' => 'Closure',
          'collection' => 'Illuminate\\Support\\Collection',
          'reflector' => 'Illuminate\\Support\\Reflector',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionintersectiontype' => 'ReflectionIntersectionType',
          'reflectionuniontype' => 'ReflectionUnionType',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'firstClosureParameterTypes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Container/Container.php',
          1 => 'Illuminate\\Container\\Container',
          2 => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'f03b1cf22ebfa8ce67a43380a71eac54' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'closure' => 'Closure',
          'collection' => 'Illuminate\\Support\\Collection',
          'reflector' => 'Illuminate\\Support\\Reflector',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionintersectiontype' => 'ReflectionIntersectionType',
          'reflectionuniontype' => 'ReflectionUnionType',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'closureParameterTypes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Container/Container.php',
          1 => 'Illuminate\\Container\\Container',
          2 => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '7b3c73c7d45b8ca092d35e363746bf38' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'closure' => 'Closure',
          'collection' => 'Illuminate\\Support\\Collection',
          'reflector' => 'Illuminate\\Support\\Reflector',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionintersectiontype' => 'ReflectionIntersectionType',
          'reflectionuniontype' => 'ReflectionUnionType',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'closureReturnTypes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Container/Container.php',
          1 => 'Illuminate\\Container\\Container',
          2 => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'cd0d86755bdef8de17189d6c7f30d78d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'when',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1233895730451d61aac3462e231087e1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'whenHasAttribute',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd474b842c5b8272b445fd6b7c7d659cf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'bound',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2c05cf9ece660f28bcccb00263a848ca' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'has',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5ec295715443e69a02e098b44f059755' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'resolved',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b57e261d6103f12d1fccb529c340904d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'isShared',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f1066a8f55e399f8a83e4e61a6a43bf2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'getScopedTyped',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '65ec8b7b9e9099a3b3087ea48f7d25a6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'isAlias',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b4c689fbf38313c5afd1e29af4698f51' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'bind',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5b4f6195a7d8080c820f3a2468570424' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'getClosure',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fce7ae4964723c52101d60f0794c0424' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'hasMethodBinding',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'adefea5caa210da9117cee288d14a4ba' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'bindMethod',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dd91184a84cad7f6fabfb20e4e2b5e20' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'parseBindMethod',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '81f78764049e911baf3573440731117b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'callMethodBinding',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3f9f2935aacebaae3d8447d772234e2c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'addContextualBinding',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '546feb77ec1397b9721a7fccc8188654' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'bindIf',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '346bd2fbdf6e7a45acbed27791c59fde' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'singleton',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a20e607d492a3638e33407ff9d9f9e7f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'singletonIf',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c4d26cdb07d488d783b811de39e6f00c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'scoped',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '06f520772d94a76ecbdfd3b3a7f4106c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'scopedIf',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e5237147b477425fc9c3beedc1fd3937' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'bindBasedOnClosureReturnTypes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ea36cdbcaf37c5826b069c51249128fa' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'extend',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4e03e58dd1005a21947e628f880b44ee' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'instance',
         'templatePhpDocNodes' => 
        array (
          'TInstance' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TInstance',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'mixed',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '976105c967abba99de01b5a94180410f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'removeAbstractAlias',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f039725865b796f303f4d6522a26d892' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'tag',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '14c0271ed0f74de0427f96342aee3fe1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'tagged',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e2b9d6387ad2c8ee2611e34d2dbbfe03' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'alias',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '040b84235f083f0b4710d3f68d0ed842' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'rebinding',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f263b01ffe543fab8a64dd09f31b342e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'refresh',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '52bb4c6baf16f3749ea15dfaca4b835b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'rebound',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8bbd6e16d50436c811b74456e81d219b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'getReboundCallbacks',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '47b0949ec527c8f53f5f3c79fa141438' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'wrap',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '083878becfd889514464f8641aa75b69' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'call',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '697752e769efba94a233698d4d021325' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'getClassForCallable',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e7705890d5dd4c2f6351e7f8afd84b3a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'factory',
         'templatePhpDocNodes' => 
        array (
          'TClass' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TClass',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'object',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '95f869a3d2a0dd2408dd2940c96908df' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'makeWith',
         'templatePhpDocNodes' => 
        array (
          'TClass' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TClass',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'object',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f3f16fff616c5bd03cbcfde5dcc01b14' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'make',
         'templatePhpDocNodes' => 
        array (
          'TClass' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TClass',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'object',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6284e33439bae1bf59a74aa23d566e0b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'get',
         'templatePhpDocNodes' => 
        array (
          'TClass' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TClass',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'object',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '29a2c3b5a268421ed3b23520b4e1970b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'resolve',
         'templatePhpDocNodes' => 
        array (
          'TClass' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TClass',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'object',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '48188c2aa003339d87a2e73eb1b6f48d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'getConcrete',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cc3f5cd77965049eedd52af849a80dc4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'getConcreteBindingFromAttributes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4af5a91cb4680222f8f1670c54ffc00b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'getContextualConcrete',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8c189c562e9c2b939f01c48d5278bc7a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'findInContextualBindings',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3e5d55a2aaeea249900c7518e4761403' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'isBuildable',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7a4ec07d3250e58ea8d1dc2b68aa428a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'build',
         'templatePhpDocNodes' => 
        array (
          'TClass' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TClass',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'object',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f692739e9299677498d0325b61b8f4da' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'buildSelfBuildingInstance',
         'templatePhpDocNodes' => 
        array (
          'TClass' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TClass',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'object',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8847a812f0f5078dd986c47bb9be6d19' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'resolveDependencies',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd88d53504ccb1e2d1f1a5ebd5735ec2e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'hasParameterOverride',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c1d71be0af8d487d38402702fbbac730' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'getParameterOverride',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '51e85b79ccdeaf22fc04044e42a959b1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'getLastParameterOverride',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c03717f0e8921c6f78d87eee7d6402c7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'resolvePrimitive',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6aaf96f080b57c761e1d12d73dee2e3e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'resolveClass',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a78147ea204e26d8fc24ff9d5e728c9f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'resolveVariadicClass',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '97747decdfdfd741c92e2ff86f7e915c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'resolveFromAttribute',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2e7287187d606ae421a02828a21fdf65' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'notInstantiable',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6bc5564b545ac125c6e0b9c5db643d2c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'unresolvablePrimitive',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '324bf8a8e6f6d058a89bd30dcbebdccd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'beforeResolving',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '07da3bad215fea38f4d3630a570a0fdd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'resolving',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '025dea47ff0ec102e66b6d143516177e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'afterResolving',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '294b8084e07a5934349f5255137e175a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'afterResolvingAttribute',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3ade5ff1676c533a2a44a8912a548c0e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'fireBeforeResolvingCallbacks',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4a8dfe6d99b6260b9e6a6d74cc19cbf5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'fireBeforeCallbackArray',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'aa2e9f3fc5729640c391794d04a7cf85' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'fireResolvingCallbacks',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b1779f47d13724a21a5bc64c3517fc19' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'fireAfterResolvingCallbacks',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b690fe73567260ddc79d4bdc39e74a3a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'fireAfterResolvingAttributeCallbacks',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '81972325c7dba344d1a9da552a4e6d11' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'getCallbacksForType',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2666c43aaea16147b8ce2ba188853273' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'fireCallbackArray',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '43f5619af67e5608fd0d97f8e82be118' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'currentlyResolving',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'af4661231e9053a035051a037775f79e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'getBindings',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '352cb4f370ade157f4b3bef604c480b9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'getAlias',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1d2466ff74de6b6840a4b9f063e17470' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'getExtenders',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '58c6301d18b72365fbc4029d8bec16f9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'forgetExtenders',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8591509728bdb2f70b9dd0dc41d342ab' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'dropStaleInstances',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dd4b2b86411af2d7227a69b5ecb10d80' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'forgetInstance',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7e951806c4c9127d2a261526af5dcd84' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'forgetInstances',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cc56d6b3a326b4375c782e2249cc44fc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'forgetScopedInstances',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6701101fb31d53a4b2aa01bddb24d910' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'resolveEnvironmentUsing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8d2466e16bb4a0ff8134f89ecdf09467' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'currentEnvironmentIs',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '88b257e4929ba2fd6e767a80e316523f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'flush',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '698efab4fbcbccd0c0556ca2dcd2d828' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'getInstance',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ef5d8385d4ea8208be925a9424c17566' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'setInstance',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cb281895c601b37a54a6a6fe5c969ad9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'offsetExists',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5b49b291cf09666a809d84feaa3ffb56' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'offsetGet',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1775744ba70567dafbcc10d900b76ab1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'offsetSet',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e95391c945957a9cedcc3a2896742226' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => 'offsetUnset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd4193acb5527053ce48099494ef25e70' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => '__get',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ddd2271d4da19048195f202968556b05' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Container',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'bind' => 'Illuminate\\Container\\Attributes\\Bind',
          'scoped' => 'Illuminate\\Container\\Attributes\\Scoped',
          'singleton' => 'Illuminate\\Container\\Attributes\\Singleton',
          'bindingresolutionexception' => 'Illuminate\\Contracts\\Container\\BindingResolutionException',
          'circulardependencyexception' => 'Illuminate\\Contracts\\Container\\CircularDependencyException',
          'containercontract' => 'Illuminate\\Contracts\\Container\\Container',
          'contextualattribute' => 'Illuminate\\Contracts\\Container\\ContextualAttribute',
          'selfbuilding' => 'Illuminate\\Contracts\\Container\\SelfBuilding',
          'reflectsclosures' => 'Illuminate\\Support\\Traits\\ReflectsClosures',
          'logicexception' => 'LogicException',
          'reflectionattribute' => 'ReflectionAttribute',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'reflectionfunction' => 'ReflectionFunction',
          'reflectionparameter' => 'ReflectionParameter',
          'typeerror' => 'TypeError',
        ),
         'className' => 'Illuminate\\Container\\Container',
         'functionName' => '__set',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Container/Container.php' => 'fae6eca6d7d0421c9d9d237349eb91ecdd5b33caebfa6fe3befc019f5f57daf8',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Reflection/Traits/ReflectsClosures.php' => '4d423d1cc3170c4f64eb58a49f80bc7d841684c63ad46c9a97ffab5d82c9e365',
    ),
  ),
));