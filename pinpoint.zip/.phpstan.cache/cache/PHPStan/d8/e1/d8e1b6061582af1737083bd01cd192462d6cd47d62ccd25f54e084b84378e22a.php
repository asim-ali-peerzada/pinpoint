<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/larastan/larastan/stubs/common/Contracts/Container.stub
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      'febdd28f9409fcbb02096dc092c33420' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '95d626144ed6d4855699b890382bb69e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Foundation',
         'uses' => 
        array (
        ),
         'className' => 'Illuminate\\Contracts\\Foundation\\Application',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/larastan/larastan/stubs/common/Contracts/Container.stub' => '6fb925c4401c1a5d96df59ccf09a19c610737b30c50b9de0f59338ea49ce7d79',
    ),
  ),
));