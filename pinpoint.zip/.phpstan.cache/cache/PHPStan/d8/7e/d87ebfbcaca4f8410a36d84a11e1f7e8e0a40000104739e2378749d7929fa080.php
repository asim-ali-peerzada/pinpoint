<?php declare(strict_types = 1);

// odsl-/mnt/workspace/Personal-Projects/sentinel/src/Internal/Recorder.php-PHPStan\BetterReflection\Reflection\ReflectionClass-AsimAli\Pinpoint\Internal\Recorder
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.3-8.2.33-d8bedea5807ca3fc4d0b063f8037f30b2b480c7ff5ee451d9ec76a505e1e1ac8',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'filename' => '/mnt/workspace/Personal-Projects/sentinel/src/Internal/Recorder.php',
      ),
    ),
    'namespace' => 'AsimAli\\Pinpoint\\Internal',
    'name' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
    'shortName' => 'Recorder',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 0,
    'docComment' => '/**
 * @internal The recorder is not part of Pinpoint\'s public API contract.
 */',
    'attributes' => 
    array (
    ),
    'startLine' => 12,
    'endLine' => 121,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => NULL,
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
      'queries' => 
      array (
        'declaringClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'name' => 'queries',
        'modifiers' => 2,
        'type' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'array',
            'isIdentifier' => true,
          ),
        ),
        'default' => 
        array (
          'code' => '[]',
          'attributes' => 
          array (
            'startLine' => 15,
            'endLine' => 15,
            'startTokenPos' => 44,
            'startFilePos' => 422,
            'endTokenPos' => 45,
            'endFilePos' => 423,
          ),
        ),
        'docComment' => '/** @var array<int, array{sql: string, fingerprint: string, time_ms: float, caller: array{file: string, line: int}|null}> */',
        'attributes' => 
        array (
        ),
        'startLine' => 15,
        'endLine' => 15,
        'startColumn' => 5,
        'endColumn' => 34,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'lazyLoads' => 
      array (
        'declaringClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'name' => 'lazyLoads',
        'modifiers' => 2,
        'type' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'array',
            'isIdentifier' => true,
          ),
        ),
        'default' => 
        array (
          'code' => '[]',
          'attributes' => 
          array (
            'startLine' => 18,
            'endLine' => 18,
            'startTokenPos' => 58,
            'startFilePos' => 527,
            'endTokenPos' => 59,
            'endFilePos' => 528,
          ),
        ),
        'docComment' => '/** @var array<int, array{model: string, relation: string}> */',
        'attributes' => 
        array (
        ),
        'startLine' => 18,
        'endLine' => 18,
        'startColumn' => 5,
        'endColumn' => 36,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'config' => 
      array (
        'declaringClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'name' => 'config',
        'modifiers' => 2,
        'type' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'Illuminate\\Contracts\\Config\\Repository',
            'isIdentifier' => false,
          ),
        ),
        'default' => NULL,
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 20,
        'endLine' => 20,
        'startColumn' => 33,
        'endColumn' => 56,
        'isPromoted' => true,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
    ),
    'immediateMethods' => 
    array (
      '__construct' => 
      array (
        'name' => '__construct',
        'parameters' => 
        array (
          'config' => 
          array (
            'name' => 'config',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'Illuminate\\Contracts\\Config\\Repository',
                'isIdentifier' => false,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => true,
            'attributes' => 
            array (
            ),
            'startLine' => 20,
            'endLine' => 20,
            'startColumn' => 33,
            'endColumn' => 56,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 20,
        'endLine' => 20,
        'startColumn' => 5,
        'endColumn' => 60,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'AsimAli\\Pinpoint\\Internal',
        'declaringClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'currentClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'aliasName' => NULL,
      ),
      'isRecording' => 
      array (
        'name' => 'isRecording',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'bool',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 22,
        'endLine' => 25,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'AsimAli\\Pinpoint\\Internal',
        'declaringClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'currentClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'aliasName' => NULL,
      ),
      'capturesCaller' => 
      array (
        'name' => 'capturesCaller',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'bool',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 27,
        'endLine' => 32,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'AsimAli\\Pinpoint\\Internal',
        'declaringClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'currentClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'aliasName' => NULL,
      ),
      'shouldRecord' => 
      array (
        'name' => 'shouldRecord',
        'parameters' => 
        array (
          'request' => 
          array (
            'name' => 'request',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'Illuminate\\Http\\Request',
                'isIdentifier' => false,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 34,
            'endLine' => 34,
            'startColumn' => 34,
            'endColumn' => 49,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'bool',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 34,
        'endLine' => 41,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'AsimAli\\Pinpoint\\Internal',
        'declaringClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'currentClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'aliasName' => NULL,
      ),
      'recordQuery' => 
      array (
        'name' => 'recordQuery',
        'parameters' => 
        array (
          'query' => 
          array (
            'name' => 'query',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'array',
                'isIdentifier' => true,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 43,
            'endLine' => 43,
            'startColumn' => 33,
            'endColumn' => 44,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 43,
        'endLine' => 46,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'AsimAli\\Pinpoint\\Internal',
        'declaringClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'currentClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'aliasName' => NULL,
      ),
      'recordLazyLoad' => 
      array (
        'name' => 'recordLazyLoad',
        'parameters' => 
        array (
          'model' => 
          array (
            'name' => 'model',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'string',
                'isIdentifier' => true,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 48,
            'endLine' => 48,
            'startColumn' => 36,
            'endColumn' => 48,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'relation' => 
          array (
            'name' => 'relation',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'string',
                'isIdentifier' => true,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 48,
            'endLine' => 48,
            'startColumn' => 51,
            'endColumn' => 66,
            'parameterIndex' => 1,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 48,
        'endLine' => 51,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'AsimAli\\Pinpoint\\Internal',
        'declaringClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'currentClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'aliasName' => NULL,
      ),
      'flush' => 
      array (
        'name' => 'flush',
        'parameters' => 
        array (
          'request' => 
          array (
            'name' => 'request',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'array',
                'isIdentifier' => true,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 53,
            'endLine' => 53,
            'startColumn' => 27,
            'endColumn' => 40,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 53,
        'endLine' => 82,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'AsimAli\\Pinpoint\\Internal',
        'declaringClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'currentClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'aliasName' => NULL,
      ),
      'reset' => 
      array (
        'name' => 'reset',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 84,
        'endLine' => 88,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'AsimAli\\Pinpoint\\Internal',
        'declaringClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'currentClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'aliasName' => NULL,
      ),
      'hasNPlusOne' => 
      array (
        'name' => 'hasNPlusOne',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'bool',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 90,
        'endLine' => 101,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'AsimAli\\Pinpoint\\Internal',
        'declaringClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'currentClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'aliasName' => NULL,
      ),
      'repeatCounts' => 
      array (
        'name' => 'repeatCounts',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'array',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 103,
        'endLine' => 110,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'AsimAli\\Pinpoint\\Internal',
        'declaringClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'currentClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'aliasName' => NULL,
      ),
      'lazyLoads' => 
      array (
        'name' => 'lazyLoads',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'array',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 112,
        'endLine' => 115,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'AsimAli\\Pinpoint\\Internal',
        'declaringClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'currentClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'aliasName' => NULL,
      ),
      'queries' => 
      array (
        'name' => 'queries',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'array',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 117,
        'endLine' => 120,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'AsimAli\\Pinpoint\\Internal',
        'declaringClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'currentClassName' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));