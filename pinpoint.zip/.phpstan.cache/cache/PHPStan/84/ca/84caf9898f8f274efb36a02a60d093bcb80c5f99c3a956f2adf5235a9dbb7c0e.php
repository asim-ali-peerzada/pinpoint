<?php declare(strict_types = 1);

// ftm-phar:///mnt/workspace/Personal-Projects/sentinel/vendor/phpstan/phpstan/phpstan.phar/vendor/jetbrains/phpstorm-stubs/date/date_c.stub
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      'c846c58499564339827f60e74231ff88' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeInterface',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e6e6d4b0b57e14d56349a2e8b78ed695' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeInterface',
         'functionName' => 'diff',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeInterface',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9fdb1d2d806db31327574951dc4e40f5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeInterface',
         'functionName' => 'format',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeInterface',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9b54cdf85cdf218699f64eec9a062d07' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeInterface',
         'functionName' => 'getOffset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeInterface',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4d034cae4e216aa41cbc221b69f151de' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeInterface',
         'functionName' => 'getTimestamp',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeInterface',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8873002160a0c44cb896a945ef01e422' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeInterface',
         'functionName' => 'getTimezone',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeInterface',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '68c66c236cb6dc1c72dd0755dd79ba00' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeInterface',
         'functionName' => '__wakeup',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeInterface',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7a011ae2e9960fc81afaf1f5757f29be' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeInterface',
         'functionName' => '__serialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeInterface',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2d76d05cb7af61c055172cb8976c93d5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeInterface',
         'functionName' => '__unserialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeInterface',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e59225b9398471d8f8e0bde076f3fd3b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeInterface',
         'functionName' => 'getMicrosecond',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeInterface',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '37c4359c5d37de7fa7b763f47cdf97ca' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'af57b8f96db1afe5822388f72369e820' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c6c6415f91c5d12dd06909463b2c2c13' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => 'add',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '66abf6c037cff0993a73e180e03e0bfa' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => 'createFromFormat',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0b4ac890075274dc7dcbca5e9f6c8a3b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => 'createFromMutable',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '137f9c13392c9a0b6cb6c713d38f46fa' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => 'getLastErrors',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f15b031e5a7efeaeb88f719c7def3d0d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => 'modify',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1253029462adb42b0c75d4e5a4dfb450' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => '__set_state',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4a4438e5f46006435ef7b06de7bffa78' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => 'setDate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2faa83f428916d2c37907184e847dfd3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => 'setISODate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3e02835cda0e59f6f9593cdecb15f5ad' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => 'setTime',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fb734b27f2d71394c48c9df02dacbe5d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => 'setTimestamp',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '06cffdac325a82a6245f282d5924ae8f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => 'setTimezone',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd0a404551e1eabb184b49adae5e5094a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => 'sub',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd43e68bf514351e8ec2ce0c3d308bd44' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => 'diff',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4378ea33b87f67bc86edd626b1fafd61' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => 'format',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9a231d7f409e96eeb20686fdc0704fd5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => 'getOffset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f0ec54dc8ae5320c3716cfa791f9290a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => 'getTimestamp',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ae4a9e1fad6ade8efe604907712f5c99' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => 'getTimezone',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fa1c664bfce5b692d199b4076ac62812' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => '__wakeup',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ad625eb04abf771c6f7bb7d3e97c064e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => 'createFromInterface',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '07b39f17e26f23f383a7a3403b9b96ce' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => '__serialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '739e9b592e44362a347e540b2e7a88c1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => '__unserialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8671c90c59617c459fd28283ada8553d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => 'createFromTimestamp',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '14bed061e4cfa318e77adb8f2cd61bcf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => 'getMicrosecond',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ccf8c6317f1f47260cb5e5fcafdaaec0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeImmutable',
         'functionName' => 'setMicrosecond',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeImmutable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3660f4d92fbf34cb9bbfbfd44bc0b6bb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0196c67f95a7c29c3836db9ee91cbefd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fa17ffe4274518fb539b912023e0d2cc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => '__wakeup',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ae3701529d90cb61637c0a3acee76b0e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => 'format',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4036f09793e064469d6c52570de71593' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => 'modify',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3497f1d8f5f85c7de91475ecf9818e74' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => 'add',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c107eca1f5f4249d51f5af6f0d9b3316' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => 'createFromImmutable',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2c953b7196af1e195875f67686972ed6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => 'sub',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1a8de2304785e312bd51a7341d193d2a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => 'getTimezone',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '46269797f466e8c7103be5597690d95b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => 'setTimezone',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ecee0ebffd953d2554b9f44845dbf06b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => 'getOffset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'be1041e3bfaadba6ab02fbdd5beadbc5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => 'setTime',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e25b10f1d9ea69301508871596457acb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => 'setDate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd3b57ec146c0dd721050595e946dae41' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => 'setISODate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '95c0cb2a3f9157584cc4f08b219abecf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => 'setTimestamp',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '361d117bb621b4c9033ea64e11fdb411' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => 'getTimestamp',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '26105da24a3ceea379dfe5fe618b5552' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => 'diff',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0af1281a57a65b833443b884b8dd3f60' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => 'createFromFormat',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '24d604806ab4866150282d1f3c686976' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => 'getLastErrors',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c27ac7d2cbf1c7ce9ebd2a03a2ccd346' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => '__set_state',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '06f9b27541fb04672ccb7fddc28d3929' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => 'createFromInterface',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6119d3b1c5ea03b9ddb547f019cb1392' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => '__serialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '669ac346b07530a34e2cf0482cad48ae' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => '__unserialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7f790edba03cf4d92d95393dc6c9ba80' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => 'createFromTimestamp',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b3c0414bc59f46c90567c06dd1a591fa' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => 'getMicrosecond',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dc99ab9362403fb2720eaa3513ed4aeb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTime',
         'functionName' => 'setMicrosecond',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTime',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '308d6f3cbda6d36ba95ef9ee6b9fde4f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeZone',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '182971fb0619ad27c9e827aee37448a7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeZone',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeZone',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ede5522a4af1a6c86cf984d6ef151fc7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeZone',
         'functionName' => 'getName',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeZone',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '777db65ab023066e71c3c0312274bd69' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeZone',
         'functionName' => 'getLocation',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeZone',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '39860184b5884eb2cf53d3284277e047' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeZone',
         'functionName' => 'getOffset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeZone',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bdfc8bf6ad44d20585ca9a97ef3b0b7f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeZone',
         'functionName' => 'getTransitions',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeZone',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6fe30e1408fca93f2c1f582ce17e882e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeZone',
         'functionName' => 'listAbbreviations',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeZone',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cb150a1338d1744f86ef23e58787fe09' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeZone',
         'functionName' => 'listIdentifiers',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeZone',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '63bd78a3b40608f8eec976c3b745a909' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeZone',
         'functionName' => '__wakeup',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeZone',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '99905712a47a6d1918bab17dd0b604e6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeZone',
         'functionName' => '__set_state',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeZone',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b0d34dc13d07bf4f171ad82f02231fb4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeZone',
         'functionName' => '__serialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeZone',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3667ded75a8a0d83710ad07bc0e102d7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateTimeZone',
         'functionName' => '__unserialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateTimeZone',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5d8236212a489dac80bde04219a95e77' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateInterval',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e72c07593e36e933623c4c24d446fef6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateInterval',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateInterval',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e3664c9d0cd8ade92c391ef8ba49f9b1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateInterval',
         'functionName' => 'format',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateInterval',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '668f85c7a036c1be06aca7fb4d7e6ce8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateInterval',
         'functionName' => 'createFromDateString',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateInterval',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'abcaa0d13d9609243f43d03ad2ce227e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateInterval',
         'functionName' => '__wakeup',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateInterval',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3e5cd088b6a4e5500f645b0b69afc1bc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateInterval',
         'functionName' => '__set_state',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateInterval',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ad6eb4571bdd7f0aefb0ad2b184d037f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateInterval',
         'functionName' => '__serialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateInterval',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '19fc73212dd3049894713a4eeb4385ef' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateInterval',
         'functionName' => '__unserialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DateInterval',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4bfd70526320b05cac7a3c8a2d770459' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DatePeriod',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
          'TDate' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TDate',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'DateTimeInterface',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TEnd' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TEnd',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\NullableTypeNode::__set_state(array(
                 'type' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'DateTimeInterface',
                   'attributes' => 
                  array (
                    'startLine' => 5,
                    'endLine' => 5,
                  ),
                )),
                 'attributes' => 
                array (
                  'startLine' => 5,
                  'endLine' => 5,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '127790871e79422b74f54336ab675c51' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DatePeriod',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DatePeriod',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TDate' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDate',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'DateTimeInterface',
                   'attributes' => 
                  array (
                    'startLine' => 4,
                    'endLine' => 4,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
            'TEnd' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TEnd',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\NullableTypeNode::__set_state(array(
                   'type' => 
                  \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                     'name' => 'DateTimeInterface',
                     'attributes' => 
                    array (
                      'startLine' => 5,
                      'endLine' => 5,
                    ),
                  )),
                   'attributes' => 
                  array (
                    'startLine' => 5,
                    'endLine' => 5,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 5,
                  'endLine' => 5,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '64909a5ebdc98f9a25db0ee891154448' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DatePeriod',
         'functionName' => 'getDateInterval',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DatePeriod',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TDate' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDate',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'DateTimeInterface',
                   'attributes' => 
                  array (
                    'startLine' => 4,
                    'endLine' => 4,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
            'TEnd' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TEnd',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\NullableTypeNode::__set_state(array(
                   'type' => 
                  \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                     'name' => 'DateTimeInterface',
                     'attributes' => 
                    array (
                      'startLine' => 5,
                      'endLine' => 5,
                    ),
                  )),
                   'attributes' => 
                  array (
                    'startLine' => 5,
                    'endLine' => 5,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 5,
                  'endLine' => 5,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b6fc0eb2682990de0dd048c08570177d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DatePeriod',
         'functionName' => 'getEndDate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DatePeriod',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TDate' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDate',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'DateTimeInterface',
                   'attributes' => 
                  array (
                    'startLine' => 4,
                    'endLine' => 4,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
            'TEnd' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TEnd',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\NullableTypeNode::__set_state(array(
                   'type' => 
                  \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                     'name' => 'DateTimeInterface',
                     'attributes' => 
                    array (
                      'startLine' => 5,
                      'endLine' => 5,
                    ),
                  )),
                   'attributes' => 
                  array (
                    'startLine' => 5,
                    'endLine' => 5,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 5,
                  'endLine' => 5,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6e94e8b8984629347e877e08940f6f8a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DatePeriod',
         'functionName' => 'getStartDate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DatePeriod',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TDate' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDate',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'DateTimeInterface',
                   'attributes' => 
                  array (
                    'startLine' => 4,
                    'endLine' => 4,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
            'TEnd' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TEnd',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\NullableTypeNode::__set_state(array(
                   'type' => 
                  \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                     'name' => 'DateTimeInterface',
                     'attributes' => 
                    array (
                      'startLine' => 5,
                      'endLine' => 5,
                    ),
                  )),
                   'attributes' => 
                  array (
                    'startLine' => 5,
                    'endLine' => 5,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 5,
                  'endLine' => 5,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '477a381e26f6e2015c5a6ec23285db3e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DatePeriod',
         'functionName' => '__set_state',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DatePeriod',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TDate' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDate',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'DateTimeInterface',
                   'attributes' => 
                  array (
                    'startLine' => 4,
                    'endLine' => 4,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
            'TEnd' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TEnd',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\NullableTypeNode::__set_state(array(
                   'type' => 
                  \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                     'name' => 'DateTimeInterface',
                     'attributes' => 
                    array (
                      'startLine' => 5,
                      'endLine' => 5,
                    ),
                  )),
                   'attributes' => 
                  array (
                    'startLine' => 5,
                    'endLine' => 5,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 5,
                  'endLine' => 5,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a426afa9fd3f40c79504efe3fa5531df' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DatePeriod',
         'functionName' => '__wakeup',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DatePeriod',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TDate' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDate',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'DateTimeInterface',
                   'attributes' => 
                  array (
                    'startLine' => 4,
                    'endLine' => 4,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
            'TEnd' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TEnd',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\NullableTypeNode::__set_state(array(
                   'type' => 
                  \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                     'name' => 'DateTimeInterface',
                     'attributes' => 
                    array (
                      'startLine' => 5,
                      'endLine' => 5,
                    ),
                  )),
                   'attributes' => 
                  array (
                    'startLine' => 5,
                    'endLine' => 5,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 5,
                  'endLine' => 5,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5818ad67a1420274e5b66ef8b9720650' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DatePeriod',
         'functionName' => 'getRecurrences',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DatePeriod',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TDate' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDate',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'DateTimeInterface',
                   'attributes' => 
                  array (
                    'startLine' => 4,
                    'endLine' => 4,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
            'TEnd' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TEnd',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\NullableTypeNode::__set_state(array(
                   'type' => 
                  \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                     'name' => 'DateTimeInterface',
                     'attributes' => 
                    array (
                      'startLine' => 5,
                      'endLine' => 5,
                    ),
                  )),
                   'attributes' => 
                  array (
                    'startLine' => 5,
                    'endLine' => 5,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 5,
                  'endLine' => 5,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a7d29622d4b0c02c177f1c838a84ff12' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DatePeriod',
         'functionName' => 'getIterator',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DatePeriod',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TDate' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDate',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'DateTimeInterface',
                   'attributes' => 
                  array (
                    'startLine' => 4,
                    'endLine' => 4,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
            'TEnd' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TEnd',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\NullableTypeNode::__set_state(array(
                   'type' => 
                  \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                     'name' => 'DateTimeInterface',
                     'attributes' => 
                    array (
                      'startLine' => 5,
                      'endLine' => 5,
                    ),
                  )),
                   'attributes' => 
                  array (
                    'startLine' => 5,
                    'endLine' => 5,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 5,
                  'endLine' => 5,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3f436c71f1546ed494323f1f58ce0428' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DatePeriod',
         'functionName' => '__serialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DatePeriod',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TDate' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDate',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'DateTimeInterface',
                   'attributes' => 
                  array (
                    'startLine' => 4,
                    'endLine' => 4,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
            'TEnd' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TEnd',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\NullableTypeNode::__set_state(array(
                   'type' => 
                  \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                     'name' => 'DateTimeInterface',
                     'attributes' => 
                    array (
                      'startLine' => 5,
                      'endLine' => 5,
                    ),
                  )),
                   'attributes' => 
                  array (
                    'startLine' => 5,
                    'endLine' => 5,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 5,
                  'endLine' => 5,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '576b15472d0576cc0b41369e5680459d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DatePeriod',
         'functionName' => '__unserialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DatePeriod',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TDate' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDate',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'DateTimeInterface',
                   'attributes' => 
                  array (
                    'startLine' => 4,
                    'endLine' => 4,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
            'TEnd' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TEnd',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\NullableTypeNode::__set_state(array(
                   'type' => 
                  \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                     'name' => 'DateTimeInterface',
                     'attributes' => 
                    array (
                      'startLine' => 5,
                      'endLine' => 5,
                    ),
                  )),
                   'attributes' => 
                  array (
                    'startLine' => 5,
                    'endLine' => 5,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 5,
                  'endLine' => 5,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0c39cdd2caed8867123db637abdba2f8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DatePeriod',
         'functionName' => 'createFromISO8601String',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'DatePeriod',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TDate' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TDate',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'DateTimeInterface',
                   'attributes' => 
                  array (
                    'startLine' => 4,
                    'endLine' => 4,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
            'TEnd' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TEnd',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\NullableTypeNode::__set_state(array(
                   'type' => 
                  \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                     'name' => 'DateTimeInterface',
                     'attributes' => 
                    array (
                      'startLine' => 5,
                      'endLine' => 5,
                    ),
                  )),
                   'attributes' => 
                  array (
                    'startLine' => 5,
                    'endLine' => 5,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 5,
                  'endLine' => 5,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8e358bd1aaaacd19edd0cc20977833fa' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateError',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '44efd9c95167f87e2702468b81048577' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateObjectError',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'af7ee3717fd66609b75bc7f8ac7a6b47' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateRangeError',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cd94f1276b753b99f707fb94e0edb903' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateException',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a43f8d93cb622b68959c910e470e3320' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateInvalidTimeZoneException',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9fe9124efab982f80de010eb05a71561' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateInvalidOperationException',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ec1a4dbbf44ff2de9a39c6e62ea2ded5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateMalformedStringException',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '745a37ed9a4ed50545fd6b9c04ead602' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateMalformedIntervalStringException',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7f4192b9253c8165660c677c66aa1559' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'DateMalformedPeriodStringException',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'phar:///mnt/workspace/Personal-Projects/sentinel/vendor/phpstan/phpstan/phpstan.phar/vendor/jetbrains/phpstorm-stubs/date/date_c.stub' => 'bb2b814c843193c731f3a43ebcec04e4056dab75a70c89cdb0c84431f5d157ee',
    ),
  ),
));