<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/symfony/http-foundation/Request.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      '7c6b80e84ed6fb6bb9d86233e118dd40' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => NULL,
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8718d1e4e600a7ac9e6c8cd0ab8afd71' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7a3166fb4673f554d155828143ad3643' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3456a1170d9e3bc98b599fd0ef3b592f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'initialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5b8d5fb3cb71e1a2a06193815204df5a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'createFromGlobals',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ec8bb6abad201192113c01d1e2ccfc8a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'create',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5c5d39003577886e3d6e1ffea3945bf7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'setFactory',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bd016356e8166294c7df1d318fcadf01' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'duplicate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '561e7412980bb8b229596af5574eb8a7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => '__clone',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a24d5ee0195bd2bd83a2eda43307d09e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => '__toString',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6124f2f3cffc623399c651c02ae4d399' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'overrideGlobals',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9c7d7c8422c692660ae63bcbb80af4c6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'setTrustedProxies',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7f084a99c60fcde287894fa3e0a3ff6b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getTrustedProxies',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f1babe16782489884ccb281733cc0970' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getTrustedHeaderSet',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f016533187873fe294046cba7624edd9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'setTrustedHosts',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '53f8433ba70eb04f678f434d59d99c61' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getTrustedHosts',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9590ee4ffdb9fe04ac08971e0dd67305' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'normalizeQueryString',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0291364e98a75e17e0ab3ed22f5fb60f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'enableHttpMethodParameterOverride',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ded857f9886f84d992b407689ddec147' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getHttpMethodParameterOverride',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5307be7237c184207d830a6790aa3363' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'setAllowedHttpMethodOverride',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c01a8e10c42770c314b7e54028e4b04f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getAllowedHttpMethodOverride',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '626cb362480db8634a63d7e0f3aa4782' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'get',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '96d77031e0eb9fca66ed5fa3000dacd9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getSession',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4babb7a492290dd72a01c5c678efd57a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'hasPreviousSession',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '835f02eae1ec18e3ec73d1b6137b6565' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'hasSession',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e3a871df60e209e3e35e73002e682e8b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'setSession',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '806eb47addea6712d8f8e205c235a70e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'setSessionFactory',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'be23ad1eec4beefd9a6805ad30001e3a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getClientIps',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'db7af562d44851ea48140c8c67de6cec' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getClientIp',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5d6a85f3c4f8f263a08611df2f2cd837' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getScriptName',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c6bce85cf1e7949e3f69c9031c4c9d8b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getPathInfo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6c311a7eda400fbd7e9bc17540963344' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getBasePath',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd972edeebd884cf8866051e95a42f474' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getBaseUrl',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd74555d87bb052a4ce355d299b13352d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getBaseUrlReal',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '376bf1e3c666d6e0f37e0809c567ede1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getScheme',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '59def04bfa40bc551a97d6896113789d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getPort',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5f8080292fd00fb01dd43cbaf2e9e6de' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getUser',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '31fccdf02d0cdfdd8c094182a9659b0b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getPassword',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '30208673826c45d224f120ab8fc9b20b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getUserInfo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd5d9aaa587dbcb8c68ed6ac0f7e72972' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getHttpHost',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8bf9378a87307bb717f3cefeb529b541' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getRequestUri',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd1e34403478f845574e81d3a84158794' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getSchemeAndHttpHost',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b2f4f0c21cd2fc2854ecab4fe04a5b7c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getUri',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7fe299b0bfaec4a208716400b5b19178' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getUriForPath',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '464cafe1a4df96be95bdc4fc55d843b7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getRelativeUriForPath',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9c8c7b396cdf68d65c7ea078a6a9fbf8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getQueryString',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ef1da991b96411d9a17ba32239dac0f8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'isSecure',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bcc2a37d3f91fe0509706576a31cbbef' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getHost',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '16b7af2694e9a4b677e1128cdcaf1f4e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'setMethod',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '25961c23bde4497b3f2150109aff29c0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getMethod',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ff1e5c089df2112f35218931b2b41efc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getRealMethod',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bc513b5cf268c8aabd28d56283b95cef' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getMimeType',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '963c666b16561c145d31e9b6784acdd5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getMimeTypes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '59174d4fa0833dd14f1e569dcef28556' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getFormat',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0b47e59e731773d4ec542d20128bcf3d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'setFormat',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a0458d29cb16ec5e3d86346242528571' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getRequestFormat',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '137645230280f8edb8a0234fcd5c001b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'setRequestFormat',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '561e1058db7d856f54698ef4819339cf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getContentTypeFormat',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4225f938748a383995e22cf9eeec19aa' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'setDefaultLocale',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '394dd48a63de00d6d81e16b59ed172c2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getDefaultLocale',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ae57f632df98173b6b49a0da8dc800f6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'setLocale',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '577a602db7c348248f4315af6557f3c9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getLocale',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '88071e067a1c5ca1f3d6156070e77701' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'isMethod',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3154db05acac42ddf392516f8c90e053' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'isMethodSafe',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8dc56647beb08511797cbee5b0f96d10' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'isMethodIdempotent',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd1d4ab4cb8cfe96060a121f7c4ee21ce' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'isMethodCacheable',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1de24558bd0cbbe986ece1981fb36ca5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getProtocolVersion',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6c3d67daafc30badd229d1320a9bd7d4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getContent',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '25dc134e6c79767e562a254fa98772bd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getPayload',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'eb50c84d663d31f296946244d572ff9d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'toArray',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9636144b00559a32acabf2b4e99d9676' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getETags',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b48715eac3a6f0927d36f1e7933b1677' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'isNoCache',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c17fb78147247d248c6b95218c5b283d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getPreferredFormat',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9c2a1e201ca463dd48e3abbfbcd703bd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getPreferredLanguage',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c7197d58277061a045e7a96a5b054616' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getLanguages',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '034611b4ad33d18dec5e01dd96d60062' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'formatLocale',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '02eb0d0e765d59459b729ab3a5ecbfcb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getLanguageCombinations',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '72ff3bc3e9f1a60fdce1911d44a78125' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getLanguageComponents',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f3f6ebc6e923247d329ffd5a61c01fd3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getCharsets',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9e689fa735f5bffc36c13b3930e9122c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getEncodings',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '163d55e1edf4639cc71634bb411d5066' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getAcceptableContentTypes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'efd666d2703ad5276bbadb35aa95d6d2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'isXmlHttpRequest',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8bf5304d6ed3a3bc73b57462c50cefcb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'preferSafeContent',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '240542b7cf41f48a1ceb42b701d0e13d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'prepareRequestUri',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3d0314f409321c7ac0266895d58af084' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'prepareBaseUrl',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2ef6ac68e78819d9b5c8421e0294ce79' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'prepareBasePath',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '97387656fc9b4feb900ef58a6e54c76e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'preparePathInfo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '72c909ba2dc9f5ff591fa17512b9bde1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'initializeFormats',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2d4c45eb1ae2b9fd3068aa1d5d29319e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'setPhpDefaultLocale',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3cecfbecb0e6f3f6024da4f4edda6285' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getUrlencodedPrefix',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9da9163af5d2027107b41b58f12a4ffb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'createRequestFromFactory',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '25d43a60537fd30506549c47678dc818' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'isFromTrustedProxy',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '98f104aeb0a5cdbcd9485181150b737d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'getTrustedValues',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1abd73255fe995dbe07216cbe8733639' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'normalizeAndFilterClientIps',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ef73956ac209c6f2f03f410a67d94fb2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'isIisRewrite',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ba0ed9640fc5f5aae14d93ecde985ce7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Symfony\\Component\\HttpFoundation',
         'uses' => 
        array (
          'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
          'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
          'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
          'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
          'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
          'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
        ),
         'className' => 'Symfony\\Component\\HttpFoundation\\Request',
         'functionName' => 'isHostValid',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Symfony\\Component\\HttpFoundation',
           'uses' => 
          array (
            'badrequestexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\BadRequestException',
            'conflictingheadersexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\ConflictingHeadersException',
            'jsonexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\JsonException',
            'sessionnotfoundexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SessionNotFoundException',
            'suspiciousoperationexception' => 'Symfony\\Component\\HttpFoundation\\Exception\\SuspiciousOperationException',
            'sessioninterface' => 'Symfony\\Component\\HttpFoundation\\Session\\SessionInterface',
          ),
           'className' => 'Symfony\\Component\\HttpFoundation\\Request',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/symfony/http-foundation/Request.php' => '3cdfb6da08d239a36737a80a0f62f823eb26e5864d51fd940d9106c3435f49a0',
    ),
  ),
));