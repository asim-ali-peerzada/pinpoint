<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Database/Eloquent/Builder.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-807b1ec61c5649b9e11d4418cc11162b59312d77564aeca65361fcaac97e333c-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\database\\eloquent\\builder' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));