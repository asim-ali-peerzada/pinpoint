<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      '89a206e9d97b7161c089d778b2e847c1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '180cbdd8758d76d3f3b543e078290cb2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'carbon' => 'Carbon\\Carbon',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '747da7b136f6094dda9d5dd2b42d454e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'carbon' => 'Carbon\\Carbon',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'wherePast',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '45ca5088420e681029fef914dd691f34' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'carbon' => 'Carbon\\Carbon',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereNowOrPast',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '9b6136aec0718f725714d21a25c1943f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'carbon' => 'Carbon\\Carbon',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWherePast',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      'e63778cf4a3e5cbabe027e33b7830ffa' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'carbon' => 'Carbon\\Carbon',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereNowOrPast',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '5a24092785bdc3e7f734600377157814' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'carbon' => 'Carbon\\Carbon',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereFuture',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '7876566866fbc2ba1a3dd4f3089e0d4f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'carbon' => 'Carbon\\Carbon',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereNowOrFuture',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '65f98d92030142c156e2801b9acdb940' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'carbon' => 'Carbon\\Carbon',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereFuture',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '7267d9df44df6d12f8b495ae6409ca09' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'carbon' => 'Carbon\\Carbon',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereNowOrFuture',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '6e4d4c1cd693991e4c434dd7fdfe4c9b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'carbon' => 'Carbon\\Carbon',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'wherePastOrFuture',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '44fba0dc4230f0301e60aa086e9a32da' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'carbon' => 'Carbon\\Carbon',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereToday',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '297f1b4c5deadc8c8784a96d88d6f263' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'carbon' => 'Carbon\\Carbon',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereBeforeToday',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '1109cd4df3c9e9c11641d727e06a960b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'carbon' => 'Carbon\\Carbon',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereTodayOrBefore',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '77f193359cadd722c2c209c1c230126a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'carbon' => 'Carbon\\Carbon',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereAfterToday',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '9bd534f271e4f3b34b2354408293c107' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'carbon' => 'Carbon\\Carbon',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereTodayOrAfter',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '8c54016802d310beb4fa7fc9ae1ef738' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'carbon' => 'Carbon\\Carbon',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereToday',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '2e135ebdb693e80a58d045504f3236d2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'carbon' => 'Carbon\\Carbon',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereBeforeToday',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '81ec1862c1a1be51ff0d93112055faac' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'carbon' => 'Carbon\\Carbon',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereTodayOrBefore',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '4353eceb6d356e4155ed648a3da4ff0a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'carbon' => 'Carbon\\Carbon',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereAfterToday',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '5a87de24c65525091e032ec88ec17c83' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'carbon' => 'Carbon\\Carbon',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereTodayOrAfter',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      'bc1466093fdd9515cd7885cd5e0ee507' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'carbon' => 'Carbon\\Carbon',
          'arr' => 'Illuminate\\Support\\Arr',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereTodayBeforeOrAfter',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      'b9453f8eeeb022f848affd885193966e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
          'TValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 2,
                'endLine' => 2,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '15c4c7282cdb06be9365b8029613d190' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'closure' => 'Closure',
          'higherorderwhenproxy' => 'Illuminate\\Support\\HigherOrderWhenProxy',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Conditionable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Support\\Traits\\Conditionable',
          3 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          4 => NULL,
        ),
      )),
      'a209f8c6b4dc387d5651458358afdcf2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'closure' => 'Closure',
          'higherorderwhenproxy' => 'Illuminate\\Support\\HigherOrderWhenProxy',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'when',
         'templatePhpDocNodes' => 
        array (
          'TWhenParameter' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TWhenParameter',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TWhenReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TWhenReturnType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Conditionable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Support\\Traits\\Conditionable',
          3 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          4 => NULL,
        ),
      )),
      '50abb2d0f514e42dca5256c9af872f72' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'closure' => 'Closure',
          'higherorderwhenproxy' => 'Illuminate\\Support\\HigherOrderWhenProxy',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'unless',
         'templatePhpDocNodes' => 
        array (
          'TUnlessParameter' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TUnlessParameter',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TUnlessReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TUnlessReturnType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Conditionable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Support\\Traits\\Conditionable',
          3 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          4 => NULL,
        ),
      )),
      'dab48407117e189f2fc747fa7bdb3515' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'chunk',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Query\\Builder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '6d39de1df5ccbd057e4565243be15bf2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'chunkMap',
         'templatePhpDocNodes' => 
        array (
          'TReturn' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TReturn',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Query\\Builder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      'e81a968982e95e78be79c08724cd9c4a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'each',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Query\\Builder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '675aff1c910cbb675b4aace401617b2a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'chunkById',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Query\\Builder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '59e9d011485cdb1cbdb42b14aa4f1222' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'chunkByIdDesc',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Query\\Builder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '6a821d092481ae601622c630d36eb7b7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orderedChunkById',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Query\\Builder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      'b0690761dd0c914f2de1f29adb6f59fe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'eachById',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Query\\Builder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      'a2932476a98e31ccb1ff3aa21bb09f2c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'lazy',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Query\\Builder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      'a50e7afe90df74db5f5e5956dfd932c2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'lazyById',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Query\\Builder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '8a5f633dc0534813ca5fb156d838b49d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'lazyByIdDesc',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Query\\Builder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '0f00c56f39e43d08291174e0ceefb3d6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orderedLazyById',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Query\\Builder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '2e6a1226c5c32b3410a6afa5909f4dc5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'first',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Query\\Builder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '8985c2b3263020903188920b1afcb971' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'firstOrFail',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Query\\Builder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      'd76f6ea022f971a0536bba55a8083d9b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'sole',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Query\\Builder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      'd0bf81e7b708601c47ec29230c156a03' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'paginateUsingCursor',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Query\\Builder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '74ddd1c7b1b40f0b4e86a5f1d1216444' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'getOriginalColumnNameForCursorPagination',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Query\\Builder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '69cfdd48f70eea62ffe5331e5ce7349d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'paginator',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Query\\Builder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '8f46e6c947abfd8d7e38f4be3f19b18a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'simplePaginator',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Query\\Builder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '161485014be953a3c0e2659fe17492b9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'cursorPaginator',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Query\\Builder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '6143b6e8b0f1c7529a0772a182208025' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'tap',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Query\\Builder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      'c3bf03d04296477e3fb7742be0c295fb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'container' => 'Illuminate\\Container\\Container',
          'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
          'expression' => 'Illuminate\\Database\\Query\\Expression',
          'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
          'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
          'cursor' => 'Illuminate\\Pagination\\Cursor',
          'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
          'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'pipe',
         'templatePhpDocNodes' => 
        array (
          'TReturn' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TReturn',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Database\\Concerns',
           'uses' => 
          array (
            'container' => 'Illuminate\\Container\\Container',
            'builder' => 'Illuminate\\Database\\Eloquent\\Builder',
            'multiplerecordsfoundexception' => 'Illuminate\\Database\\MultipleRecordsFoundException',
            'expression' => 'Illuminate\\Database\\Query\\Expression',
            'recordnotfoundexception' => 'Illuminate\\Database\\RecordNotFoundException',
            'recordsnotfoundexception' => 'Illuminate\\Database\\RecordsNotFoundException',
            'cursor' => 'Illuminate\\Pagination\\Cursor',
            'cursorpaginator' => 'Illuminate\\Pagination\\CursorPaginator',
            'lengthawarepaginator' => 'Illuminate\\Pagination\\LengthAwarePaginator',
            'paginator' => 'Illuminate\\Pagination\\Paginator',
            'collection' => 'Illuminate\\Support\\Collection',
            'lazycollection' => 'Illuminate\\Support\\LazyCollection',
            'str' => 'Illuminate\\Support\\Str',
            'conditionable' => 'Illuminate\\Support\\Traits\\Conditionable',
            'invalidargumentexception' => 'InvalidArgumentException',
            'runtimeexception' => 'RuntimeException',
          ),
           'className' => 'Illuminate\\Database\\Query\\Builder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TValue' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      'c393628755d5e0d1443966e953386081' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '622f931d59f9473658696cc28090c5d3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Concerns',
         'uses' => 
        array (
          'collection' => 'Illuminate\\Support\\Collection',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'explain',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '9dc86a57b90a9f45e80a1a63c2b9c826' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'error' => 'Error',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      'd38d8c95f3792182633ba4971478bcba' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'error' => 'Error',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'forwardCallTo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      'cbe7ca9f1ed82ba18f18dc2d78ab34bf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'error' => 'Error',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'forwardDecoratedCallTo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      'fb065474658e5f4228f693bdc9a9a6b1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'error' => 'Error',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'throwBadMethodCallException',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      'd9a027284ea96e3f3e8b6ac8d94c3cb0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '005b37a84b2ed14614b4ecc115b1109b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'macro',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      'e2d758866a41fc983fa8ad78f91d98ba' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'mixin',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      'ec8579b596a3db78826d000a0c506cf6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'hasMacro',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      'bd444d3546c6f59aefcc686a2d39ab33' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'flushMacros',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '95a22fe2c58bb9d1b18640a21a6d1377' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => '__callStatic',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      '0877ce2e737d9a1aa62e182f16d2f6e5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'macroCall',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php',
          1 => 'Illuminate\\Database\\Query\\Builder',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => '/** @use \\Illuminate\\Database\\Concerns\\BuildsQueries<\\stdClass> */',
        ),
      )),
      'e31ad951a102f58a695a79beac696534' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '465a7c0da8c8f3c2cb4a84dc049a3fe6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'select',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bd8b37d36caa7c11d1463868fdf3e2db' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'selectSub',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c26418aa39a081fa8c706a1200d0bda5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'selectExpression',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b8248810b4cbfa37e6d6d29802e7581f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'selectRaw',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6745d73fe805bb82e12507eeebbb3459' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'fromSub',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2c990a89b99fba4a1b103537e925babd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'fromRaw',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '988abde77b43af71b8d78f9e57323830' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'createSub',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd821b80643c89efd8cf9a5c341062291' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'parseSub',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8b40f465fbe7c07f0b5d69a0cbbb0931' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'prependDatabaseNameIfCrossDatabaseQuery',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '96a41d13d19f297f885727548df4de4e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'addSelect',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2e246e7707bb5eaabf2f3aec06a66fd4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'selectVectorDistance',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3222f95b660f816e006e288f557cff2d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'distinct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f2cce7f47006c7bb35aad89e01a4ef05' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'from',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4e3a52135419b71d96aa7385af792a42' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'useIndex',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3584b9b615993b50ce1366516f9305a2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'forceIndex',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd3c9a101362046e682846b048a23a98d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'ignoreIndex',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'eb3810bfb7951cf91e4e7c4592ca46af' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'join',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7eb3bf57ea5bd1f903d49a266ad3ede6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'joinWhere',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2411972cb78d5cd8cf778052261c3ef2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'joinSub',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a6d6d2c0106c5e32671651a3cfdc5a48' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'joinLateral',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '502685f21a5c7ad945a946ba05068fa8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'leftJoinLateral',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd9391a23d34d810ce9613ad7354ff8bc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'leftJoin',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3b97f972b2a76ddbd1a15d10cd6c3785' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'leftJoinWhere',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '82f3932a4973813b4d276988329694ff' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'leftJoinSub',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'daa55c77570877a3e4649063df357b37' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'rightJoin',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '63bc492ffcf63b9a87fdea7e7fd4673c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'rightJoinWhere',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a8467c920d447831a8c42e8e075559fe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'rightJoinSub',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fb8e5507764af85e13c9649d12211ba0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'crossJoin',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '35ecbc472ed4df1436e30ccf42437558' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'crossJoinSub',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd39cb42b366ccb8c7ad8ef972a7a0d89' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'newJoinClause',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '06aad8bd5767302e4b89a6f3218f19eb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'newJoinLateralClause',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e1d04c8781991c002ddd5abe1dca6a56' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'mergeWheres',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6d37c90f1682a0e33a6e6205fa3bb4e2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'where',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1685faa541ff944473e492646b6f8a1a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'addArrayOfWheres',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1b9ef661efae754e1bbb71fe4c543767' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'prepareValueAndOperator',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd43eb10ce53ec24dc89ce5bc00330a22' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'invalidOperatorAndValue',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0144fdf59827a6b6a00f3fea58258afc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'invalidOperator',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'aeee5071e6ed5a4862877abc7ee5038f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'isBitwiseOperator',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '287c8848335910f5dbdaea32158c1010' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhere',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f804eefa534f418114269e8082e3bcf5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereNot',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a41b068b0c717ee513f7042ed34e4cb8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereNot',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ddfd0a579e27e1007ef42f4cd2c1929c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereColumn',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '616745f1a448160ca76ae02bdc0ed87b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereColumn',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3f51dea055fe2f25590f18e906188ddc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereVectorSimilarTo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f23e0b77108efe05842ae647d814db10' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereVectorDistanceLessThan',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '228f1c22202071befe21b2eb13883c7e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereVectorDistanceLessThan',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b31671fb78886e5683017a03896f587c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereRaw',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '84072c283b211d08fbc13bb039b34193' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereRaw',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '13816ed3dd676f39f40e81b04e546faf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereLike',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a824349af921949ae8c9e5597d26f601' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereLike',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '830d3d762e457cc3622ac86fbb43746a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereNotLike',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '06d867654f6d3b54c28e04c2cc540554' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereNotLike',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5222845181889f265d0b1a01ea53061d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereNullSafeEquals',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'aa78480b6168fcff4ae59d8d20cf68ca' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereNullSafeEquals',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd253a41d4c4d26a07500deb98a0f6260' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereIn',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '39b9ea7ed543b7efdae16b4c635caa9a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereIn',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1d70193f78975915906781cce858865d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereNotIn',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a1f2bf917c8cd1465cdbfb717dca8c73' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereNotIn',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6c33994503a36531df055131dd382ab8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereIntegerInRaw',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a5a8613bfc899f672846d102767810b3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereIntegerInRaw',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'af6e6f9e9f4ca87debaa2299fbc4ed53' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereIntegerNotInRaw',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c3954271a7d352c9a0d78e539eea12b7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereIntegerNotInRaw',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '475f27b03b06ce59866c9bcfddb07fed' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereNull',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9bae1d0a940c62decbe2c14bfa1a6bc7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereNull',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '743ef1013b20e3a2ebd51b564da701b1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereNotNull',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '35398118b1cd850548aab5774bf76cc7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereBetween',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ad68f6a6a3efc416081d3fb69d5dde87' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereBetweenColumns',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '41210065ac21263b8f09fed9bef9c089' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereBetween',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2474734816f34ce6ef8d4ebdb927c646' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereBetweenColumns',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f409c91f935dec07368327f8aae204ba' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereNotBetween',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '54ccf73ac27e64408da0aae425422b70' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereNotBetweenColumns',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '40758c7a12596cf8f028ed54421ec917' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereNotBetween',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '59d1e2ac30a798d99ab74fa41feded65' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereNotBetweenColumns',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '02a429c453a5c7b7c03d8e60a7bdcddc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereValueBetween',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '251eb82bf07b5972d9abcabb85591b2c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereValueBetween',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'db6a0adb080a3f07afaf533088f051d2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereValueNotBetween',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3d85402b5d3c53ab31382e2ae792229b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereValueNotBetween',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd6b327a624ecaebceda42a0922602172' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereNotNull',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '75d22031a91a7c48d3446b0341cff6a9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereDate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ebd1364dd564f37c99a1563a852c958d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereDate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a5327e85c18f84d57a951c63c60f17cc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereTime',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '60bbffe7b80cfb6df564384f4836cc6a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereTime',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '061c142f3cb7a4356ee354f461b15365' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereDay',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '79ef0620bc0cfc1ea454f1daa9519e86' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereDay',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '280b527982b6e05b31317aeb2d85348d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereMonth',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8e033c0bb6317714ff3c7e459acecc15' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereMonth',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2f39a7f455f8620e84ab95d863703f8e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereYear',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ab380d67d1e789a74e9eb143c3a7d52d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereYear',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'aa55d8338b04e35243b2401539ce2c5d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'addDateBasedWhere',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a3679f0f30cab38f0d7e2d9ba507b676' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereNested',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '48dbb044273e7a405e84a9bee122e793' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'forNestedWhere',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2541186c6c5ad7682cc715d0eae46c66' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'addNestedWhereQuery',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9f0f8865c1f5a27785e8d79bf4831b67' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereSub',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fcc748a00f3e4fdfb7f0d8faae57ffe0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereExists',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dade357ed2c1ed42e94ee6fe6d1b285a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereExists',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd64210fbe9ab3aebf5949c1eb23ae3f1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereNotExists',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '992acf8e5fc4a973f59df2783a82dbe0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereNotExists',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '413a89f607ab9813fdbd6b79f886f90e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'addWhereExistsQuery',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6cd8b1141ece5c4625172eedfe192830' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereRowValues',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a79bc026c1a3875386ad9b1424deb8ce' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereRowValues',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cac092ab8c1cbf19fd4eba0975a9eeb9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereJsonContains',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6813ed9a69f86b70e10b5b662c4ba057' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereJsonContains',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '299e7ec7f68b6b6ef3e12df035c56937' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereJsonDoesntContain',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f4e867104f4fb750b0962b44a15d7452' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereJsonDoesntContain',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4a13493e3a49872a5789b681a784da6d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereJsonOverlaps',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '46d5990516e8f09d58d5955901f76750' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereJsonOverlaps',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6df9767c9323f29e4ba1a01e2c019739' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereJsonDoesntOverlap',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '59f602778c5735e9eea08aab1ed4fc88' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereJsonDoesntOverlap',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '484d3b6d4508dc946cc05cae5deb4d69' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereJsonContainsKey',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'aae213715f46564a1febf571e2e0874d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereJsonContainsKey',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '770b5391ed29bd20ed9e8fb022a97164' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereJsonDoesntContainKey',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cd045d21500aec5660f965c014ef1918' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereJsonDoesntContainKey',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e34d9ce32225f937495b5d2dfce0d737' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereJsonLength',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b8e8e4db02e5d589a5e67cfa38782a10' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereJsonLength',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a1b10606ad91f5b8b0f33708241e044c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'dynamicWhere',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '55e220c7a7612dec8246c5663341562e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'addDynamic',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f631a631d0a1d720e7abd6ae9a5b97d2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereFullText',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd30c0b14f4648d49f5be489d0b60da83' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereFullText',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f677007379c28188ddc9ea3f8aa50566' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereAll',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1e221692dcc967e31c0974de5939d8d3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereAll',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3eb0ea4cce1066abdef7872442e9842e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereAny',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f72bd482f2e6f9a58521a78b637b86c7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereAny',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4c286aa6cab5528c360eafcb99b48e76' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'whereNone',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '468a244e5a7106bdce44a65d1534bad6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orWhereNone',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'feb752d263050c31f20f65378d6f46a2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'groupBy',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0ecf66afcc7aa6702a15780af8ae1bdb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'groupByRaw',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e04325e29ad35bbafa23b9623833074f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'having',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a8d66872ae0a6a941775fa3935ae660a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orHaving',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7b0efc40d5fc8a8f7d1fa56908a5b02c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'havingNested',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7d5070374d20853f7f2c9c9163e84942' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'addNestedHavingQuery',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1ab5cfdd87cd26f6054211bafcbc4858' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'havingNull',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '08b85d90e03bfd034908658bbf26db76' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orHavingNull',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dafecf2b48594e5b607ddcc9081ec6f4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'havingNotNull',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b822dcece41ce0f186e3b3f74c0c6ef9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orHavingNotNull',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9c6e535d84b7e8351d4e8146ece2ea41' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'havingBetween',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3428233db82e72bdbdbe80d85b7e389b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'havingNotBetween',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3c0777b43ca181e9bd11350c4642c900' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orHavingBetween',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'eb2036b05cb760ef16fdf73cd8755406' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orHavingNotBetween',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c328d254d67c6cedd91dc027402a2e99' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'resolveDatePeriodBounds',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '27a6a17ec7644d9d919138d3a9163ca2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'havingRaw',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1f62c8dd1e198f3cf4fb818ac92892b0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orHavingRaw',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0eabdc0d8ef4908c8a757cc7203effbe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orderBy',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8a0cb3d9d7fd33d7a792b76b38bbdfad' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orderByDesc',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '87502bbc4e5d4379843962631bda5474' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'latest',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8353e039beadf0a4fb0c4b29c715f86f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'oldest',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '60079d70cc8c7b6c2f575dbe4a9cc7d8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orderByVectorDistance',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '95f55e9b0121e341686a93f6e1885cde' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'inRandomOrder',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '525aaf7338efbf79fba14f481c2ebeae' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'inOrderOf',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ed47f14b35d64d3ff9e0ef301db54932' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'orderByRaw',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '69af298466625935d2de7589d7da9fb4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'skip',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ba55d8dbab9708a1bfe643e521abdd6d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'offset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1f7de6217f3922948c7584baedd6dfcf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'take',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0aede5f5fae606f224ecba44cf968d9b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'limit',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e4fc634fd714e4d872d260a2be034c6e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'groupLimit',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7216e5e51dcbc93a5b85ae0875ae3026' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'forPage',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '26b4885a710a7243b36e2e9becbb641f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'forPageBeforeId',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '787203ffa4b23a3a2951f0191a4d6c66' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'forPageAfterId',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '41823ae2609ba214f86d029676fd3ea5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'reorder',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '288e36bdbb0c93dd2c9920c0b46669c1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'reorderDesc',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9d8d65821711795d99a6b2a2636f87c0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'removeExistingOrdersFor',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '007f5003ff27b1a829e75f5a77c9e6bb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'union',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '087025740ba67d4011729c6b1d47f6f5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'unionAll',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8c32c0b5398baf295e6fb4833a9a048c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'lock',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3b86ad84aa7a8f053646d75a070f55b8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'lockForUpdate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0b363db88c7ae7fa4f3265b689ef8c32' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'sharedLock',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '753c30c21ce4bddd0c9112b7e387fff0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'timeout',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '14b3088f189d625a49153ee4d7d27960' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'beforeQuery',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b26ba3223f22143507d95ec342bb4af0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'applyBeforeQueryCallbacks',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '688ca0a6654ba022b25ca0e05acab4ee' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'afterQuery',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0e084abf574cb9af8aece95064b3dfb8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'applyAfterQueryCallbacks',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f9131b19e7625a356d792a33be5afae0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'toSql',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c1c5662f5431856ad71d3687c0918d59' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'toRawSql',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bcb263628d972f13cfff1b996725ca8e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'find',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dfece5c62055a7e940016ef8ca64d4e3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'findOr',
         'templatePhpDocNodes' => 
        array (
          'TValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e2a6e8a9fe2a8f3b8636de774b50f96e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'value',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f4dbe4ba3633e0ab7be293549ed76d4d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'rawValue',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0718d5c7911ae92ac4211403b9df97d4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'soleValue',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ed54c4702ec6eecb38686d7fde9e51e5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'get',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e22023f7d539a3191e8fa0cedfbd3cc9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'runSelect',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '24e44c5e4b586aa77dba348a87108b63' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'withoutGroupLimitKeys',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9017380bf9bd8b522825c2cd0bee859d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'paginate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '89e43a676d096fd184507382507506c2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'simplePaginate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '81ee139559f037ea23d1bb44d0d6c2ae' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'cursorPaginate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '68da9a3e5b52b20b9c2c6497715cbafb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'ensureOrderForCursorPagination',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'abd36864c8857bad4cf0e68657fc66ba' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'getCountForPagination',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2f8ef91689903fad1c4838e7f53cf6da' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'runPaginationCountQuery',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e8be2eb5766426d8bf48bd2c09f4db85' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'cloneForPaginationCount',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f81a3cd767457bbce42d1bee1ccdb9ca' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'withoutSelectAliases',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8e109051a035d1244a34866d09278045' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'cursor',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e2937f25804d57ca68e60784e612ec3b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'enforceOrderBy',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '010c059d7641da8645a366ae66b2f53e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'pluck',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a6a1b2612982e2690e2ebd83f2f11267' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'stripTableForPluck',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6c4302abd6e04cf360f81809e7bc4f73' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'pluckFromObjectColumn',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6e66ec79b059920ebbca178ad8bf3802' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'pluckFromArrayColumn',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f402be93951a6f061f3ce47b673f01cb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'implode',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f5d3831627481971a22de6e65a40f63c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'exists',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0a82fbd477a8ada95fef7e2fd15ddbf3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'doesntExist',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1c7519b76a19f15a464fa9579285cb8e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'existsOr',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bb9b1fcac948623af974458174b583d4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'doesntExistOr',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'be0883680a6ac9516aabed04ca1a6c33' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'count',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd78adc8f10242e23dbe3a67230e8a744' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'min',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '863f8e7ce86c5695221c2342997a89ea' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'max',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6d0f645cebce79f7b29ed3c7924eac4d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'sum',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '914f6bdf83431e5f6df8a46395b01388' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'avg',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cee2bc1ec48debcd0e00403c5e432a47' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'average',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ba0622d161ccd11cc6177b9ff8124f0a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'aggregate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '93fe869f36dbe269c62512d18fd5ad39' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'numericAggregate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5ea7b4cc95a08159ee6642061debde53' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'setAggregate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '95bf1693d97f41788ff0cff829832a87' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'onceWithColumns',
         'templatePhpDocNodes' => 
        array (
          'TResult' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TResult',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 6,
                'endLine' => 6,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '996967c95e66bbbca6efd636696d18c2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'insert',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3fe4cec48ea57c23dc13b9b06255f9c6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'insertOrIgnore',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '27dedd5b5a9c70f6c6d05684f27aa1d4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'insertGetId',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ce87ed1279e456791eed2a620b26e752' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'insertUsing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ff68087e76e416a2241a4a5f39af8fd4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'insertOrIgnoreUsing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a4cddd58f95bb1eec70f428add4677c8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'update',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a54c4a9287af0de7271eb9c3f776dac3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'updateFrom',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0cb6c0d5a2579b0f6c11ad6334bdd398' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'updateOrInsert',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4c1d79968d73df25cdb89f31488e8ec4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'upsert',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '048b87dbcc1fb5d7911a30f32692d1f0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'increment',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f30c7bd221d1c0c9d73f7b097a2b0368' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'incrementEach',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'efa230d5dfbc44e9dbf229f77ab36e78' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'decrement',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '43ac7c91e8e00657bec58fb3fb75cc75' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'decrementEach',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6ad6893611c8fa93eef1103642c54ab9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'delete',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3fc096dfb24eb9835fdbedb7464d8bcc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'truncate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e7e4e858a7213248fa8fd0c0861425cb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'newQuery',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c84bd4b62e67f438bfc4d6ccbb697619' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'forSubQuery',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e22c675888caed50d415a2ebf58c1d98' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'getColumns',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '503bce9837ee64263d7060fd46016b0f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'raw',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd4580931d03000a56a9cebe6e8d8aec1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'getUnionBuilders',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '27bc9a10a47fc447ec1878007346d171' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'getLimit',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0c869cd15b98c2f5986085d3613059db' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'getOffset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8077f422524d818cb827f5a870873b46' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'getBindings',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e2f9dba404b8f5ff4ea1e47a0ebe8c9b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'getRawBindings',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8a8b006201cfb308e9666db19dd2fd0b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'setBindings',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd70aaace2776376fa4d9036060340660' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'addBinding',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3bb19ba561ed1f1a6925f4f1ebdfadab' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'castBinding',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '69b2b494ae9254b5aa154da01250030a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'mergeBindings',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3ee36c8b350035bf1504885c12b19842' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'cleanBindings',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e94d93bba15af877dafe3bca0cc95a2b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'flattenValue',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9442f1ea79f7eb9020f52c6d4112fdd5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'defaultKeyName',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7b4e58474a57f3dd350200e099c6b09e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'getConnection',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a0dd627d06f061cc72d12587a6a3d71d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'ensureConnectionSupportsVectors',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fc8117d4e61ab08e23603859cd6f7ae6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'getProcessor',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e06b982b163af8f8835a892fb5fe5f2b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'getGrammar',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b38892320fe395a2478681f627253ca6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'useWritePdo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1ff0bfc03b65c961e70bd3d17429a9b4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'isQueryable',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b528a4a04db9d3b8cd8a09e44485f2cb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'clone',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f8e1125c5482e7457c95a1bc911a35a4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'cloneWithout',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9f1295496c8cd9b065ff286afbc073b3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'cloneWithoutBindings',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8c802718d13ab120db3accc2cb56ded0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'dump',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a4aff30bdd536b19c88805da3b3c95e0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'dumpRawSql',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '124bb16b410841136f3cddb816a9e1d6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'dd',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1e5d85d1341110a9400c6fe21ab0e87b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => 'ddRawSql',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '08b0f8c17077966b51a878c69e6a819d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Database\\Query',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'closure' => 'Closure',
          'dateperiod' => 'DatePeriod',
          'datetimeinterface' => 'DateTimeInterface',
          'buildercontract' => 'Illuminate\\Contracts\\Database\\Query\\Builder',
          'conditionexpression' => 'Illuminate\\Contracts\\Database\\Query\\ConditionExpression',
          'expressioncontract' => 'Illuminate\\Contracts\\Database\\Query\\Expression',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'buildsqueries' => 'Illuminate\\Database\\Concerns\\BuildsQueries',
          'buildswheredateclauses' => 'Illuminate\\Database\\Concerns\\BuildsWhereDateClauses',
          'explainsqueries' => 'Illuminate\\Database\\Concerns\\ExplainsQueries',
          'connectioninterface' => 'Illuminate\\Database\\ConnectionInterface',
          'eloquentbuilder' => 'Illuminate\\Database\\Eloquent\\Builder',
          'relation' => 'Illuminate\\Database\\Eloquent\\Relations\\Relation',
          'postgresconnection' => 'Illuminate\\Database\\PostgresConnection',
          'grammar' => 'Illuminate\\Database\\Query\\Grammars\\Grammar',
          'processor' => 'Illuminate\\Database\\Query\\Processors\\Processor',
          'paginator' => 'Illuminate\\Pagination\\Paginator',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'lazycollection' => 'Illuminate\\Support\\LazyCollection',
          'str' => 'Illuminate\\Support\\Str',
          'forwardscalls' => 'Illuminate\\Support\\Traits\\ForwardsCalls',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'invalidargumentexception' => 'InvalidArgumentException',
          'logicexception' => 'LogicException',
          'runtimeexception' => 'RuntimeException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Database\\Query\\Builder',
         'functionName' => '__call',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Database/Query/Builder.php' => '812f717ba4aa895f020b319c4fce4116dca8cab74eda36830d2c2f02b58aaed6',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Database/Concerns/BuildsWhereDateClauses.php' => '63f2222578dc1dd4ba6e051e7136c277c0266eeba601cb7cd919ee9af964b984',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Database/Concerns/BuildsQueries.php' => '8ea5428ad1592fca250ef6724cbb4384185c5f95ef7bda850062a0d20e56bec1',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Conditionable/Traits/Conditionable.php' => '5697fdba0acb78ca0b4e122e5c459cd5d97d000ed9b14fed31271cb7ffd44225',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Database/Concerns/ExplainsQueries.php' => 'c1aca7045d73d0d54dd97c0c9fe2456e8ccc152e9b8fbd16412b93da97196bd3',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Support/Traits/ForwardsCalls.php' => 'b90103bc7248a11bd7629c525e064a45a50dd93ae0d836bcb79937e63f0b3568',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Macroable/Traits/Macroable.php' => '6dd85b1e28b55ebeee678f9ca423dfb8375e1342bc42d8658da6321bdf97b3c0',
    ),
  ),
));