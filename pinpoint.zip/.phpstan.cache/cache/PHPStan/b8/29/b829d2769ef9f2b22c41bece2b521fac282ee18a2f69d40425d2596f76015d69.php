<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/src/Facades/Pinpoint.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      'e8bc7d3e52e4bd13d23ca1a422d747b7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint\\Facades',
         'uses' => 
        array (
          'facade' => 'Illuminate\\Support\\Facades\\Facade',
        ),
         'className' => 'AsimAli\\Pinpoint\\Facades\\Pinpoint',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd2913ac6767c8e4a4a8cdac3f7cd0198' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint\\Facades',
         'uses' => 
        array (
          'facade' => 'Illuminate\\Support\\Facades\\Facade',
        ),
         'className' => 'AsimAli\\Pinpoint\\Facades\\Pinpoint',
         'functionName' => 'getFacadeAccessor',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'AsimAli\\Pinpoint\\Facades',
           'uses' => 
          array (
            'facade' => 'Illuminate\\Support\\Facades\\Facade',
          ),
           'className' => 'AsimAli\\Pinpoint\\Facades\\Pinpoint',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/src/Facades/Pinpoint.php' => '2be956d1288209dcf49c9d23c01afaf04748cb97721f52f8ebc28b8a088580fe',
    ),
  ),
));