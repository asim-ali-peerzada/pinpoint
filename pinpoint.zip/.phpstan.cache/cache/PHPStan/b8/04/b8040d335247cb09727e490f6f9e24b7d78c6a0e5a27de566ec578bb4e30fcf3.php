<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../nesbot/carbon/src/Carbon/Traits/Modifiers.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-3fa3b46a794e51ec6c6a84090c21a84103986d34c130a36cf56d96181bff839f-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'carbon\\traits\\modifiers' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));