<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/src/PinpointServiceProvider.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      '959ac5d2892b50a41dfb73ef4c2b2c9b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint',
         'uses' => 
        array (
          'aggregatecommand' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
          'prunecommand' => 'AsimAli\\Pinpoint\\Commands\\PruneCommand',
          'reportcommand' => 'AsimAli\\Pinpoint\\Commands\\ReportCommand',
          'recorder' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'queryexecuted' => 'Illuminate\\Database\\Events\\QueryExecuted',
          'requesthandled' => 'Illuminate\\Foundation\\Http\\Events\\RequestHandled',
          'log' => 'Illuminate\\Support\\Facades\\Log',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'package' => 'Spatie\\LaravelPackageTools\\Package',
          'packageserviceprovider' => 'Spatie\\LaravelPackageTools\\PackageServiceProvider',
        ),
         'className' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '314d306cd854eece7116d800b4fe469c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint',
         'uses' => 
        array (
          'aggregatecommand' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
          'prunecommand' => 'AsimAli\\Pinpoint\\Commands\\PruneCommand',
          'reportcommand' => 'AsimAli\\Pinpoint\\Commands\\ReportCommand',
          'recorder' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'queryexecuted' => 'Illuminate\\Database\\Events\\QueryExecuted',
          'requesthandled' => 'Illuminate\\Foundation\\Http\\Events\\RequestHandled',
          'log' => 'Illuminate\\Support\\Facades\\Log',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'package' => 'Spatie\\LaravelPackageTools\\Package',
          'packageserviceprovider' => 'Spatie\\LaravelPackageTools\\PackageServiceProvider',
        ),
         'className' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
         'functionName' => 'configurePackage',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '520824605f5f0bc7a795cc914ebcb502' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint',
         'uses' => 
        array (
          'aggregatecommand' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
          'prunecommand' => 'AsimAli\\Pinpoint\\Commands\\PruneCommand',
          'reportcommand' => 'AsimAli\\Pinpoint\\Commands\\ReportCommand',
          'recorder' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'queryexecuted' => 'Illuminate\\Database\\Events\\QueryExecuted',
          'requesthandled' => 'Illuminate\\Foundation\\Http\\Events\\RequestHandled',
          'log' => 'Illuminate\\Support\\Facades\\Log',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'package' => 'Spatie\\LaravelPackageTools\\Package',
          'packageserviceprovider' => 'Spatie\\LaravelPackageTools\\PackageServiceProvider',
        ),
         'className' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
         'functionName' => 'registeringPackage',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '638e58e0db60441be34ff9098bc8a015' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint',
         'uses' => 
        array (
          'aggregatecommand' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
          'prunecommand' => 'AsimAli\\Pinpoint\\Commands\\PruneCommand',
          'reportcommand' => 'AsimAli\\Pinpoint\\Commands\\ReportCommand',
          'recorder' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'queryexecuted' => 'Illuminate\\Database\\Events\\QueryExecuted',
          'requesthandled' => 'Illuminate\\Foundation\\Http\\Events\\RequestHandled',
          'log' => 'Illuminate\\Support\\Facades\\Log',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'package' => 'Spatie\\LaravelPackageTools\\Package',
          'packageserviceprovider' => 'Spatie\\LaravelPackageTools\\PackageServiceProvider',
        ),
         'className' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
         'functionName' => 'bootingPackage',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1b5a7f557d55d7ff010ff10f9bf01fcb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint',
         'uses' => 
        array (
          'aggregatecommand' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
          'prunecommand' => 'AsimAli\\Pinpoint\\Commands\\PruneCommand',
          'reportcommand' => 'AsimAli\\Pinpoint\\Commands\\ReportCommand',
          'recorder' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'queryexecuted' => 'Illuminate\\Database\\Events\\QueryExecuted',
          'requesthandled' => 'Illuminate\\Foundation\\Http\\Events\\RequestHandled',
          'log' => 'Illuminate\\Support\\Facades\\Log',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'package' => 'Spatie\\LaravelPackageTools\\Package',
          'packageserviceprovider' => 'Spatie\\LaravelPackageTools\\PackageServiceProvider',
        ),
         'className' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
         'functionName' => 'registerQueryListener',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd5bfba13460493fe68aeb81a77f02334' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint',
         'uses' => 
        array (
          'aggregatecommand' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
          'prunecommand' => 'AsimAli\\Pinpoint\\Commands\\PruneCommand',
          'reportcommand' => 'AsimAli\\Pinpoint\\Commands\\ReportCommand',
          'recorder' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'queryexecuted' => 'Illuminate\\Database\\Events\\QueryExecuted',
          'requesthandled' => 'Illuminate\\Foundation\\Http\\Events\\RequestHandled',
          'log' => 'Illuminate\\Support\\Facades\\Log',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'package' => 'Spatie\\LaravelPackageTools\\Package',
          'packageserviceprovider' => 'Spatie\\LaravelPackageTools\\PackageServiceProvider',
        ),
         'className' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
         'functionName' => 'registerRequestListener',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5d702e995b3443bb80a014080dd9ba4f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint',
         'uses' => 
        array (
          'aggregatecommand' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
          'prunecommand' => 'AsimAli\\Pinpoint\\Commands\\PruneCommand',
          'reportcommand' => 'AsimAli\\Pinpoint\\Commands\\ReportCommand',
          'recorder' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'queryexecuted' => 'Illuminate\\Database\\Events\\QueryExecuted',
          'requesthandled' => 'Illuminate\\Foundation\\Http\\Events\\RequestHandled',
          'log' => 'Illuminate\\Support\\Facades\\Log',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'package' => 'Spatie\\LaravelPackageTools\\Package',
          'packageserviceprovider' => 'Spatie\\LaravelPackageTools\\PackageServiceProvider',
        ),
         'className' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
         'functionName' => 'registerLazyLoadingObserver',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e65a0cc0d22fb9f99b4317a241aff632' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint',
         'uses' => 
        array (
          'aggregatecommand' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
          'prunecommand' => 'AsimAli\\Pinpoint\\Commands\\PruneCommand',
          'reportcommand' => 'AsimAli\\Pinpoint\\Commands\\ReportCommand',
          'recorder' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'queryexecuted' => 'Illuminate\\Database\\Events\\QueryExecuted',
          'requesthandled' => 'Illuminate\\Foundation\\Http\\Events\\RequestHandled',
          'log' => 'Illuminate\\Support\\Facades\\Log',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'package' => 'Spatie\\LaravelPackageTools\\Package',
          'packageserviceprovider' => 'Spatie\\LaravelPackageTools\\PackageServiceProvider',
        ),
         'className' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
         'functionName' => 'requestStart',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '52a42a8221b4781b1127ab08cfad1003' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint',
         'uses' => 
        array (
          'aggregatecommand' => 'AsimAli\\Pinpoint\\Commands\\AggregateCommand',
          'prunecommand' => 'AsimAli\\Pinpoint\\Commands\\PruneCommand',
          'reportcommand' => 'AsimAli\\Pinpoint\\Commands\\ReportCommand',
          'recorder' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'queryexecuted' => 'Illuminate\\Database\\Events\\QueryExecuted',
          'requesthandled' => 'Illuminate\\Foundation\\Http\\Events\\RequestHandled',
          'log' => 'Illuminate\\Support\\Facades\\Log',
          'reflectionclass' => 'ReflectionClass',
          'reflectionexception' => 'ReflectionException',
          'package' => 'Spatie\\LaravelPackageTools\\Package',
          'packageserviceprovider' => 'Spatie\\LaravelPackageTools\\PackageServiceProvider',
        ),
         'className' => 'AsimAli\\Pinpoint\\PinpointServiceProvider',
         'functionName' => 'currentLazyLoadingCallback',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/src/PinpointServiceProvider.php' => '0e277ce56691eaa66274e55aeed8f8e46471f29ea6fe791ebc10a9a89f3dd492',
    ),
  ),
));