<?php declare(strict_types = 1);

// ftm-phar:///mnt/workspace/Personal-Projects/sentinel/vendor/phpstan/phpstan/phpstan.phar/vendor/jetbrains/phpstorm-stubs/random/random.stub
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      'fbe13543a180253fb554822016b45252' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'lcg_value',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a8d0cfe0388d740af6742f843ffa723a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'mt_srand',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '494c5fd9ce89ccff278c19b553a90ee8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'srand',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f569527cdd19a4e19a6fbd050652f2db' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'rand',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4c960155ad09daa49b67eb3de708dc1f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'mt_rand',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2863e737c8459702ca4861451e197f03' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'mt_getrandmax',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'acf67043c315928829bf0d34530487cd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'getrandmax',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a6da69df380ba99e59c3d957e9ad0dcb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'random_bytes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '152a4699c23f23419297b2533db2307c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'random_int',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd770fc75af2ff17495971c202ceca28d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Mt19937',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'aabb77e8fe842f10ab44598ddaffae97' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Mt19937',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Mt19937',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b92819fafc34156ceb6d4445ca56bfb4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Mt19937',
         'functionName' => 'generate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Mt19937',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '55ecc1ce6810aac1a4daf550e03549cc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Mt19937',
         'functionName' => '__serialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Mt19937',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cc44c1e715c2a47d14e8d14c08802e1c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Mt19937',
         'functionName' => '__unserialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Mt19937',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '95fd75137d65870f6de5734834545214' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Mt19937',
         'functionName' => '__debugInfo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Mt19937',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '871fe3809d254be2cc954394f72eff8a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bad0e5bb1408e45c8bbcc75707ec6238' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '83af31e82621448c3be05b78d953f4dc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
         'functionName' => 'generate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cd13f1428332e0869a3b0827ed75defb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
         'functionName' => 'jump',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f1dd1fd5e2b7096265d1029275d12412' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
         'functionName' => '__serialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '470820b633f649d844f1b0d74b5d1a55' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
         'functionName' => '__unserialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e95e54f324a9d590cabb44ddd436f050' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
         'functionName' => '__debugInfo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ed03e2429a3c6f30b6b27e9d4d5b9e21' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Xoshiro256StarStar',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ae85e950da72e30fa4e4175acec298ad' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Xoshiro256StarStar',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Xoshiro256StarStar',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '08f0a0db2c38d8666bd00739c501fc05' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Xoshiro256StarStar',
         'functionName' => 'generate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Xoshiro256StarStar',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '97ee8dbfc6e2619c2b0cd5e84ec785e3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Xoshiro256StarStar',
         'functionName' => 'jump',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Xoshiro256StarStar',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9cfaed8cde7c378b3e7581f41a002e41' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Xoshiro256StarStar',
         'functionName' => 'jumpLong',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Xoshiro256StarStar',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '58193eba592492e38ac59bb7e6305a94' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Xoshiro256StarStar',
         'functionName' => '__serialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Xoshiro256StarStar',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ec979682b257073aa18b8ae0c285c444' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Xoshiro256StarStar',
         'functionName' => '__unserialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Xoshiro256StarStar',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd4cc231ec562e1228706c9198992429d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Xoshiro256StarStar',
         'functionName' => '__debugInfo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Xoshiro256StarStar',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '661162b82e3777ecbb5bcce7c7427379' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Secure',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '16f4dcd8dfc7dffe0db029c90980f185' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Secure',
         'functionName' => 'generate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Secure',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bfe5fc566120f6bee43762f100bfedc7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Engine',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a4b2add87118788ea55f70c0a88570dc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Engine',
         'functionName' => 'generate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Engine',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0c520c5e7a22cd747231ed9e34fce58f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\CryptoSafeEngine',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f01ae70ef790d808e3271a37d4bd1b1f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '915a5bdb2a96e0c370bb85ac9e2eb0c5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2ec097568276ae7794245508c279ce24' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => 'nextInt',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2402e4933e2ad86f0532c056dbe0eaf2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => 'getInt',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0f68444b1d3d8a8c42f7319de08199dd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => 'getBytes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'eeef855917145803cc9b12d4f10d9974' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => 'shuffleArray',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6b3a67d612f24357e26accc9eb31ce23' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => 'shuffleBytes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e21aa5d562bd9d95445760b74144259b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => 'pickArrayKeys',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b89d63074c0ecc342ab5c90291178999' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => '__serialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '82c71eb5a120ad98aad6395fc4b45110' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => '__unserialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '74cc9a3bb6471ec79f2fd09649f277fb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => 'nextFloat',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '53f40a871b8f225d6c955d34cf8cee9f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => 'getFloat',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '682fb4b7c60280f44fde5ee857e73066' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => 'getBytesFromString',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ef0a5f84ebd761a5f0a29c5114086b42' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\RandomError',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8ac3de69637c5768788b65b1a2d3b369' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\BrokenRandomEngineError',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e95d44197b872254310bd36971bd9dd8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\RandomException',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '41cdcdd9d7a791eeb28829a0722b7670' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\IntervalBoundary',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2eaede8628488592d0fcf06c95cdd2fa' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\IntervalBoundary',
         'functionName' => 'cases',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\IntervalBoundary',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'phar:///mnt/workspace/Personal-Projects/sentinel/vendor/phpstan/phpstan/phpstan.phar/vendor/jetbrains/phpstorm-stubs/random/random.stub' => '1267cf5900cb646cb69e4421289b8c2ec8921073610dd3499800524d7becb853',
    ),
  ),
));