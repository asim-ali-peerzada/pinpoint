<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      '8f39fbfc16b1cbadfd1e3856bf18bbdd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f4d096253885e6e0f225c0ab05a67528' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '0afe5ee342eb36a0e27f6c64b9643594' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'presetmanager' => 'Orchestra\\Canvas\\Core\\PresetManager',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
          3 => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          4 => NULL,
        ),
      )),
      '4f3ca96f56ab03904382740a2a15e0fd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'presetmanager' => 'Orchestra\\Canvas\\Core\\PresetManager',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'addGeneratorPresetOptions',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
          3 => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          4 => NULL,
        ),
      )),
      '366d14842b22210d796abc830f3374ef' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'presetmanager' => 'Orchestra\\Canvas\\Core\\PresetManager',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'generatorPreset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
          3 => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          4 => NULL,
        ),
      )),
      '00b68de34e409db3b28562aa1ad5598a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'presetmanager' => 'Orchestra\\Canvas\\Core\\PresetManager',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'getGeneratorSourcePath',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
          3 => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          4 => NULL,
        ),
      )),
      '61056498ccc8676b67066a9149765b1c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'generateCode',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '0a6bbcd7bdfdf95d98a6b1cdc76795d0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'generatingCode',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '5093e9c8679dec226590cccbaa6e4f7f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'codeAlreadyExists',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'c9f3fb0ae09497624db5eb81502f02eb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'codeHasBeenGenerated',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '6a7fb523245e6c1bedac226ac59a651c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'afterCodeHasBeenGenerated',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '9464a6a90a92c6f316121e689fa0761b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '236e2049e277fb32a1712668802aaa4d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'handleTestCreationUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '52cb9c463ba340da86b9aabca0d52d17' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '3c687263e26dc691ba86971a1c25daba' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'qualifyModelUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '10e50b8ea1ccf5ea739ffb71c27abe7b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'getPathUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '0ceb718fdc07a46e9f777151047353f3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'rootNamespaceUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '7a3bbbb951978cba1b614b68cb86138d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'userProviderModelUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'f42893961b365b38eefca98449f97c64' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'viewPathUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'fd7930823da0904ed7badf55523a5f96' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'findAvailableModelsUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '04a5bdfa3cf7f22311999b40705e9d9c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'possibleModelsUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '2f2643ce73ef1b6c7794ade85487289e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'possibleEventsUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '9cf86d3daafbec84c2fef2905f9112fe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'rootNamespace',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '92268085525f539a7ebb6ab3cff1ab7f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'generatorPreset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '3e57aaab4f76f1a87984bce4021aa747' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'configure',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Orchestra\\Canvas\\Console',
           'uses' => 
          array (
            'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
            'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
            'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
            'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
          ),
           'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ec519f8c720e41572c3b26a94c3d5a19' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'handle',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Orchestra\\Canvas\\Console',
           'uses' => 
          array (
            'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
            'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
            'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
            'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
          ),
           'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8a4f788782b53a9f99e254eb345181b3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'afterCodeHasBeenGenerated',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Orchestra\\Canvas\\Console',
           'uses' => 
          array (
            'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
            'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
            'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
            'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
          ),
           'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '318c0846612979c420334dcabab21b61' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'getPath',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Orchestra\\Canvas\\Console',
           'uses' => 
          array (
            'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
            'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
            'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
            'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
          ),
           'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9ce080ef1b3a2973001e04d267f63d5a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
         'functionName' => 'rootNamespace',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Orchestra\\Canvas\\Console',
           'uses' => 
          array (
            'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
            'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
            'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
            'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
          ),
           'className' => 'Orchestra\\Canvas\\Console\\MailMakeCommand',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MailMakeCommand.php' => '33e7f4143a63d6f900f5e1a3c4a83ec753165347f2219b1964e6b04c92d68365',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas-core/src/Concerns/CodeGenerator.php' => '53a99bd8408373e5b764137127dd6bb92f0f84481043bc6e888a5bca12525f95',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas-core/src/Concerns/CreatesUsingGeneratorPreset.php' => '04f1fc472c3c006decd42fd64ba2fd495b70184367d40a981caa601c12ad8775',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas-core/src/Concerns/TestGenerator.php' => 'ef413e8049b5871ddf09a295ff748ee33efd5a8673d085e8a292c571cb30451f',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas-core/src/Concerns/UsesGeneratorOverrides.php' => 'ccb973108e69ca46e54365c3cacda3127f5f816944d3d836b07a02ff21b1869d',
    ),
  ),
));