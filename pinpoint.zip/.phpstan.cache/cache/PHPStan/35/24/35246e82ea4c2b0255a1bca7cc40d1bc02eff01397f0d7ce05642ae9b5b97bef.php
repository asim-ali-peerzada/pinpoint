<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Serialization.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      'f08b02b94db2a0156a0fbe32e1d7748e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'datetimezone' => 'DateTimeZone',
          'returntypewillchange' => 'ReturnTypeWillChange',
          'throwable' => 'Throwable',
        ),
         'className' => 'Carbon\\Traits\\Serialization',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '66a6465ac38a509a846b6bda49583ace' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
        ),
         'className' => 'Carbon\\Traits\\Serialization',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Carbon\\Traits\\ObjectInitialisation',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Serialization.php',
          1 => 'Carbon\\Traits\\Serialization',
          2 => 'Carbon\\Traits\\ObjectInitialisation',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '1fae14b2c3a5b03940761ede9a1b0ef5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'datetimezone' => 'DateTimeZone',
          'returntypewillchange' => 'ReturnTypeWillChange',
          'throwable' => 'Throwable',
        ),
         'className' => 'Carbon\\Traits\\Serialization',
         'functionName' => 'serialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'datetimezone' => 'DateTimeZone',
            'returntypewillchange' => 'ReturnTypeWillChange',
            'throwable' => 'Throwable',
          ),
           'className' => 'Carbon\\Traits\\Serialization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8c0fec9b0f50ddc6c6cb3d3b1f7e76f9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'datetimezone' => 'DateTimeZone',
          'returntypewillchange' => 'ReturnTypeWillChange',
          'throwable' => 'Throwable',
        ),
         'className' => 'Carbon\\Traits\\Serialization',
         'functionName' => 'fromSerialized',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'datetimezone' => 'DateTimeZone',
            'returntypewillchange' => 'ReturnTypeWillChange',
            'throwable' => 'Throwable',
          ),
           'className' => 'Carbon\\Traits\\Serialization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a0275ead89a16ecd662d7bba92081f54' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'datetimezone' => 'DateTimeZone',
          'returntypewillchange' => 'ReturnTypeWillChange',
          'throwable' => 'Throwable',
        ),
         'className' => 'Carbon\\Traits\\Serialization',
         'functionName' => '__set_state',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'datetimezone' => 'DateTimeZone',
            'returntypewillchange' => 'ReturnTypeWillChange',
            'throwable' => 'Throwable',
          ),
           'className' => 'Carbon\\Traits\\Serialization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a45f75b017822ad0d4b3bbb8c167acec' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'datetimezone' => 'DateTimeZone',
          'returntypewillchange' => 'ReturnTypeWillChange',
          'throwable' => 'Throwable',
        ),
         'className' => 'Carbon\\Traits\\Serialization',
         'functionName' => '__serialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'datetimezone' => 'DateTimeZone',
            'returntypewillchange' => 'ReturnTypeWillChange',
            'throwable' => 'Throwable',
          ),
           'className' => 'Carbon\\Traits\\Serialization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '82178f319ce087a2f7b03c8ca47116ab' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'datetimezone' => 'DateTimeZone',
          'returntypewillchange' => 'ReturnTypeWillChange',
          'throwable' => 'Throwable',
        ),
         'className' => 'Carbon\\Traits\\Serialization',
         'functionName' => '__unserialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'datetimezone' => 'DateTimeZone',
            'returntypewillchange' => 'ReturnTypeWillChange',
            'throwable' => 'Throwable',
          ),
           'className' => 'Carbon\\Traits\\Serialization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6e5340a118bbd837f5b1f869c9099fca' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'datetimezone' => 'DateTimeZone',
          'returntypewillchange' => 'ReturnTypeWillChange',
          'throwable' => 'Throwable',
        ),
         'className' => 'Carbon\\Traits\\Serialization',
         'functionName' => 'jsonSerialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'datetimezone' => 'DateTimeZone',
            'returntypewillchange' => 'ReturnTypeWillChange',
            'throwable' => 'Throwable',
          ),
           'className' => 'Carbon\\Traits\\Serialization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0714d5f14e1acb9b9d25d60292f541ef' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'datetimezone' => 'DateTimeZone',
          'returntypewillchange' => 'ReturnTypeWillChange',
          'throwable' => 'Throwable',
        ),
         'className' => 'Carbon\\Traits\\Serialization',
         'functionName' => 'serializeUsing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'datetimezone' => 'DateTimeZone',
            'returntypewillchange' => 'ReturnTypeWillChange',
            'throwable' => 'Throwable',
          ),
           'className' => 'Carbon\\Traits\\Serialization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '467cae54b32f3fefc7f8c57482956714' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'datetimezone' => 'DateTimeZone',
          'returntypewillchange' => 'ReturnTypeWillChange',
          'throwable' => 'Throwable',
        ),
         'className' => 'Carbon\\Traits\\Serialization',
         'functionName' => 'cleanupDumpProperties',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'datetimezone' => 'DateTimeZone',
            'returntypewillchange' => 'ReturnTypeWillChange',
            'throwable' => 'Throwable',
          ),
           'className' => 'Carbon\\Traits\\Serialization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4045a7d11ab34aaec4580ab5d51e6c84' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'datetimezone' => 'DateTimeZone',
          'returntypewillchange' => 'ReturnTypeWillChange',
          'throwable' => 'Throwable',
        ),
         'className' => 'Carbon\\Traits\\Serialization',
         'functionName' => 'dumpTimezone',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'invalidformatexception' => 'Carbon\\Exceptions\\InvalidFormatException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'datetimezone' => 'DateTimeZone',
            'returntypewillchange' => 'ReturnTypeWillChange',
            'throwable' => 'Throwable',
          ),
           'className' => 'Carbon\\Traits\\Serialization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Serialization.php' => 'de0e1ea1bc306ad603494d670590f23fb8049bf8800e10b933f59c028dbb1104',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../nesbot/carbon/src/Carbon/Traits/ObjectInitialisation.php' => '0e15bb605dca915b0c5d4415f530a564b2ef6a1ffa46cc78209a6ee1c7c2b544',
    ),
  ),
));