<?php declare(strict_types = 1);

// odsl-/mnt/workspace/Personal-Projects/sentinel/src/Internal/Statistics.php-PHPStan\BetterReflection\Reflection\ReflectionClass-AsimAli\Pinpoint\Internal\Statistics
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.3-8.2.33-eea602e8068224f158597575d2e45cc853c5e30b35b85953cd43ed9c360cca4f',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'AsimAli\\Pinpoint\\Internal\\Statistics',
        'filename' => '/mnt/workspace/Personal-Projects/sentinel/src/Internal/Statistics.php',
      ),
    ),
    'namespace' => 'AsimAli\\Pinpoint\\Internal',
    'name' => 'AsimAli\\Pinpoint\\Internal\\Statistics',
    'shortName' => 'Statistics',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 0,
    'docComment' => '/**
 * @internal Not part of Pinpoint\'s public API contract.
 */',
    'attributes' => 
    array (
    ),
    'startLine' => 8,
    'endLine' => 27,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => NULL,
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      'percentile' => 
      array (
        'name' => 'percentile',
        'parameters' => 
        array (
          'durations' => 
          array (
            'name' => 'durations',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'array',
                'isIdentifier' => true,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 13,
            'endLine' => 13,
            'startColumn' => 39,
            'endColumn' => 54,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'p' => 
          array (
            'name' => 'p',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'int',
                'isIdentifier' => true,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 13,
            'endLine' => 13,
            'startColumn' => 57,
            'endColumn' => 62,
            'parameterIndex' => 1,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'int',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Nearest-rank percentile. Sorts in place; pass a copy if order matters.
 */',
        'startLine' => 13,
        'endLine' => 26,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 17,
        'namespace' => 'AsimAli\\Pinpoint\\Internal',
        'declaringClassName' => 'AsimAli\\Pinpoint\\Internal\\Statistics',
        'implementingClassName' => 'AsimAli\\Pinpoint\\Internal\\Statistics',
        'currentClassName' => 'AsimAli\\Pinpoint\\Internal\\Statistics',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));