<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Database/Console/Migrations/BaseCommand.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-d36e720a2a494567282aa33bc9db411e0153fcdac201ecd80b206fd9846bed3d-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\database\\console\\migrations\\basecommand' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));