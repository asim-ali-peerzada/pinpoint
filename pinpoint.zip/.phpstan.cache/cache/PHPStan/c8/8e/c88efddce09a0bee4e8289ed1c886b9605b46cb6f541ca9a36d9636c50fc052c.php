<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../symfony/http-kernel/HttpKernelInterface.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6653c14a3a32da7f1c21c0e8692e367d8a2e947b30b3f0006386673381e0038b-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'symfony\\component\\httpkernel\\httpkernelinterface' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));