<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas-core/src/Concerns/TestGenerator.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-ef413e8049b5871ddf09a295ff748ee33efd5a8673d085e8a292c571cb30451f-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'orchestra\\canvas\\core\\concerns\\testgenerator' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));