<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Database/Eloquent/Concerns/HasRelationships.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-733f895df31b006008f771925a1356d495c053ea73ba17f9a085729c679388a2-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\database\\eloquent\\concerns\\hasrelationships' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));