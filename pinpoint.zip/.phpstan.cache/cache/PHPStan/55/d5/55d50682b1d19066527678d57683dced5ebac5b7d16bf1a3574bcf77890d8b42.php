<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Support/Traits/InteractsWithData.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-5f3e6445359ba821ac7da0fb7cb05a7dcc3e6ed73e5d341237cccf7c570acd3a-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\support\\traits\\interactswithdata' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));