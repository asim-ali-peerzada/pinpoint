<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../symfony/console/Exception/ExceptionInterface.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-566051a18eafac33728f361dfbe3492515ad5f9230bdf00405845e1b164e3b3e-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'symfony\\component\\console\\exception\\exceptioninterface' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));