<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Queue/Console/FlushFailedCommand.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6fcfd7266d1e0f5f0114c1ca5fcf43b2a2d862566423c8f5b25eadabe61629b3-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\queue\\console\\flushfailedcommand' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));