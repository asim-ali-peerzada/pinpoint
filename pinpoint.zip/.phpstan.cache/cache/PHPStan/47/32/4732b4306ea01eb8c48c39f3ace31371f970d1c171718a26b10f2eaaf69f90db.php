<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Localization.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      'f5f2d0dc601cecce937ff03968a6f212' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2d1a8e388ad0d88725c428183d281f6c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Carbon\\Traits\\StaticLocalization',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Localization.php',
          1 => 'Carbon\\Traits\\Localization',
          2 => 'Carbon\\Traits\\StaticLocalization',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '1cf4670353a606eeb2b14778e59a6fa9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'setHumanDiffOptions',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Carbon\\Traits\\StaticLocalization',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Carbon\\Traits\\StaticLocalization',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Localization.php',
          1 => 'Carbon\\Traits\\Localization',
          2 => 'Carbon\\Traits\\StaticLocalization',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '3ff788e5aef5d07404472b3530248421' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'enableHumanDiffOption',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Carbon\\Traits\\StaticLocalization',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Carbon\\Traits\\StaticLocalization',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Localization.php',
          1 => 'Carbon\\Traits\\Localization',
          2 => 'Carbon\\Traits\\StaticLocalization',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '26fa286e383e848e0a2e7ad9c084b3a3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'disableHumanDiffOption',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Carbon\\Traits\\StaticLocalization',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Carbon\\Traits\\StaticLocalization',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Localization.php',
          1 => 'Carbon\\Traits\\Localization',
          2 => 'Carbon\\Traits\\StaticLocalization',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '3dce6a3d79cb88aa998b99ebc7b9a5e9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'getHumanDiffOptions',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Carbon\\Traits\\StaticLocalization',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Carbon\\Traits\\StaticLocalization',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Localization.php',
          1 => 'Carbon\\Traits\\Localization',
          2 => 'Carbon\\Traits\\StaticLocalization',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '300235e2d83518b084777a25883988c2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'setTranslator',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Carbon\\Traits\\StaticLocalization',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Carbon\\Traits\\StaticLocalization',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Localization.php',
          1 => 'Carbon\\Traits\\Localization',
          2 => 'Carbon\\Traits\\StaticLocalization',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '0a6156220c0225bad1898131865f1050' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'getTranslator',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Carbon\\Traits\\StaticLocalization',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Carbon\\Traits\\StaticLocalization',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Localization.php',
          1 => 'Carbon\\Traits\\Localization',
          2 => 'Carbon\\Traits\\StaticLocalization',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '751db1690b946428b6dfe5014a5f4237' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'hasLocalTranslator',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0bfc80be07277c2590234c58279977f4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'getLocalTranslator',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a66fdc193e83014d816b36986cdaba14' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'setLocalTranslator',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5c6f042547605016bacec60f485a2041' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'getTranslationMessageWith',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e52adf31cced5df69090c43e37eb39be' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'getTranslationMessage',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '94304ea33f6fbd9159fd7f8881570108' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'translateWith',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6496e277455c3ea12654ee38e4d76124' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'translate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8eefd4d389d4b3981bfacef3cb901e62' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'translateNumber',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5aa3ed45c5d8b3777df9746fbf1fef11' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'translateTimeString',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '871e6374fd3f16d84c70bf4e1d3da33c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'getMatchingWordIndexes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2e6402509063bcbfe1ef489ad0b895f9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'translateTimeStringTo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd5fe969b845fd5e9979dde4451a86f61' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'locale',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b4d644a0a0481ecb03ecb970d92dd33e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'getLocale',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '24dbe93b42a26f62076406d5fed86c34' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'setLocale',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '581994364b90e5da25188e012aced2f7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'setFallbackLocale',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5764f5d0f5f7f52351caefdf8cfd6821' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'getFallbackLocale',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'df4b3c72dae0b7baaaf6ff2397e3353e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'executeWithLocale',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '156a29101d7f10ac6e8192e05c1b9a0b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'localeHasShortUnits',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '995725afc01b2c474a3286f4c9861333' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'localeHasDiffSyntax',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '591eaaf11017f94243b9a68763f0f8ec' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'localeHasDiffOneDayWords',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '14ce799eb29b6f22cfc2eafa62d072d4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'localeHasDiffTwoDayWords',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cab5a48376ed7afc1e3f945a6c5cb5a0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'localeHasPeriodSyntax',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9026d78273f862b85f3314c37ca4a4e0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'getAvailableLocales',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '26441b51c29b8ee6eddfccd66d0e83bf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'getAvailableLocalesInfo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b47c01fa5727d910840f625f1ae42b44' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'getTranslatorLocale',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '665cda68bfe7b40dc485b28a9002db55' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'getLocaleAwareTranslator',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ae47e8356831d42d4307858c98c01c0a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'getFromCatalogue',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fe850f58345ff58522d1cb9ce3ab3db5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'cleanWordFromTranslationString',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3d25495952d8be68e9100ad88aea3a7e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'translateWordsByKeys',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f7301a6048fd659f16418c141085f164' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'getTranslationArray',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9c49b8dfc90d51294e356179311383d3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'carboninterface' => 'Carbon\\CarbonInterface',
          'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
          'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
          'language' => 'Carbon\\Language',
          'translator' => 'Carbon\\Translator',
          'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
          'closure' => 'Closure',
          'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
          'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
          'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ),
         'className' => 'Carbon\\Traits\\Localization',
         'functionName' => 'replaceOrdinalWords',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'carboninterface' => 'Carbon\\CarbonInterface',
            'invalidtypeexception' => 'Carbon\\Exceptions\\InvalidTypeException',
            'notlocaleawareexception' => 'Carbon\\Exceptions\\NotLocaleAwareException',
            'language' => 'Carbon\\Language',
            'translator' => 'Carbon\\Translator',
            'translatorstrongtypeinterface' => 'Carbon\\TranslatorStrongTypeInterface',
            'closure' => 'Closure',
            'translatorbaginterface' => 'Symfony\\Component\\Translation\\TranslatorBagInterface',
            'localeawareinterface' => 'Symfony\\Contracts\\Translation\\LocaleAwareInterface',
            'translatorinterface' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
          ),
           'className' => 'Carbon\\Traits\\Localization',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Localization.php' => 'c9e5cba3a1609019a5e0b4b9e646f216d3fb28dcf914202b20ed74cdcb223efe',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../nesbot/carbon/src/Carbon/Traits/StaticLocalization.php' => '4f9f8e7535980a8d4c9d23d2d470fd35f76ae56468388e2db7698e582b721864',
    ),
  ),
));