<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Comparison.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      'b03444ddb6302f02c673291bb3588a71' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '16f7b87a388ec2611ccb133b0c900105' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'eq',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6f2bc480bc60ae502d18e9c3b91ad91f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'equalTo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'afb0848cf02683a950a9a9a2171478f1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'ne',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7613d3937c46348dc74631570fdfa32c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'notEqualTo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1f2e888210b4ea18a5ed536505a84d5e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'gt',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9c28a19d6bc2a1505f9738d92af23375' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'greaterThan',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '892776833bbbba3b8f0ecbdb2334cba6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isAfter',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7c3c63594e0e7aea5038450f5c19e523' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'gte',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1eea5da06f89a65ccb64ff2cead85d5f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'greaterThanOrEqualTo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '893a08a341d13db67557bf41cdc4c9c7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'lt',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b5c9fb60e9d09fd73edf4aa31b78860e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'lessThan',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b2214e4427af9af9607f2c246c86e2bd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isBefore',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ea0bf36bbea02ed07cb423588b97b1da' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'lte',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fb9f671b92e88e90ec60a9bbc3189b96' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'lessThanOrEqualTo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e4f328f6e7f95c9c19a3f4a546f455dc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'between',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2cbeaec6a0bd85d60a7b70fe40e6821b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'betweenIncluded',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3a94e550bbb11001b445d2840735dfa6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'betweenExcluded',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd849d49e04af5550e68667ff2f228df0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isBetween',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '87c1ebfbeb17fe71969e88e618e77af9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isWeekday',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9de596730fa93388997cabbf92d48263' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isWeekend',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b5938ae95783ecf8eefc18411f6eaa32' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isYesterday',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '764786ab1a369cc0a11d98a6e0433317' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isToday',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '37e304c018454284d8202d9596895744' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isTomorrow',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b1c63d149beac89424360ef1114e043a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isFuture',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e6dba59ef9313672bdb4931ee63b1771' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isPast',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5e4f54e8938b7e08c12ea4a3a4bbcd83' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isNowOrFuture',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8a727191ca54fc0ccf0b98124b6418d6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isNowOrPast',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '41cf43b6bb8b9bd347c58a932e891b9c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isLeapYear',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9167217e37bfa881b2702fc813ab8074' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isLongYear',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '42498592b06b767311493ce053e0d03e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isLongIsoYear',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4b5db3ec1fc54c3156548f5be4d48574' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isSameAs',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '854c671e63a7e07c82a97fb8bcf17654' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isSameUnit',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c9bcf25362f1eb9044e8c8d3b088866f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isCurrentUnit',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6d2d147173d1fc8e8b623ff010545869' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isSameQuarter',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f033b57c070165230670dc5a53129be0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isSameMonth',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fbed16b09b659f62734648ff49854ac4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isDayOfWeek',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '77cba274658eb7a6d4c315ea6dc728ff' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isBirthday',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b52c8364d332bd6fd20e54cfcc91b615' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isLastOfMonth',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b0eacc3277ab89dd3d2d26a7dcb3bdfd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isStartOfUnit',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'eb515483836a92ba0743aa3286a39862' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isEndOfUnit',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c521ddb791306d514e70a035687dbe5b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isStartOfMillisecond',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7d59e06a5867325c4bfb27a1bccdc594' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isEndOfMillisecond',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9f3d06e05ba8bd68a887d8514270afc0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isStartOfSecond',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '894ad0e39025c57470c4ca8e2c3f33a5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isEndOfSecond',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1ec644202b896010259641b4c51356ea' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isStartOfMinute',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'eddd4d03bf7c3209778f9cfda591875f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isEndOfMinute',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f315e16587c99cdbcfa025d5c5583ac7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isStartOfHour',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '839b9f0ebcc5f7179efc9c8ceba4460c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isEndOfHour',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6e0c6405f6482c203d719f2527b570bc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isStartOfDay',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '056f56e319080b97f09419c90ccf8004' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isEndOfDay',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0df58d5958175f6ab4ef375489ee3862' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isStartOfWeek',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a176303aa7d516dd07d220981fe3d42b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isEndOfWeek',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e774f0ea3aedd2bf470d757e6e8a3dc8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isStartOfMonth',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '88dd573bb542418fe31cc4dfb4024bc0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isEndOfMonth',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '02a80964867bf313c048ccb4639f663f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isStartOfQuarter',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ca76bdaf550535c101f7371167277ebe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isEndOfQuarter',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd2d81f840b48209956e67cc7fa74f9c5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isStartOfYear',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '69b468e77e232d5032e6c32e41a831fa' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isEndOfYear',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ace6d4c533fada7e93c7c60c27034755' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isStartOfDecade',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'df6eea7660bb851a904ce1a3f9a9a33f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isEndOfDecade',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e16d1f7f06e7dc0dc970cee0c261f3a7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isStartOfCentury',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3bc5010dda4fe504ce53a657241bd0d8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isEndOfCentury',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '92a4b502ba8528ddff5d357bd6d33477' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isStartOfMillennium',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'da82b8f5e2d693fd0ca9746ade629820' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isEndOfMillennium',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f5ebbc5cd11c0c3e8d8dbc4d9528cd65' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isMidnight',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2589412a31a4721e147311baf788843a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isMidday',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '08d050cfc345aacbb6c4d9bfd2cf6d24' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'hasFormat',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4f6f5104d689026dcb0e212462f95a72' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'hasFormatWithModifiers',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6b7b297437a461e355985af8203c5373' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'canBeCreatedFromFormat',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e777b4cd219356cdd7b24f6ce8e8b929' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'is',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b3b772994cac820ee31aa191b4dfee11' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isStartOfTime',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7e07e28ac4654515a28b5ad046591fe1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Carbon\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'badmethodcallexception' => 'BadMethodCallException',
          'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
          'carboninterface' => 'Carbon\\CarbonInterface',
          'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
          'factoryimmutable' => 'Carbon\\FactoryImmutable',
          'month' => 'Carbon\\Month',
          'unit' => 'Carbon\\Unit',
          'weekday' => 'Carbon\\WeekDay',
          'closure' => 'Closure',
          'dateinterval' => 'DateInterval',
          'datetimeinterface' => 'DateTimeInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'Carbon\\Traits\\Comparison',
         'functionName' => 'isEndOfTime',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Carbon\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'badmethodcallexception' => 'BadMethodCallException',
            'carbonconverterinterface' => 'Carbon\\CarbonConverterInterface',
            'carboninterface' => 'Carbon\\CarbonInterface',
            'badcomparisonunitexception' => 'Carbon\\Exceptions\\BadComparisonUnitException',
            'factoryimmutable' => 'Carbon\\FactoryImmutable',
            'month' => 'Carbon\\Month',
            'unit' => 'Carbon\\Unit',
            'weekday' => 'Carbon\\WeekDay',
            'closure' => 'Closure',
            'dateinterval' => 'DateInterval',
            'datetimeinterface' => 'DateTimeInterface',
            'invalidargumentexception' => 'InvalidArgumentException',
          ),
           'className' => 'Carbon\\Traits\\Comparison',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/nesbot/carbon/src/Carbon/Traits/Comparison.php' => '2238f1264439673c03b0f283618e7638718eb6a6f4aa6b9d74f58b59e9b5906b',
    ),
  ),
));