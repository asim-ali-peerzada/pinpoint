<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Foundation/Console/ModelMakeCommand.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-52c3c71fba8e2dbce12b1e560c0af437c46bb836f5882a341c2adda2709b7d29-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\foundation\\console\\modelmakecommand' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));