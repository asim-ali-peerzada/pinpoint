<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas/src/Console/ScopeMakeCommand.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-57c97ae8299d9f5795fc0a95739adac104454525abe81893d0442ce975638ecc-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'orchestra\\canvas\\console\\scopemakecommand' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));