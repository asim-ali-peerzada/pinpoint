<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../symfony/http-foundation/Request.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-3cdfb6da08d239a36737a80a0f62f823eb26e5864d51fd940d9106c3435f49a0-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'symfony\\component\\httpfoundation\\request' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));