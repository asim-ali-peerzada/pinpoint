<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas/src/Console/EventMakeCommand.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-8e723044c6365df26967593a37b3456f35235d2088a327aeae87a345e2807aea-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'orchestra\\canvas\\console\\eventmakecommand' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));