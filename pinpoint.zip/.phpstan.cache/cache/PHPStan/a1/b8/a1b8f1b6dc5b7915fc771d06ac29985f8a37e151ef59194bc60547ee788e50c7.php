<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      'a74e1b38f2b7713fd82d64564f18301a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1f2b4bf9d94ec8aa7cb888f019c1e6d1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'bc4e2d2efda4567f93db66f5c3e68170' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'presetmanager' => 'Orchestra\\Canvas\\Core\\PresetManager',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
          3 => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          4 => NULL,
        ),
      )),
      '7671c48d866dfde7ab0e61debb87fc1f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'presetmanager' => 'Orchestra\\Canvas\\Core\\PresetManager',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => 'addGeneratorPresetOptions',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
          3 => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          4 => NULL,
        ),
      )),
      'ad0553a0ca1adae805acd00166f913c6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'presetmanager' => 'Orchestra\\Canvas\\Core\\PresetManager',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => 'generatorPreset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
          3 => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          4 => NULL,
        ),
      )),
      '58ba7239c2184bed5ba4796a2a8ee377' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'presetmanager' => 'Orchestra\\Canvas\\Core\\PresetManager',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => 'getGeneratorSourcePath',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
          3 => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          4 => NULL,
        ),
      )),
      '1924a5fdf53d15284cf2f715193231fe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => 'generateCode',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '63f94c85de91e6b8d63b9953991c62dd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => 'generatingCode',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'ad592b8fac88e261f34383c39ff8803c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => 'codeAlreadyExists',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'dc61070d65bbf1fc0af09607f6f5f4b3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => 'codeHasBeenGenerated',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'b0fffb3b2cf7e7c6692a5785c476d02b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => 'afterCodeHasBeenGenerated',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '178e0a1f92689f41fcf0f0aad7ab1600' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'ffe036982c1aa0edb95863100a497008' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => 'handleTestCreationUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '2d8446007ca9979e2f805c26da1065b3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'c60cd03c3ccb2e1ad2ef1308cc04fa63' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => 'qualifyModelUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '73240cce290414bd5ed87c80559dcd17' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => 'getPathUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '9993da45a8df5031a9afc4435120e15f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => 'rootNamespaceUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'b4a0e539b62399677428d4655efbd901' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => 'userProviderModelUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '81c5ed1d8030a92538a2369cbeb13d89' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => 'viewPathUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '84587ef729c2dbd4ce085efa14472cbe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => 'findAvailableModelsUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '9fff58dc3e06274d1e38e06c58200cb9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => 'possibleModelsUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '5a8ca6fe65f412dc8c994e770144209c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => 'possibleEventsUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'b084d2f11348f1997fe703283c507e80' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => 'rootNamespace',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '24933f8a7f0147d14a79b1fbe9a03020' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => 'generatorPreset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'd25565216160368681966a0e15a4ba7e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => 'configure',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Orchestra\\Canvas\\Console',
           'uses' => 
          array (
            'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
            'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
            'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
            'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
          ),
           'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8c5c89acb6bac2c3eaa6a1858f3dd737' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => 'handle',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Orchestra\\Canvas\\Console',
           'uses' => 
          array (
            'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
            'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
            'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
            'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
          ),
           'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'abaa9bf29e4c31cd0eda5c70258b1a09' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => 'getPath',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Orchestra\\Canvas\\Console',
           'uses' => 
          array (
            'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
            'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
            'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
            'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
          ),
           'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4a263b9f60b308a4f5225d1171671f06' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
         'functionName' => 'rootNamespace',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Orchestra\\Canvas\\Console',
           'uses' => 
          array (
            'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
            'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
            'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
            'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
          ),
           'className' => 'Orchestra\\Canvas\\Console\\ChannelMakeCommand',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/ChannelMakeCommand.php' => '28fa535be30420a37b669c6111294b0c8e48e32dfd5ac5a9c7b9151f1566e33e',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas-core/src/Concerns/CodeGenerator.php' => '53a99bd8408373e5b764137127dd6bb92f0f84481043bc6e888a5bca12525f95',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas-core/src/Concerns/CreatesUsingGeneratorPreset.php' => '04f1fc472c3c006decd42fd64ba2fd495b70184367d40a981caa601c12ad8775',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas-core/src/Concerns/TestGenerator.php' => 'ef413e8049b5871ddf09a295ff748ee33efd5a8673d085e8a292c571cb30451f',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas-core/src/Concerns/UsesGeneratorOverrides.php' => 'ccb973108e69ca46e54365c3cacda3127f5f816944d3d836b07a02ff21b1869d',
    ),
  ),
));