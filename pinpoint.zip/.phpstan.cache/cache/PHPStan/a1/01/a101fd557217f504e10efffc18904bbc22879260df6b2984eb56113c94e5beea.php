<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../spatie/laravel-package-tools/src/Concerns/Package/HasServiceProviders.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-13087bce55edcd7331c49f401090abc08d2c179e352ddfb847cafa160781a438-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'spatie\\laravelpackagetools\\concerns\\package\\hasserviceproviders' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));