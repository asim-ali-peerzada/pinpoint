<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Database/Console/DumpCommand.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-73e4b19f7fb131a6ed1b9cc01bcbe561623c5d26a4c5a4ede3416e5260e820aa-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\database\\console\\dumpcommand' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));