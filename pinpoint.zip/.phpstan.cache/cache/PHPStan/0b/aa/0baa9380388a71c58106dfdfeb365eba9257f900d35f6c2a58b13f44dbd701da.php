<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../pestphp/pest-plugin-laravel/src/Commands/PestTestCommand.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-5a567301210a6ece95a2f8fbafaf646a60f0b526a1a707b78e0072ec73a7a495-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'pest\\laravel\\commands\\pesttestcommand' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));