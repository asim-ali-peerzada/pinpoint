<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Support/Traits/Dumpable.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-5ee524eba6728c03ac2743fb83643d2178f7a632664167f92d87323c10206ad8-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\support\\traits\\dumpable' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));