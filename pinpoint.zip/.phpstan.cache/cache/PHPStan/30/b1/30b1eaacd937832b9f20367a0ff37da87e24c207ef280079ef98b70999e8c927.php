<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Http/Request.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-b588e38f63b4050aeb78e8d0ba90bd5adebba883f5c7391153e457c34e73175d-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\http\\request' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));