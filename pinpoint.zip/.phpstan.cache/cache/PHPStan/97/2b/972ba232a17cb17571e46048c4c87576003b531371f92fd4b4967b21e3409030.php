<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      '8f5dda4b05d4868538a8f560d7c80b5f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
          'TKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TKey',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'array-key',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 2,
                'endLine' => 2,
              ),
            )),
          ),
          'TValue' => 
          array (
            0 => '@template-covariant',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c3dc6cc0504bb8cd297cd5bc733177ab' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
          'TKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TKey',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'array-key',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 2,
                'endLine' => 2,
              ),
            )),
          ),
          'TValue' => 
          array (
            0 => '@template-covariant',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '47b7843c512b021d656ddaea3b1232ab' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'closure' => 'Closure',
          'higherorderwhenproxy' => 'Illuminate\\Support\\HigherOrderWhenProxy',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Conditionable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\Conditionable',
          3 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          4 => NULL,
        ),
      )),
      'e808bbefc794cfb03a89319a99027ed7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'closure' => 'Closure',
          'higherorderwhenproxy' => 'Illuminate\\Support\\HigherOrderWhenProxy',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'when',
         'templatePhpDocNodes' => 
        array (
          'TWhenParameter' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TWhenParameter',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TWhenReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TWhenReturnType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Conditionable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\Conditionable',
          3 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          4 => NULL,
        ),
      )),
      'd099b52bb31edfba73443d1a17af2ade' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'closure' => 'Closure',
          'higherorderwhenproxy' => 'Illuminate\\Support\\HigherOrderWhenProxy',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'unless',
         'templatePhpDocNodes' => 
        array (
          'TUnlessParameter' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TUnlessParameter',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TUnlessReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TUnlessReturnType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Conditionable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\Conditionable',
          3 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          4 => NULL,
        ),
      )),
      '8f906b783c4c5bc461e96d99df77c004' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'make',
         'templatePhpDocNodes' => 
        array (
          'TMakeKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMakeKey',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'array-key',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TMakeValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMakeValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'fdb2acd4ab11c3212885f685608b83ee' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'wrap',
         'templatePhpDocNodes' => 
        array (
          'TWrapValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TWrapValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '1b0e3e299c39864d1e1e47cb561093fe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'unwrap',
         'templatePhpDocNodes' => 
        array (
          'TUnwrapKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TUnwrapKey',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'array-key',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TUnwrapValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TUnwrapValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '65251011e605f62945093847a078a565' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'empty',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'ac5b127acb16dcad8dd0ec40a9753f25' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'times',
         'templatePhpDocNodes' => 
        array (
          'TTimesValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TTimesValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'a1a24dbf6577e7c45d737f6f35aed053' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'fromJson',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'c02b8c484033038a2752788e53639630' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'avg',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '903e2f4d47a53e48bfa8906e11ac41e3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'average',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '520c5e04e50d5d271efde66abe845ad4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'some',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '9903a6fffad786c821d0d405cef1b0b4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'dd',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '50002958eb98ca47310d17613827e94c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'dump',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '7874aa24a3da7df4c56180319bd9b10e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'each',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '901632fe3e298a2c627d4edebbe018f5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'eachSpread',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'd9b821c15a67c18916a5fb5fe22bad4c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'every',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'f2c087d8ac23879213e53900dcdc4c33' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'firstWhere',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '5e77c672830ee3fd989e88445da45f42' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'hasMany',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '7398c041e9bd1131510def7e1ddf66d9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'value',
         'templatePhpDocNodes' => 
        array (
          'TValueDefault' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TValueDefault',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'f2ab0041c77eb07d620d7a1e9bf8ddf5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'ensure',
         'templatePhpDocNodes' => 
        array (
          'TEnsureOfType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TEnsureOfType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '143e9a12a5de0d439a92885aad7cf3fd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'isNotEmpty',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '32bd33f38fde85c837fc5e89aee187e1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'mapSpread',
         'templatePhpDocNodes' => 
        array (
          'TMapSpreadValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMapSpreadValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'f1d830c9304760fb9eef0f7ca400e814' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'mapToGroups',
         'templatePhpDocNodes' => 
        array (
          'TMapToGroupsKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMapToGroupsKey',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'array-key',
                 'attributes' => 
                array (
                  'startLine' => 6,
                  'endLine' => 6,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 6,
                'endLine' => 6,
              ),
            )),
          ),
          'TMapToGroupsValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMapToGroupsValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 7,
                'endLine' => 7,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '41a980dc4ae6c969a87d1540502451d8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'flatMap',
         'templatePhpDocNodes' => 
        array (
          'TFlatMapKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TFlatMapKey',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'array-key',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TFlatMapValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TFlatMapValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '4f3c8ff5aeb1607f59123282ce7a785e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'mapInto',
         'templatePhpDocNodes' => 
        array (
          'TMapIntoValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMapIntoValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '54d384d1c30e2c79c8fef943104b9dce' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'min',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '1c420b46990c54ab8ba4fa38caeef35d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'max',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'd9ccf70454afbb4a95f3bb93eb2d118e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'forPage',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'ed3962faaba63fbd1d11c3db89dcad9b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'partition',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '6128c9a922e38e043715f4d38c8cd7a7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'percentage',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '6f3855dc613d47466f723026e3d0af56' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'sum',
         'templatePhpDocNodes' => 
        array (
          'TReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TReturnType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '63e7fc844921b3d96ed454b6a8d28fe5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'whenEmpty',
         'templatePhpDocNodes' => 
        array (
          'TWhenEmptyReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TWhenEmptyReturnType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'a1167a75247806ea34af8448a5cd5f8f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'whenNotEmpty',
         'templatePhpDocNodes' => 
        array (
          'TWhenNotEmptyReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TWhenNotEmptyReturnType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'd8f11bd2addd5063d6b9ea756422c9ef' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'unlessEmpty',
         'templatePhpDocNodes' => 
        array (
          'TUnlessEmptyReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TUnlessEmptyReturnType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'e6772b0109d87f13b7e54f62c6e43a72' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'unlessNotEmpty',
         'templatePhpDocNodes' => 
        array (
          'TUnlessNotEmptyReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TUnlessNotEmptyReturnType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '0d2149b0144ad5838047ae8d0ecca562' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'where',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'fb9fd6f93bb4b7890010b3bb64aaadff' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'whereNull',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '0912afc593c78cbade8bf378f4d0915c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'whereNotNull',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '0ca566bfec3655a0713cfa6c1bca2b52' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'whereStrict',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '7c1a8449be6a8dd0e1017689551d8717' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'whereIn',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '5226fab0aa7017a106ec51860afd1b39' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'whereInStrict',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'e38314abe97dfcff3b47af25e78faef1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'whereBetween',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '93c7972a1238cffce48c85ee7b16af1f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'whereNotBetween',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '142633eba9a3c66bd346a4668080f082' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'whereNotIn',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '65407a8f5661df7b1f23eca6d769e8e0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'whereNotInStrict',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'e624fe435739209e5a8ef9cb38c8378a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'whereInstanceOf',
         'templatePhpDocNodes' => 
        array (
          'TWhereInstanceOf' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TWhereInstanceOf',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'aa17c223e4d65d9aa0b53673d8e71faf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'pipe',
         'templatePhpDocNodes' => 
        array (
          'TPipeReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TPipeReturnType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'e46390a306ced31e41c386f1d0a393b9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'pipeInto',
         'templatePhpDocNodes' => 
        array (
          'TPipeIntoValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TPipeIntoValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'b64cc8a47e4b371f074b26e62e415c67' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'pipeThrough',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '2328323b752a76c33d871311e520c3f6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'reduce',
         'templatePhpDocNodes' => 
        array (
          'TReduceInitial' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TReduceInitial',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TReduceReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TReduceReturnType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '2bd221067034a4cdab0414cc1caf899e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'reduceSpread',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '9d592eaee769cbfb64e8c800264e2397' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'reduceWithKeys',
         'templatePhpDocNodes' => 
        array (
          'TReduceWithKeysInitial' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TReduceWithKeysInitial',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TReduceWithKeysReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TReduceWithKeysReturnType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '4db1bcb3fa1d4a271d02c61ba97288f5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'reject',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'b387ccb225c90445c3dd789679ddf387' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'tap',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '9bacbbf4483165dfe1fda72f66edba06' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'unique',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '4136286919ff5b4359e7879f625208dc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'uniqueStrict',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '74411cf7b883c706afe7e9a9220d9e39' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'collect',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '0c5789957f7e1df76463ec8267a92069' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'toArray',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '4365f1959cc087dc8d3032c862c035d1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'jsonSerialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '8169f19ecf3fc1724be4c8d7d574b0da' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'toJson',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'e591879cf9b1476caa1c635a6f66fdfe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'toPrettyJson',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '028e5ab05cb053505c3092a418f4db64' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'getCachingIterator',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '8a497dfd811a2489170d952b2a2aea65' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => '__toString',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '5a0fa1f18dde88be637b17067c1559a3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'escapeWhenCastingToString',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '2dc8ded7a4082fd8fc9732c101e4238d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'proxy',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '76a512ed70cacef887531d42a5ea7e25' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => '__get',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '77bfd46246d43d04cc2d817ad16dc7c0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'getArrayableItems',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '05297581e7eaa5d04f81d475369f46f3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'operatorForWhere',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'cdf4f3254081d5f85bd2eb3f5732aef4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'useAsCallable',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '2eeb08d8fc38be9a7d83c729f4faaa41' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'valueRetriever',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '9ab5b28fb3f08f75553a682e0d7c9cf9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'equality',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'a41654364d7c3cc4c08d3085ad01f8c0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'negate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'a941e4de36ef69ed34929fd6d9f2c2b4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'backedenum' => 'BackedEnum',
          'cachingiterator' => 'CachingIterator',
          'closure' => 'Closure',
          'exception' => 'Exception',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'arr' => 'Illuminate\\Support\\Arr',
          'collection' => 'Illuminate\\Support\\Collection',
          'enumerable' => 'Illuminate\\Support\\Enumerable',
          'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
          'jsonserializable' => 'JsonSerializable',
          'unexpectedvalueexception' => 'UnexpectedValueException',
          'unitenum' => 'UnitEnum',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'identity',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support\\Traits',
           'uses' => 
          array (
            'backedenum' => 'BackedEnum',
            'cachingiterator' => 'CachingIterator',
            'closure' => 'Closure',
            'exception' => 'Exception',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'arr' => 'Illuminate\\Support\\Arr',
            'collection' => 'Illuminate\\Support\\Collection',
            'enumerable' => 'Illuminate\\Support\\Enumerable',
            'higherordercollectionproxy' => 'Illuminate\\Support\\HigherOrderCollectionProxy',
            'jsonserializable' => 'JsonSerializable',
            'unexpectedvalueexception' => 'UnexpectedValueException',
            'unitenum' => 'UnitEnum',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '5655200f89a0866989aded75c23ef2f0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '5d01ec60e5726ffb6d9f70d802988306' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'macro',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'd5324c195382d20a8533932b7138c322' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'mixin',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'e21442c42a6ba4b9d34428d2646b41c1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'hasMacro',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '5fd67cd746d995b8ad7c514444ee406d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'flushMacros',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '9b3faf6640387f1ab9ec9cdebf597867' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => '__callStatic',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '9aae42633b4579d47d6714c2acf170d5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'badmethodcallexception' => 'BadMethodCallException',
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionmethod' => 'ReflectionMethod',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => '__call',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\Macroable',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\Macroable',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'cc869067a2ae170995e11095663469c0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'useresource' => 'Illuminate\\Database\\Eloquent\\Attributes\\UseResource',
          'useresourcecollection' => 'Illuminate\\Database\\Eloquent\\Attributes\\UseResourceCollection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'resourcecollection' => 'Illuminate\\Http\\Resources\\Json\\ResourceCollection',
          'logicexception' => 'LogicException',
          'reflectionclass' => 'ReflectionClass',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'dbb825d17c79dd5694df0115571f89d0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'useresource' => 'Illuminate\\Database\\Eloquent\\Attributes\\UseResource',
          'useresourcecollection' => 'Illuminate\\Database\\Eloquent\\Attributes\\UseResourceCollection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'resourcecollection' => 'Illuminate\\Http\\Resources\\Json\\ResourceCollection',
          'logicexception' => 'LogicException',
          'reflectionclass' => 'ReflectionClass',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'toResourceCollection',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'aff8836e936d57033080b7129d376506' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'useresource' => 'Illuminate\\Database\\Eloquent\\Attributes\\UseResource',
          'useresourcecollection' => 'Illuminate\\Database\\Eloquent\\Attributes\\UseResourceCollection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'resourcecollection' => 'Illuminate\\Http\\Resources\\Json\\ResourceCollection',
          'logicexception' => 'LogicException',
          'reflectionclass' => 'ReflectionClass',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'guessResourceCollection',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'e722e6a9c296609fedae0306485770a4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'useresource' => 'Illuminate\\Database\\Eloquent\\Attributes\\UseResource',
          'useresourcecollection' => 'Illuminate\\Database\\Eloquent\\Attributes\\UseResourceCollection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'resourcecollection' => 'Illuminate\\Http\\Resources\\Json\\ResourceCollection',
          'logicexception' => 'LogicException',
          'reflectionclass' => 'ReflectionClass',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'resolveResourceFromAttribute',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      '0f33dc329d84017f917589fbecdaee15' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support\\Traits',
         'uses' => 
        array (
          'useresource' => 'Illuminate\\Database\\Eloquent\\Attributes\\UseResource',
          'useresourcecollection' => 'Illuminate\\Database\\Eloquent\\Attributes\\UseResourceCollection',
          'model' => 'Illuminate\\Database\\Eloquent\\Model',
          'resourcecollection' => 'Illuminate\\Http\\Resources\\Json\\ResourceCollection',
          'logicexception' => 'LogicException',
          'reflectionclass' => 'ReflectionClass',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'resolveResourceCollectionFromAttribute',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php',
          1 => 'Illuminate\\Support\\Collection',
          2 => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          3 => NULL,
          4 => '/**
 * @use \\Illuminate\\Support\\Traits\\EnumeratesValues<TKey, TValue>
 */',
        ),
      )),
      'e541147dd30c81d0cb49150d1eba590f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b589a17469191ff76b6591ee359dd520' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'range',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '288145caea44fcf06e4f6d4647d0d1ad' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'all',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ee7c7de4baa05a6f6b955b927db83e7c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'lazy',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1ce661d7c02221cd8a5c8e0afb49b3b7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'median',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6cec0aecf2da8bfef0b70042824f2d5c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'mode',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'afb83db9312f3d98ed716d0bba164051' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'collapse',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7a8f529627b0deb596840c8825e1ae66' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'collapseWithKeys',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5d3d8da9b38ecbf7d3e6548049f729ae' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'contains',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9e5543775b5da4444d2d8937b83c4b27' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'containsStrict',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a17c9754ddfa21a1752c97390f449554' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'doesntContain',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '22b2833b78ed673458e0fdd56746c590' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'doesntContainStrict',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '174b87300d47817c7cc37d2746462868' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'crossJoin',
         'templatePhpDocNodes' => 
        array (
          'TCrossJoinKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TCrossJoinKey',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TCrossJoinValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TCrossJoinValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '65921676d5da393fa0dd8cfe4836ce97' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'diff',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cc97874b73633a46bbaa3d8ac0fbb632' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'diffUsing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cf64d3288d23d0c4ef0e1a0c8363b281' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'diffAssoc',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6c3a673c2bd76f98808f50ba76174a6d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'diffAssocUsing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6f43e87d333aada61c25d322eb182739' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'diffKeys',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2e114a194148d9972d56d4b0f2f7000b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'diffKeysUsing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '98b5042c04f7b9b30753ee1a465a933b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'duplicates',
         'templatePhpDocNodes' => 
        array (
          'TMapValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMapValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1658e7b995633cc42d5328e3c4511ec5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'duplicatesStrict',
         'templatePhpDocNodes' => 
        array (
          'TMapValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMapValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '06f5a43eb0c4a239ec222d6c6f567443' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'duplicateComparator',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ac03692333408ede303ee873c135d074' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'except',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '15d1ebfdf4bafc1e12f75276f105311a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'filter',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4eac12af0093f8c3439ec7c68896d4e8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'first',
         'templatePhpDocNodes' => 
        array (
          'TFirstDefault' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TFirstDefault',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '045961faa3e69ddf04ea76d6ec9d6b50' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'flatten',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a24b25cc38ea03752f9e3c822ddc7e8e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'flip',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'afc6d57fa7990d278c97fe045e6a5749' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'forget',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '82ed064f534c208f52b8c7b7a7946e69' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'get',
         'templatePhpDocNodes' => 
        array (
          'TGetDefault' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TGetDefault',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a2f05bb3cf631fff40bc904eb7c52d43' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'getOrPut',
         'templatePhpDocNodes' => 
        array (
          'TGetOrPutValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TGetOrPutValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ec6888e2b15b7fa0c1c03971c022f718' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'groupBy',
         'templatePhpDocNodes' => 
        array (
          'TGroupKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TGroupKey',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\UnionTypeNode::__set_state(array(
                 'types' => 
                array (
                  0 => 
                  \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                     'name' => 'array-key',
                     'attributes' => 
                    array (
                      'startLine' => 4,
                      'endLine' => 4,
                    ),
                  )),
                  1 => 
                  \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                     'name' => '\\UnitEnum',
                     'attributes' => 
                    array (
                      'startLine' => 4,
                      'endLine' => 4,
                    ),
                  )),
                  2 => 
                  \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                     'name' => '\\Stringable',
                     'attributes' => 
                    array (
                      'startLine' => 4,
                      'endLine' => 4,
                    ),
                  )),
                ),
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6bab996397c46d4edb74452ccfacebdd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'keyBy',
         'templatePhpDocNodes' => 
        array (
          'TNewKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TNewKey',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\UnionTypeNode::__set_state(array(
                 'types' => 
                array (
                  0 => 
                  \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                     'name' => 'array-key',
                     'attributes' => 
                    array (
                      'startLine' => 4,
                      'endLine' => 4,
                    ),
                  )),
                  1 => 
                  \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                     'name' => '\\UnitEnum',
                     'attributes' => 
                    array (
                      'startLine' => 4,
                      'endLine' => 4,
                    ),
                  )),
                ),
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3c7543abbe4bc6c7ff88742678330dfe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'has',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '62d467080a22837c786f40e3235680f1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'hasAny',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dda772ee61c94fe71e8b582f5fdc6a23' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'implode',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4e7e3e81c2acd0fe35f6babd3cc4433a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'intersect',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c3e7a7c5da7c5569f34ae6768d261291' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'intersectUsing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cad8d8a644ec988bd9e6c74029343244' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'intersectAssoc',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd3d9ac6f393773cbae8dcebfcce0a58f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'intersectAssocUsing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a53b3150050d5724948a80e4261fe1f4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'intersectByKeys',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f79e50b5e039400f9de27ad7fe3e8b35' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'isEmpty',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '21cfef32784732e0123063a5bd5e5a53' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'containsOneItem',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '98cb448c4297902e89b7d627fe24d9e7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'containsManyItems',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '730680c5d89e83d917500da0c9330c3e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'join',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '27e1afd380aa873b16db177e9f7f09f7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'keys',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c615f59777325401a9e36b785ebf888a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'last',
         'templatePhpDocNodes' => 
        array (
          'TLastDefault' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TLastDefault',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd640a185cf043c0c728680fcd2a507f0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'pluck',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cb40dc28623af39b623415014c8ed07a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'map',
         'templatePhpDocNodes' => 
        array (
          'TMapValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMapValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fce5bb163860ad99d990194054ae87b3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'mapToDictionary',
         'templatePhpDocNodes' => 
        array (
          'TMapToDictionaryKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMapToDictionaryKey',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'array-key',
                 'attributes' => 
                array (
                  'startLine' => 6,
                  'endLine' => 6,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 6,
                'endLine' => 6,
              ),
            )),
          ),
          'TMapToDictionaryValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMapToDictionaryValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 7,
                'endLine' => 7,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd237bb6ceb7da9c985be8e97260d42a5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'mapWithKeys',
         'templatePhpDocNodes' => 
        array (
          'TMapWithKeysKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMapWithKeysKey',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'array-key',
                 'attributes' => 
                array (
                  'startLine' => 6,
                  'endLine' => 6,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 6,
                'endLine' => 6,
              ),
            )),
          ),
          'TMapWithKeysValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMapWithKeysValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 7,
                'endLine' => 7,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9111c804bed72d3dfb427e54977b6067' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'merge',
         'templatePhpDocNodes' => 
        array (
          'TMergeValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMergeValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f22d48dfeb233ab19ca5bf6318a8eb63' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'mergeRecursive',
         'templatePhpDocNodes' => 
        array (
          'TMergeRecursiveValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMergeRecursiveValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ba53d38e65c24ca39818b477933e0814' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'multiply',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7e55b53317919804d824b20e616a509b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'combine',
         'templatePhpDocNodes' => 
        array (
          'TCombineValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TCombineValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a384007b4923d4c76d86690bea4a7d52' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'union',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5f233df67a66011065e67a0026a35f7d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'nth',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '06e4ebdaa8d04b3e5f8c37446ce98b7a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'only',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a37027084695c62c4091b943fb8b633f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'select',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3e847af9c60c314dd7ebe1db52166873' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'pop',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '160b2fd2094cd11787853716c9388ad8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'prepend',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9bbd3d0cb5c8fec47385fcaabbdf98f0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'push',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '97e961b1963d031bc2385f7ffc1fbd4e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'unshift',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '58f50d3dcafaa0b80e8fc02c332d96ae' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'concat',
         'templatePhpDocNodes' => 
        array (
          'TConcatKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TConcatKey',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'array-key',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TConcatValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TConcatValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ee555df70094b33cd19d5b8209f476a0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'pull',
         'templatePhpDocNodes' => 
        array (
          'TPullDefault' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TPullDefault',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cff912b59efebdd2d4af951cd49a4f33' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'put',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1a0a0970255149b0c40f017edb196a76' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'random',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b5bc825d2145b8ba0df38c0a69db1253' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'replace',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '10d79fcc51d5182b0a2db87dff8d04c3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'replaceRecursive',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e620f87b8daa685cc1a4ed2cbf35e43a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'reverse',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '52a88871972564eee4b5743f5d55b586' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'search',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e54acc0d5ce44ea9352a6c9d8d537ea2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'before',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b8cd9e12779c76fdbe4614575e472f98' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'after',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1338edf01c721b8e8adaa6bead364fb1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'shift',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fa82cc6ec9beecd53c4d315e37299d86' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'shuffle',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e32eae49b0a5a952d6d927fbc94e6488' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'sliding',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c28819c9698d959495b8308ea639dd8f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'skip',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '49d0249ffee14fe83894ae9cb0c8efba' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'skipUntil',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b6da8d5f12553bd12dfdd9d5194fad03' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'skipWhile',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6cf3a503bd4de9e86789a754483683ec' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'slice',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c9c78967d07caba3bb30ba7e1c100b73' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'split',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e589e09ae4058afcd8e8561beb3a7806' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'splitIn',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0ad0e4405955f1c7c531c14b0d2bbaea' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'sole',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e3205f16cc98ccfcde7a388b8d92f44d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'hasSole',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1f66d30d94705eb5354d8d99c5dd6770' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'firstOrFail',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b3c41d790b45a84f7b485368a3871808' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'chunk',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd43c49327d377a07bdb1e640fa10b02f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'chunkWhile',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1e42536d5728fa6601eb6fdf77260cbc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'sort',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5f61624decde82be33533db126a1bb2b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'sortDesc',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd88c9db51f9b251e3910dde125083f42' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'sortBy',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd37ed54df4339a08fc169f5c6ebaea4d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'sortByMany',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6111eb74d28194b97a5df634dbd3a624' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'sortByDesc',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9fb793b174bf8743c481d2adbda793e0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'sortKeys',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '46611ccbc079961b244fe1f14416cd01' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'sortKeysDesc',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '16a16a880146e675db368a68571ee6bf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'sortKeysUsing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ba5fef4150f777a228a366da1eb17be4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'splice',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '64fe8fe3b2b8d36534e37edceb3b30f6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'take',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f61431bf5c928bfcc5644b5d57d6a15f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'takeUntil',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7e978a135a263f51729f29dfd918dc1f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'takeWhile',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7f9c60a2fd543aa0892eadda93cc5ec5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'transform',
         'templatePhpDocNodes' => 
        array (
          'TMapValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMapValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7d9560ba35d844943c45af4569d66c80' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'dot',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bdc917602931e512d913e9b9c951f4ab' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'undot',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6d3fedd1ab32faa39b8426a85aa0936c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'unique',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '97e41bbca421e973e14596bcbf100e73' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'values',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '67eca9c8ef75aeaa922709e55e3295c2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'zip',
         'templatePhpDocNodes' => 
        array (
          'TZipValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TZipValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 7,
                'endLine' => 7,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd0aecdc712ff9eb0a590c78306b5132b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'pad',
         'templatePhpDocNodes' => 
        array (
          'TPadValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TPadValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'eb9395bfdb8b366e3a8b9b913b4ae58e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'getIterator',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1aed79e1e586c318f9425ab99736bab8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'count',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e1c63a3f12c5303a107204b7dbb69406' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'countBy',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '12fa179f91b830e3f47f0c1a85b496e6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'add',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '40e919ee3c142da868a2d9535b09b491' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'toBase',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3c36c9a3c55591a1c125c25bd600b75e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'offsetExists',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fe827fe73731345ba5a6c5f9148f8653' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'offsetGet',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e80378356b863a0f457d1798e1473718' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'offsetSet',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3367c47c0fbb159e1300177a2d30e1b8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'arrayaccess' => 'ArrayAccess',
          'arrayiterator' => 'ArrayIterator',
          'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
          'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
          'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
          'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
          'invalidargumentexception' => 'InvalidArgumentException',
          'stdclass' => 'stdClass',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Collection',
         'functionName' => 'offsetUnset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'arrayaccess' => 'ArrayAccess',
            'arrayiterator' => 'ArrayIterator',
            'canbeescapedwhencasttostring' => 'Illuminate\\Contracts\\Support\\CanBeEscapedWhenCastToString',
            'enumeratesvalues' => 'Illuminate\\Support\\Traits\\EnumeratesValues',
            'macroable' => 'Illuminate\\Support\\Traits\\Macroable',
            'transformstoresourcecollection' => 'Illuminate\\Support\\Traits\\TransformsToResourceCollection',
            'invalidargumentexception' => 'InvalidArgumentException',
            'stdclass' => 'stdClass',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Collection',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Collection.php' => 'adcc6e766e1db8ef7dfbf30df442ef2eef01bb60b3fe88aeb2a3f30a33904a60',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Collections/Traits/EnumeratesValues.php' => '594ad51a08959a8a5fa8276ed0daed2acc3e24fc8ba7365fc0a53a1c7e4e6c31',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Conditionable/Traits/Conditionable.php' => '5697fdba0acb78ca0b4e122e5c459cd5d97d000ed9b14fed31271cb7ffd44225',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Macroable/Traits/Macroable.php' => '6dd85b1e28b55ebeee678f9ca423dfb8375e1342bc42d8658da6321bdf97b3c0',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Collections/Traits/TransformsToResourceCollection.php' => '226b1867a790e6da048a1b9a717b8af16ca169b1eac84605d5ae76a2aaf96f40',
    ),
  ),
));