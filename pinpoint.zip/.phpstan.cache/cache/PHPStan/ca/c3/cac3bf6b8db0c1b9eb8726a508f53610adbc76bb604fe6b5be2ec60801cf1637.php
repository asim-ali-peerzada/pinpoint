<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Enumerable.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      'aa3270e8593156a38da87cfb6a6bf32a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
          'TKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TKey',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'array-key',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 2,
                'endLine' => 2,
              ),
            )),
          ),
          'TValue' => 
          array (
            0 => '@template-covariant',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b31b83f75c512dcaff40d32ed6ae3d1e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'make',
         'templatePhpDocNodes' => 
        array (
          'TMakeKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMakeKey',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'array-key',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TMakeValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMakeValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '77566b24ec9300bfd26ef7d8b3c78790' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'times',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3343eba1d1082190542b45b35ce2b726' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'range',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9c7bda4a2e0bae1fc4f3c300ca160768' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'wrap',
         'templatePhpDocNodes' => 
        array (
          'TWrapValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TWrapValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'abd3ad2ca9131d7f0d0dd9d55a4c85d4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'unwrap',
         'templatePhpDocNodes' => 
        array (
          'TUnwrapKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TUnwrapKey',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'array-key',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TUnwrapValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TUnwrapValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '79b5eaddf87a78f3af595e2eefa7e4d6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'empty',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6efed51bbff7afddadb130db0363501a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'all',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5193e7babb942672b6e0bc6020b0b3f8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'average',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c850abbced9b4999d18a38105743593a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'median',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '230986277faa1937a1c6bf05a636e7e8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'mode',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cd29f0893267906de549f51bf166b599' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'collapse',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7320b828dfb9cbbc3f7276bfd4dfe910' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'some',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '981a1f78c95528ad010dc706d39e8dab' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'containsStrict',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '53936558173b93cae3077ac8fa2b4fc1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'avg',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0fc6e8502013f0ddb0fcb195abac2650' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'contains',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9423b4c67a54bff41a4deca4eef95817' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'doesntContain',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6b626e2c25a304281302193607248a14' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'crossJoin',
         'templatePhpDocNodes' => 
        array (
          'TCrossJoinKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TCrossJoinKey',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TCrossJoinValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TCrossJoinValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cab0da137d4fef77f9488c9be5b47a02' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'dd',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '813a8036e55f57784ca3572454ed4687' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'dump',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '31c84f235b928fce7f5d8b249ac54cba' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'diff',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '67676ef512330d95031832eb3aafcb51' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'diffUsing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ca5a11d00679deb4550234d98dd099f1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'diffAssoc',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ffa76a0a6c7e77bcb43b5acd8e8114f0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'diffAssocUsing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd91e9b58772592f9f6b7b5a5ee153db1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'diffKeys',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5c012b58995fb33b3953fffc1660f53a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'diffKeysUsing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '03740507cd0594c826651c699165c800' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'duplicates',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2b3411f035508a7042e185d92a5de437' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'duplicatesStrict',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9d2dd742243a3d8445c73f3dd896b961' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'each',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '552a749d607b7d05fd44cba53c1a7d82' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'eachSpread',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd0f110706961fceecd82ab5dd2bd5b37' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'every',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '17b0980abf977b4fd1c297fde6bb0fd4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'except',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5fe02e9a5d4ea67d8ef739e6c8e4a54a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'filter',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd359d8d62cf7c8311588f2a465de1b7b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'when',
         'templatePhpDocNodes' => 
        array (
          'TWhenReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TWhenReturnType',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'null',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'aad5d1080fd3787ee1734aa81b584233' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'whenEmpty',
         'templatePhpDocNodes' => 
        array (
          'TWhenEmptyReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TWhenEmptyReturnType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3d8b3bb7128aa23ffb40a11a5bd244b9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'whenNotEmpty',
         'templatePhpDocNodes' => 
        array (
          'TWhenNotEmptyReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TWhenNotEmptyReturnType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f4e40fbecf50e1c163dc0257d1eca906' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'unless',
         'templatePhpDocNodes' => 
        array (
          'TUnlessReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TUnlessReturnType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3febe8a7c9c2c1bc8bfd50b11cece27c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'unlessEmpty',
         'templatePhpDocNodes' => 
        array (
          'TUnlessEmptyReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TUnlessEmptyReturnType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8b7ac2177f7feb58540a3988de1f1d73' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'unlessNotEmpty',
         'templatePhpDocNodes' => 
        array (
          'TUnlessNotEmptyReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TUnlessNotEmptyReturnType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '509961fc4e732740f0d42a2290a2ac09' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'where',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dfb5de215e42b08a9fa043ce2e88c776' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'whereNull',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '22543d97e5a580d2eb1779edbbc367e5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'whereNotNull',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7f49b5017cfada1087cac3a300f8e400' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'whereStrict',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3931b53df0702c7e43710983581d056d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'whereIn',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '015f2381899c2beefd319622a6861223' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'whereInStrict',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1cf5ca8afd6daed0f3405e932f8499dd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'whereBetween',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd3ecc762f7df160672625cf9c55ae99c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'whereNotBetween',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5ce1a18fb9ab3ccd57ed626d1bca6353' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'whereNotIn',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '69a2ffcbc3dbabac50d83bf89e7609d7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'whereNotInStrict',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '777d999c0e49a74a45218e0b33e20b36' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'whereInstanceOf',
         'templatePhpDocNodes' => 
        array (
          'TWhereInstanceOf' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TWhereInstanceOf',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '859bcfdcdf6ca4067f878a25c2f6ab18' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'first',
         'templatePhpDocNodes' => 
        array (
          'TFirstDefault' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TFirstDefault',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '16a33af47cd774569145a7d3187bfe63' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'firstWhere',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4d962f362a336764c88bc08396cfe2dc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'flatten',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f8bfce956d9c8a7fbb5b6566f40ba671' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'flip',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2fcdcb80800c7529202346947f23eaf4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'get',
         'templatePhpDocNodes' => 
        array (
          'TGetDefault' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TGetDefault',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '482e10d9e24bec588e40cc9fab5f9223' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'groupBy',
         'templatePhpDocNodes' => 
        array (
          'TGroupKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TGroupKey',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'array-key',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1fa08c0767988df3ef7a8b529372181e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'keyBy',
         'templatePhpDocNodes' => 
        array (
          'TNewKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TNewKey',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'array-key',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'de09f32f9dd05db25f3ec33466751924' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'has',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0a873f4115297a93649828cec6e38432' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'hasAny',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8d257b9f5044c01a5e6c026e6cc09fd0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'implode',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '66b5f235607eb12520e49fe883a16061' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'intersect',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '584fc6c503ed4e18d9b904ae82965d62' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'intersectUsing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '872ee1e374dc2889fbc4572004f49eba' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'intersectAssoc',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '56522f0ec7c5ab4ee1a5113708db1635' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'intersectAssocUsing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0f70e070904bda634ff45154db7ff88a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'intersectByKeys',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5edc87a7807a2229428169dad1d72970' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'isEmpty',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '82e94c9cb0b92a94df4213f98d7a0db9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'isNotEmpty',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2a7734f1e6288e78d79f83c56d206cff' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'containsOneItem',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '19cde86965b4c07d4c1f273e42efd411' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'containsManyItems',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3e66ff40e2bb9c401ba72f5d564a24b6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'join',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5cb0f7954b0091f093d93ca9ae2d9b3a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'keys',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4199eb275a31beb0f8c253f1a0f26dc7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'last',
         'templatePhpDocNodes' => 
        array (
          'TLastDefault' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TLastDefault',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e5d394fedc01174d16dd1ce1a503f79c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'map',
         'templatePhpDocNodes' => 
        array (
          'TMapValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMapValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '25a66f42952b701094fa80dbac040a1d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'mapSpread',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f74f9da37c3303dd56f32717cb893c6f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'mapToDictionary',
         'templatePhpDocNodes' => 
        array (
          'TMapToDictionaryKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMapToDictionaryKey',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'array-key',
                 'attributes' => 
                array (
                  'startLine' => 6,
                  'endLine' => 6,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 6,
                'endLine' => 6,
              ),
            )),
          ),
          'TMapToDictionaryValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMapToDictionaryValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 7,
                'endLine' => 7,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '130e5ee6e8ad336e0f92787acb2daa0b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'mapToGroups',
         'templatePhpDocNodes' => 
        array (
          'TMapToGroupsKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMapToGroupsKey',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'array-key',
                 'attributes' => 
                array (
                  'startLine' => 6,
                  'endLine' => 6,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 6,
                'endLine' => 6,
              ),
            )),
          ),
          'TMapToGroupsValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMapToGroupsValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 7,
                'endLine' => 7,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '119140a938bb5e1282c780b8d8fc200c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'mapWithKeys',
         'templatePhpDocNodes' => 
        array (
          'TMapWithKeysKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMapWithKeysKey',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'array-key',
                 'attributes' => 
                array (
                  'startLine' => 6,
                  'endLine' => 6,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 6,
                'endLine' => 6,
              ),
            )),
          ),
          'TMapWithKeysValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMapWithKeysValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 7,
                'endLine' => 7,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '81bb81a835d24bd30a870755a3a48d8e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'flatMap',
         'templatePhpDocNodes' => 
        array (
          'TFlatMapKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TFlatMapKey',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'array-key',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TFlatMapValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TFlatMapValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e3c8115466685bc298612157a2639c25' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'mapInto',
         'templatePhpDocNodes' => 
        array (
          'TMapIntoValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMapIntoValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2ccf91f4bcac5c201603e32573a76c38' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'merge',
         'templatePhpDocNodes' => 
        array (
          'TMergeValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMergeValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fc4d44da0a7745a9f73f7e8e26cabb17' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'mergeRecursive',
         'templatePhpDocNodes' => 
        array (
          'TMergeRecursiveValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TMergeRecursiveValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7be8cc8a4ed7fc1f499c62881b826ae5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'combine',
         'templatePhpDocNodes' => 
        array (
          'TCombineValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TCombineValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f2eff9895ab69f2dc284fc938029fac5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'union',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd4424a2f43500fb036b24afd614a2541' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'min',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f227cc1a907dd43ea9b87e829c92b1d2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'max',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3ef367b411739d6e830e993001d5a60b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'nth',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6ce0d479cfac56a9208b80326b801ea7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'only',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd720fccaa24dbc75e30427c9bf5d69e3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'forPage',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '36c219aba710aff0987b8a56cb4ad642' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'partition',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a31e9f891b9e06dc1882ada94e1d74bc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'concat',
         'templatePhpDocNodes' => 
        array (
          'TConcatKey' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TConcatKey',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'array-key',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TConcatValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TConcatValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '10cb1677565c24a1674c57fc7d8f3566' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'random',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '013f1f633b11ee58564f52675ba0d19c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'reduce',
         'templatePhpDocNodes' => 
        array (
          'TReduceInitial' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TReduceInitial',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
          'TReduceReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TReduceReturnType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 5,
                'endLine' => 5,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5ceac7dd0106c9be4cf5e88cfbb6db76' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'reduceSpread',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '025c85a383e4666295bdd348b7e620cb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'replace',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '37a20b1decca8d8229e9d9f729ac849f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'replaceRecursive',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '55e2ffeb31258531b75cba9690fc2ae4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'reverse',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e71b805860d955a143c0d84917f613e6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'search',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ac0df81b419c7089e43dedf5f1efd72c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'before',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '123f87b5fa7e99dee42349f2238aff68' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'after',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1a16fe0b39e79b65cd2771c53c279cf4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'shuffle',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c429890311a87ce5fe421523efd4ca0c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'sliding',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5d39cf27e8c05ca4a84e3f8943201a15' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'skip',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3266c77d4520d07f97a0d920be84973a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'skipUntil',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '13db135829a7ffa888bc5a2d83531840' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'skipWhile',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '23bddaad3e0e50788ecedc416aa1bcec' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'slice',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '27db7abb936e6dfe5f334bd0fabcda48' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'split',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0ef0c1e5c85b085ce104348240e781e7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'sole',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '41014bdfaebc41c00feb6d17103d01f0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'firstOrFail',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd27e9e2be50b03b4475fef6397e073f6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'chunk',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '927d22fd42134f7084ec36987d0a3fcf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'chunkWhile',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dcf5574005500ee3fcf4e84843021ea5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'splitIn',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9891500aefeb783584a4b0722d76003e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'sort',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f9e7232e6a4787965407f59e399220f1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'sortDesc',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '66e298fc6f834caee3d851ffe182482a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'sortBy',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '13835f80651b156ae2a423eaee149ec6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'sortByDesc',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3ab072738eabd38cde4736ddb89d4ddb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'sortKeys',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6b2d5c3fe0a01a80c3993f1026d0a012' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'sortKeysDesc',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a12ce50e198befcc3623d0f58444d5a4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'sortKeysUsing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1325ff8d033c1b01683c10cbce41c80c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'sum',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '383f2493b3176c42a2e6da13ac53fd20' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'take',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'aa116de22034204b270efadebcf46d51' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'takeUntil',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e1cfbec462bf2cef960356dccd0e58f8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'takeWhile',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7c2f40dd4968b887679a907cdd1a7f5a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'tap',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ae5f90d420b6b5424b89f7ec97754698' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'pipe',
         'templatePhpDocNodes' => 
        array (
          'TPipeReturnType' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TPipeReturnType',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cc9afba35b58835f4aa60ff54362f04c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'pipeInto',
         'templatePhpDocNodes' => 
        array (
          'TPipeIntoValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TPipeIntoValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bbd06695f358abca798fc5f0252a27d1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'pipeThrough',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f5735adb389904b2fec5d91845284521' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'pluck',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd751357feeb8bc008b9125320865e48c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'reject',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '05c4c1967abb7b7eb4620c6b6c4abfee' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'undot',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2faaab5f89e9eaedd39b29133d286ca1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'unique',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '564668c4a28a9c03c91573b3e1d8e58b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'uniqueStrict',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '235beacb611ccb035cfdc96ec7bdcebe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'values',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0c5f016b02e3bc94ba6c0e8875102622' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'pad',
         'templatePhpDocNodes' => 
        array (
          'TPadValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TPadValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3f01b0f63fbd83840e7d7dfa318449e1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'getIterator',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5e22758e56371ff50a9042a671087e4c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'count',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e19ce5f08159ea77e6060089c96c0330' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'countBy',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e59905fda289fe5ac608620f9c57c98e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'zip',
         'templatePhpDocNodes' => 
        array (
          'TZipValue' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TZipValue',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 7,
                'endLine' => 7,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b52840c5b565454bb41e56d7347a2c2e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'collect',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e89f889ead50b002ed1822a7008e7890' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'toArray',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1e67378d606605e77e491d1b2f6224c5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'jsonSerialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '78fb22ecffe792818aa92b8fb404fc2a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'toJson',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '97562335a7fd4047c27c6e0fe0868e2a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'toPrettyJson',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2bd903ac9d6cc03184b755448ed8e6f7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'getCachingIterator',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '050c165c46b1c734dc38526db1cfd1b5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => '__toString',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '30bf09830b69d5c8e39ae003cd4b0a7e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'escapeWhenCastingToString',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3c1e79cbece9089e46d9936fbb93ebdd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => 'proxy',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'aba71a6dbb72d769a1eb968ed94a9934' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Support',
         'uses' => 
        array (
          'cachingiterator' => 'CachingIterator',
          'countable' => 'Countable',
          'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
          'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
          'iteratoraggregate' => 'IteratorAggregate',
          'jsonserializable' => 'JsonSerializable',
          'traversable' => 'Traversable',
        ),
         'className' => 'Illuminate\\Support\\Enumerable',
         'functionName' => '__get',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Illuminate\\Support',
           'uses' => 
          array (
            'cachingiterator' => 'CachingIterator',
            'countable' => 'Countable',
            'arrayable' => 'Illuminate\\Contracts\\Support\\Arrayable',
            'jsonable' => 'Illuminate\\Contracts\\Support\\Jsonable',
            'iteratoraggregate' => 'IteratorAggregate',
            'jsonserializable' => 'JsonSerializable',
            'traversable' => 'Traversable',
          ),
           'className' => 'Illuminate\\Support\\Enumerable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
            'TKey' => 
            array (
              0 => '@template',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TKey',
                 'bound' => 
                \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                   'name' => 'array-key',
                   'attributes' => 
                  array (
                    'startLine' => 2,
                    'endLine' => 2,
                  ),
                )),
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 2,
                  'endLine' => 2,
                ),
              )),
            ),
            'TValue' => 
            array (
              0 => '@template-covariant',
              1 => 
              \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
                 'name' => 'TValue',
                 'bound' => NULL,
                 'default' => NULL,
                 'lowerBound' => NULL,
                 'description' => '',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
            ),
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Collections/Enumerable.php' => '14dc76e6dfc3e24e817554e3e35166c932a9254d137c392732e6a959b8796069',
    ),
  ),
));