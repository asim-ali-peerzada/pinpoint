<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      '2cf580da2d01ad0d06debb47a20d9905' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a829e0377f708ce82998ebd614dd937d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'debd54ddde64e368180978a7676881d9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'presetmanager' => 'Orchestra\\Canvas\\Core\\PresetManager',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
          3 => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          4 => NULL,
        ),
      )),
      '19da90ba7409631e6de6266af631655c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'presetmanager' => 'Orchestra\\Canvas\\Core\\PresetManager',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => 'addGeneratorPresetOptions',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
          3 => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          4 => NULL,
        ),
      )),
      'ca846997d1597d79628583e8fde40627' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'presetmanager' => 'Orchestra\\Canvas\\Core\\PresetManager',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => 'generatorPreset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
          3 => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          4 => NULL,
        ),
      )),
      'a75ee120763332b647e3dda2468a2079' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'presetmanager' => 'Orchestra\\Canvas\\Core\\PresetManager',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'inputoption' => 'Symfony\\Component\\Console\\Input\\InputOption',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => 'getGeneratorSourcePath',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CreatesUsingGeneratorPreset',
          3 => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          4 => NULL,
        ),
      )),
      '32ea5b2da6a8d538d961119fb5ed584e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => 'generateCode',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '93b99abd3b16ecb6608032bdbdd518e0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => 'generatingCode',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '5ddcc66970faf15200735bdacba72979' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => 'codeAlreadyExists',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '41878a0c0c60473417dc0549503c598a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => 'codeHasBeenGenerated',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'e2ec8e1f18dccb89514de5180bf30b26' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'createsmatchingtest' => 'Illuminate\\Console\\Concerns\\CreatesMatchingTest',
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => 'afterCodeHasBeenGenerated',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '5b7903f6247e069b0411627c556293ee' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '89fa419b2bd916a9b90afa62b2352a01' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => 'handleTestCreationUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '2ca2c4ca650b8388c361c3e7224d3bb6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '5f410e12c86f08c8569d4ed3bd1e4a15' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => 'qualifyModelUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '1a28cdf5b3475397f7080b4adb9f8dc6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => 'getPathUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'ae74b888cce54cc3ac8b8347b3ced296' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => 'rootNamespaceUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '461903e766c2218ab848fa21bbf6875d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => 'userProviderModelUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '217257135f00fad980eace81757aad61' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => 'viewPathUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      'e9a9529ea0bcfcd0d1f3944c94bedf6c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => 'findAvailableModelsUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '4092c8ebaa2250428d1aed289b312590' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => 'possibleModelsUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '8b47184dfed0c771cc94c36fa5aee073' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => 'possibleEventsUsingCanvas',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '61b0c6dd5ad5a965575347d3e5ae16bf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => 'rootNamespace',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '81f8a5910836b97128cc3bb534181660' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Core\\Concerns',
         'uses' => 
        array (
          'str' => 'Illuminate\\Support\\Str',
          'preset' => 'Orchestra\\Canvas\\Core\\Presets\\Preset',
          'finder' => 'Symfony\\Component\\Finder\\Finder',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => 'generatorPreset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
         'traitData' => 
        array (
          0 => '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php',
          1 => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
          2 => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          3 => NULL,
          4 => NULL,
        ),
      )),
      '4a74f54bbc4bb74bcfa2159214f86887' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => 'configure',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Orchestra\\Canvas\\Console',
           'uses' => 
          array (
            'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
            'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
            'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
            'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
          ),
           'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '10b6eab5c951c4340cc311cb1715a896' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => 'handle',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Orchestra\\Canvas\\Console',
           'uses' => 
          array (
            'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
            'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
            'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
            'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
          ),
           'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8017e9de3122606a83efc420659873bc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => 'getPath',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Orchestra\\Canvas\\Console',
           'uses' => 
          array (
            'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
            'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
            'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
            'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
          ),
           'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8b33315d5e395de0ca4317bf8b407302' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Orchestra\\Canvas\\Console',
         'uses' => 
        array (
          'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
          'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
          'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
          'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
        ),
         'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
         'functionName' => 'rootNamespace',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Orchestra\\Canvas\\Console',
           'uses' => 
          array (
            'codegenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\CodeGenerator',
            'testgenerator' => 'Orchestra\\Canvas\\Core\\Concerns\\TestGenerator',
            'usesgeneratoroverrides' => 'Orchestra\\Canvas\\Core\\Concerns\\UsesGeneratorOverrides',
            'ascommand' => 'Symfony\\Component\\Console\\Attribute\\AsCommand',
          ),
           'className' => 'Orchestra\\Canvas\\Console\\MiddlewareMakeCommand',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/orchestra/canvas/src/Console/MiddlewareMakeCommand.php' => 'e8b19da26e61bed50689eea0367e20bfcddcaff447506226ac464fd187021113',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas-core/src/Concerns/CodeGenerator.php' => '53a99bd8408373e5b764137127dd6bb92f0f84481043bc6e888a5bca12525f95',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas-core/src/Concerns/CreatesUsingGeneratorPreset.php' => '04f1fc472c3c006decd42fd64ba2fd495b70184367d40a981caa601c12ad8775',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas-core/src/Concerns/TestGenerator.php' => 'ef413e8049b5871ddf09a295ff748ee33efd5a8673d085e8a292c571cb30451f',
      '/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../orchestra/canvas-core/src/Concerns/UsesGeneratorOverrides.php' => 'ccb973108e69ca46e54365c3cacda3127f5f816944d3d836b07a02ff21b1869d',
    ),
  ),
));