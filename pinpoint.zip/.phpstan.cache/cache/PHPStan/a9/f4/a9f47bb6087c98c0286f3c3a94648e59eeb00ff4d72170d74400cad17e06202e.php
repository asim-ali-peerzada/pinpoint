<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Queue/Console/ResumeCommand.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-f1d7688cd68d9665d5ae0bbe8b60d37627748f4c43f5a4356aad6b624cb5d1f1-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\queue\\console\\resumecommand' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));