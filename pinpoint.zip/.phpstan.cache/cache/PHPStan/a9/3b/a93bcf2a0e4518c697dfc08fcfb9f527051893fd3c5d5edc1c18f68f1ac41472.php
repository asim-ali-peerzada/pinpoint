<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Contracts/Container/Container.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      '1f7ef0cf46b9356f721a7d8db5d184f3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bedf639454b91902e8ebb2c28222b27a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'get',
         'templatePhpDocNodes' => 
        array (
          'TClass' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TClass',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'object',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b538aa953978d2efbe0870a97925411d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'bound',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1624cace7010dc895841dd767fc28735' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'alias',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5331b1489b0f22a00a1ca2f69106a812' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'tag',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6a34eb6756cce261738b7c4c9e9e0020' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'tagged',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0270e69ba490b65a0f01091135330034' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'bind',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3012a0aa5b80c57a71a9e6dab2500ffb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'bindMethod',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7463e2d59706f4e7000a07575298d221' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'bindIf',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '76fc91f5a6e24911a797e16094c8fcfa' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'singleton',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '26572df9e988cf9de511f6d18810065e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'singletonIf',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dee0d7e9f519fb0a26284e6714d71416' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'scoped',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1f6ee9f0a10b93a4b2d5c92aae73b463' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'scopedIf',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bae8d0a2d76e57f5206238df349b0c77' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'extend',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ac6d5fd708c717e4c400a383019927ac' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'instance',
         'templatePhpDocNodes' => 
        array (
          'TInstance' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TInstance',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'mixed',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c56318da38d36906e4373bb5ff7034cb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'addContextualBinding',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '081bb57c50f7612cd1c2a68dbe564469' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'when',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6a2ba155931c652d5f4824ce0dadcff8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'factory',
         'templatePhpDocNodes' => 
        array (
          'TClass' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TClass',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'object',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8b9d93ff9fc34c554cae75ff7d7d02a5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'flush',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bf653369c920393b57810f92e8cb9000' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'make',
         'templatePhpDocNodes' => 
        array (
          'TClass' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'TClass',
               'bound' => 
              \PHPStan\PhpDocParser\Ast\Type\IdentifierTypeNode::__set_state(array(
                 'name' => 'object',
                 'attributes' => 
                array (
                  'startLine' => 4,
                  'endLine' => 4,
                ),
              )),
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '',
               'attributes' => 
              array (
                'startLine' => 4,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a7c4048639c3a5c3012115a144709bf5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'call',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2ce03452f528ef54bf628ee7ed48d311' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'resolved',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8a3373e86b9be57d6338ab19e62f96ee' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'beforeResolving',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd3ec2788ccd6c5a242e3089b15592d7b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'resolving',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e6ecc1c3d2a0c42e17e50a5a677ff249' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Illuminate\\Contracts\\Container',
         'uses' => 
        array (
          'closure' => 'Closure',
          'containerinterface' => 'Psr\\Container\\ContainerInterface',
        ),
         'className' => 'Illuminate\\Contracts\\Container\\Container',
         'functionName' => 'afterResolving',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/vendor/laravel/framework/src/Illuminate/Contracts/Container/Container.php' => 'cca1c6c4c50aa8bf7007e786cde473cc9bab83317367f384ab711a0c4d305611',
    ),
  ),
));