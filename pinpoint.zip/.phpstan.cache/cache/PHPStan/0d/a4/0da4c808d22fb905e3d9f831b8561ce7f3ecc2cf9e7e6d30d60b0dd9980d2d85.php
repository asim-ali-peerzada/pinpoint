<?php declare(strict_types = 1);

// ftm-/mnt/workspace/Personal-Projects/sentinel/src/Internal/Recorder.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.3',
   'data' => 
  array (
    0 => 
    array (
      '2ff7d2c217f21ece4ce248720a028d92' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint\\Internal',
         'uses' => 
        array (
          'config' => 'Illuminate\\Contracts\\Config\\Repository',
          'request' => 'Illuminate\\Http\\Request',
          'db' => 'Illuminate\\Support\\Facades\\DB',
        ),
         'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1fc2faba829e3088fa51499c30e7b2ad' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint\\Internal',
         'uses' => 
        array (
          'config' => 'Illuminate\\Contracts\\Config\\Repository',
          'request' => 'Illuminate\\Http\\Request',
          'db' => 'Illuminate\\Support\\Facades\\DB',
        ),
         'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'AsimAli\\Pinpoint\\Internal',
           'uses' => 
          array (
            'config' => 'Illuminate\\Contracts\\Config\\Repository',
            'request' => 'Illuminate\\Http\\Request',
            'db' => 'Illuminate\\Support\\Facades\\DB',
          ),
           'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0d4b0bce01999d0c7d7e9a40a4dac992' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint\\Internal',
         'uses' => 
        array (
          'config' => 'Illuminate\\Contracts\\Config\\Repository',
          'request' => 'Illuminate\\Http\\Request',
          'db' => 'Illuminate\\Support\\Facades\\DB',
        ),
         'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
         'functionName' => 'isRecording',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'AsimAli\\Pinpoint\\Internal',
           'uses' => 
          array (
            'config' => 'Illuminate\\Contracts\\Config\\Repository',
            'request' => 'Illuminate\\Http\\Request',
            'db' => 'Illuminate\\Support\\Facades\\DB',
          ),
           'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fd1ff46ec788c06fb47a4af84b50d80a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint\\Internal',
         'uses' => 
        array (
          'config' => 'Illuminate\\Contracts\\Config\\Repository',
          'request' => 'Illuminate\\Http\\Request',
          'db' => 'Illuminate\\Support\\Facades\\DB',
        ),
         'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
         'functionName' => 'capturesCaller',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'AsimAli\\Pinpoint\\Internal',
           'uses' => 
          array (
            'config' => 'Illuminate\\Contracts\\Config\\Repository',
            'request' => 'Illuminate\\Http\\Request',
            'db' => 'Illuminate\\Support\\Facades\\DB',
          ),
           'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9aa878ecf8f528150ce3e29867668900' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint\\Internal',
         'uses' => 
        array (
          'config' => 'Illuminate\\Contracts\\Config\\Repository',
          'request' => 'Illuminate\\Http\\Request',
          'db' => 'Illuminate\\Support\\Facades\\DB',
        ),
         'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
         'functionName' => 'shouldRecord',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'AsimAli\\Pinpoint\\Internal',
           'uses' => 
          array (
            'config' => 'Illuminate\\Contracts\\Config\\Repository',
            'request' => 'Illuminate\\Http\\Request',
            'db' => 'Illuminate\\Support\\Facades\\DB',
          ),
           'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7d00a604174753096776f3be456c17fc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint\\Internal',
         'uses' => 
        array (
          'config' => 'Illuminate\\Contracts\\Config\\Repository',
          'request' => 'Illuminate\\Http\\Request',
          'db' => 'Illuminate\\Support\\Facades\\DB',
        ),
         'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
         'functionName' => 'recordQuery',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'AsimAli\\Pinpoint\\Internal',
           'uses' => 
          array (
            'config' => 'Illuminate\\Contracts\\Config\\Repository',
            'request' => 'Illuminate\\Http\\Request',
            'db' => 'Illuminate\\Support\\Facades\\DB',
          ),
           'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e16d2713d6de3998f6eec3b4776e02c8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint\\Internal',
         'uses' => 
        array (
          'config' => 'Illuminate\\Contracts\\Config\\Repository',
          'request' => 'Illuminate\\Http\\Request',
          'db' => 'Illuminate\\Support\\Facades\\DB',
        ),
         'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
         'functionName' => 'recordLazyLoad',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'AsimAli\\Pinpoint\\Internal',
           'uses' => 
          array (
            'config' => 'Illuminate\\Contracts\\Config\\Repository',
            'request' => 'Illuminate\\Http\\Request',
            'db' => 'Illuminate\\Support\\Facades\\DB',
          ),
           'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '196de4dca66c4f3cc7a43325b0a8b80f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint\\Internal',
         'uses' => 
        array (
          'config' => 'Illuminate\\Contracts\\Config\\Repository',
          'request' => 'Illuminate\\Http\\Request',
          'db' => 'Illuminate\\Support\\Facades\\DB',
        ),
         'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
         'functionName' => 'flush',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'AsimAli\\Pinpoint\\Internal',
           'uses' => 
          array (
            'config' => 'Illuminate\\Contracts\\Config\\Repository',
            'request' => 'Illuminate\\Http\\Request',
            'db' => 'Illuminate\\Support\\Facades\\DB',
          ),
           'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bfd70d8c2f838ff4c460b697ca228966' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint\\Internal',
         'uses' => 
        array (
          'config' => 'Illuminate\\Contracts\\Config\\Repository',
          'request' => 'Illuminate\\Http\\Request',
          'db' => 'Illuminate\\Support\\Facades\\DB',
        ),
         'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
         'functionName' => 'reset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'AsimAli\\Pinpoint\\Internal',
           'uses' => 
          array (
            'config' => 'Illuminate\\Contracts\\Config\\Repository',
            'request' => 'Illuminate\\Http\\Request',
            'db' => 'Illuminate\\Support\\Facades\\DB',
          ),
           'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7878234f1ea6efbb2d41b5069cea3d48' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint\\Internal',
         'uses' => 
        array (
          'config' => 'Illuminate\\Contracts\\Config\\Repository',
          'request' => 'Illuminate\\Http\\Request',
          'db' => 'Illuminate\\Support\\Facades\\DB',
        ),
         'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
         'functionName' => 'hasNPlusOne',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'AsimAli\\Pinpoint\\Internal',
           'uses' => 
          array (
            'config' => 'Illuminate\\Contracts\\Config\\Repository',
            'request' => 'Illuminate\\Http\\Request',
            'db' => 'Illuminate\\Support\\Facades\\DB',
          ),
           'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dd9af02b6f0ca6a35735f9fa26849ddd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint\\Internal',
         'uses' => 
        array (
          'config' => 'Illuminate\\Contracts\\Config\\Repository',
          'request' => 'Illuminate\\Http\\Request',
          'db' => 'Illuminate\\Support\\Facades\\DB',
        ),
         'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
         'functionName' => 'repeatCounts',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'AsimAli\\Pinpoint\\Internal',
           'uses' => 
          array (
            'config' => 'Illuminate\\Contracts\\Config\\Repository',
            'request' => 'Illuminate\\Http\\Request',
            'db' => 'Illuminate\\Support\\Facades\\DB',
          ),
           'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '232a2b2d8dba27f495da664b95165e5e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint\\Internal',
         'uses' => 
        array (
          'config' => 'Illuminate\\Contracts\\Config\\Repository',
          'request' => 'Illuminate\\Http\\Request',
          'db' => 'Illuminate\\Support\\Facades\\DB',
        ),
         'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
         'functionName' => 'lazyLoads',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'AsimAli\\Pinpoint\\Internal',
           'uses' => 
          array (
            'config' => 'Illuminate\\Contracts\\Config\\Repository',
            'request' => 'Illuminate\\Http\\Request',
            'db' => 'Illuminate\\Support\\Facades\\DB',
          ),
           'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c5093217074ad943aa81b4f7899adf47' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'AsimAli\\Pinpoint\\Internal',
         'uses' => 
        array (
          'config' => 'Illuminate\\Contracts\\Config\\Repository',
          'request' => 'Illuminate\\Http\\Request',
          'db' => 'Illuminate\\Support\\Facades\\DB',
        ),
         'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
         'functionName' => 'queries',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'AsimAli\\Pinpoint\\Internal',
           'uses' => 
          array (
            'config' => 'Illuminate\\Contracts\\Config\\Repository',
            'request' => 'Illuminate\\Http\\Request',
            'db' => 'Illuminate\\Support\\Facades\\DB',
          ),
           'className' => 'AsimAli\\Pinpoint\\Internal\\Recorder',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      '/mnt/workspace/Personal-Projects/sentinel/src/Internal/Recorder.php' => 'd8bedea5807ca3fc4d0b063f8037f30b2b480c7ff5ee451d9ec76a505e1e1ac8',
    ),
  ),
));