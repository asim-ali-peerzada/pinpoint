<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Database/Eloquent/Relations/Relation.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-a3a7c7dc5d8bcfd4861a9b2621c9c1087af16a7341a73b70208a704727d38134-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\database\\eloquent\\relations\\relation' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));