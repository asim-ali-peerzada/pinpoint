<?php declare(strict_types = 1);

// phpinternal-PHPStan\BetterReflection\Reflection\ReflectionConstant-DEBUG_BACKTRACE_IGNORE_ARGS
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.3-dev-master@709e512-8.2.33',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\InternalLocatedSource',
      'data' => 
      array (
        'name' => 'DEBUG_BACKTRACE_IGNORE_ARGS',
        'filename' => 'phpstorm-stubs:Core/Core_d.stub',
        'extensionName' => 'Core',
        'aliasName' => NULL,
      ),
    ),
    'name' => 'DEBUG_BACKTRACE_IGNORE_ARGS',
    'shortName' => 'DEBUG_BACKTRACE_IGNORE_ARGS',
    'value' => 
    array (
      'code' => '2',
      'attributes' => 
      array (
        'startLine' => 3,
        'endLine' => 3,
        'startTokenPos' => 7,
        'startFilePos' => 45,
        'endTokenPos' => 7,
        'endFilePos' => 45,
      ),
    ),
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 3,
    'endLine' => 3,
    'startColumn' => 1,
    'endColumn' => 40,
    'namespace' => NULL,
  ),
));