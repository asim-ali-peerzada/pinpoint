<?php declare(strict_types = 1);

// osfsl-/mnt/workspace/Personal-Projects/sentinel/vendor/composer/../laravel/framework/src/Illuminate/Support/NamespacedItemResolver.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-58dde602b81c74f178865a56f919d9758fb0bb686753f16023ba8b628b94c564-8.2.33',
   'data' => 
  array (
    'classes' => 
    array (
      'illuminate\\support\\namespaceditemresolver' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));